#ifndef MAINDBEDITOR_H
#define MAINDBEDITOR_H

#include <QMainWindow>
#include"msgeditor.h"
#include "ui_maindbeditor.h"
#include "CANDefines.h"
#include "delegate.h"
#include "QDebug"
#include "tabdialog.h"
#include "tabdialogSignalMessage.h"
namespace Ui {
class MainDbEditor;
}

typedef enum{
    E_DbItemType_Header=0,
    E_DbItemType_Message,
    E_DbItemType_Signal,
    E_DbItemType_SignalInMessage,
}E_DbItemType;

class MainDbManager;
class MainDbCommonViewModel;
class MainDbTreeViewModel;
class MainDbTableMsgsModel;
class MainDbTableSignsModel;
class MainDbTableCombineModel;
class MsgEditor;
class TabDialogMess;
class TabDialogSignalMessage;
class MainDbEditor : public QMainWindow, Ui_MainDbEditor
{
    Q_OBJECT
friend class QTableWidgetItem;
public:
//    explicit MainDbEditor(QWidget *parent = 0);
    MainDbEditor(QWidget *parent = 0, QString path = 0);
    ~MainDbEditor();
    MainDbManager* getMainDbManager(){
        return m_mainDbManager;
    }

protected:
//    virtual void resizeEvent(QResizeEvent * event);
    virtual void closeEvent(QCloseEvent *);

private:
    MainDbManager * m_mainDbManager;
    MsgEditor   * m_MsgEditorWidget;
    TabDialogMess * m_SignalEditorWidget;
    TabDialogSignalMessage * m_SignMsgEditorWidget;
    MainDbTreeViewModel * m_treeViewModel;
    MainDbTableMsgsModel * m_tblMsgModel;
    MainDbTableSignsModel * m_tblSignModel;
    MainDbTableCombineModel *m_tblCombineModel;
    void updateViewMsgListTab();
    void updateViewSignsListTab();
    void updateViewCombListTab();

private slots:

    /*Interface with button/treeview/treewidget*/
    void slotOpenMessageEditor();
    void slotOpenSignalEditor();
    void slotLoadDb(QString & path);
    void slotSaveDb(QString & path);

    void slotOneClickTree(QModelIndex index);
    void slotDoubleClickTree(QModelIndex index);

    void slotOneClickMsgsTab(QModelIndex index);
    void slotDoubleClickMsgsTab(QModelIndex index);
    void slotOneClickSignsTab(QModelIndex index);
    void slotDoubleClickSignsTab(QModelIndex index);
    void slotOneClickCombTab(QModelIndex index);
    void slotDoubleClickCombTab(QModelIndex index);


    void slotContextMenuMsgTable(QPoint  point);
    void slotContextMenuSignsTable(QPoint  point);
    void slotContextMenuCombTable(QPoint  point);
    void slotContextMenuTreeWidget(QPoint  point);

    void updateByDelegateOnCombineTbl(QModelIndex);
    void updateTreeViewByDelegateOnCombineTbl(QModelIndex);
    void slotEditMess(QString);


    /*Interface with */

};

typedef struct{
    QString m_msgName;
    unsigned char m_StartBit;
}CANMessagesOfSignal;

class MainDbManager: public QObject
{
    Q_OBJECT
public:
    explicit MainDbManager();
    ~MainDbManager();
   QVector<CANSignalInMessage> getSignalsInMessage(QString & messageName);
   QVector<CANMessagesOfSignal> getMessagesOfSignal(int index);
   QVector <CANMessage*> getMessagesList(){return m_CANMessages;}
   QVector <CANSignal*> getSignalsList(){return m_CANSignals;}

   int messagesCount(){return m_CANMessages.size();}
   int signalsCount(){return m_CANSignals.size();}
   int signalsInMsgsCount(){return m_CountSignalsInMsg;}

   void loadDbFile(QString & path);
   void saveDbFile(QString & path);

//private:
    QString m_CurrentPath;
    QVector <CANSignal*> m_CANSignals;
    QVector <CANMessage*> m_CANMessages;
    unsigned int m_CountMsgs; //counting message "New_Message_xxx"
    unsigned int m_CountSigns;//counting signal "New_Signal_xxx"
    unsigned int m_CountSignalsInMsg; //counting all signals of all messages

public slots:
    bool slotAddMessage(CANMessage & message);
    bool slotAddSignal(CANSignal & signal);
    bool slotAddSignal2Message(CANSignal & signal);
    void updateByDelegateOnMessTbl(QModelIndex);
    void updateByDelegateOnSigTbl(QModelIndex);
};

class MainDbCommonItem
{
public:
    explicit MainDbCommonItem(QVector<QVariant> & data,E_DbItemType itemType, MainDbCommonItem *parent = 0);
    ~MainDbCommonItem();

    void setType(E_DbItemType itemType){m_itemType = itemType;}
    E_DbItemType getType(){return m_itemType ;}

    MainDbCommonItem *child(int number);
    int childCount() const;
    int columnCount() const;
    QVariant data(int column) const;
    bool insertChildren(int position, int count, int columns,E_DbItemType itemType);
    bool insertColumns(int position, int columns);
    MainDbCommonItem *parent();
    bool removeChildren(int position, int count);
    bool removeColumns(int position, int columns);
    int childNumber() const;
    bool setData(int column, const QVariant &value);

private:
    E_DbItemType m_itemType;
    QVector<QVariant>  itemData;
    QList<MainDbCommonItem*> childItems;
    MainDbCommonItem *parentItem;
};

class MainDbCommonViewModel:public QAbstractItemModel{
    Q_OBJECT

public:
    MainDbCommonViewModel(MainDbManager * dbMng, QObject *parent = 0);
    ~MainDbCommonViewModel();

    QModelIndex index(int row, int column,
                      const QModelIndex &parent = QModelIndex()) const override;
    QModelIndex parent(const QModelIndex &index) const override;

    int rowCount(const QModelIndex &parent = QModelIndex()) const override;
    int columnCount(const QModelIndex &parent = QModelIndex()) const override;

    bool insertColumns(int position, int columns,
                       const QModelIndex &parent = QModelIndex()) override;
    bool removeColumns(int position, int columns,
                       const QModelIndex &parent = QModelIndex()) override;
    bool insertRows(int position, int rows,
                    const QModelIndex &parent = QModelIndex()) override;
    bool removeRows(int position, int rows,
                    const QModelIndex &parent = QModelIndex()) override;
    MainDbCommonItem *getItem(const QModelIndex &index) const;

protected:
    MainDbCommonItem *rootItem;
    MainDbManager * m_dbManager;

    virtual     void setupModelData(MainDbCommonItem * parent){}

private:

};

class MainDbTreeViewModel:public MainDbCommonViewModel{
    Q_OBJECT
public:
    MainDbTreeViewModel(MainDbManager * dbMng, QObject *parent = 0):
        MainDbCommonViewModel(dbMng,parent){
        QVector<QVariant> rootData;
        rootData <<  "";
        rootItem = new MainDbCommonItem(rootData, E_DbItemType_Header);
        setupModelData(rootItem);
    }
    ~MainDbTreeViewModel(){}

    QVariant data(const QModelIndex &index, int role) const override;
    QVariant headerData(int section, Qt::Orientation orientation,
                        int role = Qt::DisplayRole) const override;
    bool setData(const QModelIndex &index, const QVariant &value,
                 int role = Qt::EditRole) override;
    bool setHeaderData(int section, Qt::Orientation orientation,
                       const QVariant &value, int role = Qt::EditRole) override;
    Qt::ItemFlags flags(const QModelIndex &index) const override;
protected:
    virtual     void setupModelData(MainDbCommonItem * parent);
public slots:
    void changeByTblMess(QModelIndex,QModelIndex,QVector<int>);
    void changeByTblSig(QModelIndex,QModelIndex,QVector<int>);
    void changeByCombTbl(QModelIndex,QModelIndex,QVector<int>);

};

class MainDbTableMsgsModel:public MainDbCommonViewModel{
    Q_OBJECT
public:
    MainDbTableMsgsModel(MainDbManager * dbMng, QObject *parent = 0);
    ~MainDbTableMsgsModel(){}

    QVariant data(const QModelIndex &index, int role) const override;
    QVariant headerData(int section, Qt::Orientation orientation,
                        int role = Qt::DisplayRole) const override;
    bool setData(const QModelIndex &index, const QVariant &value,
                 int role = Qt::EditRole) override;
    bool setHeaderData(int section, Qt::Orientation orientation,
                       const QVariant &value, int role = Qt::EditRole) override;
    Qt::ItemFlags flags(const QModelIndex &index) const override;
protected:
    void setupModelData(MainDbCommonItem *parent);
signals:
    void updateByDelegate(QModelIndex);



};

class MainDbTableSignsModel:public MainDbCommonViewModel{
    Q_OBJECT
public:
    MainDbTableSignsModel(MainDbManager * dbMng, QObject *parent = 0);
    ~MainDbTableSignsModel(){}

    QVariant data(const QModelIndex &index, int role) const override;
    QVariant headerData(int section, Qt::Orientation orientation,
                        int role = Qt::DisplayRole) const override;
    bool setData(const QModelIndex &index, const QVariant &value,
                 int role = Qt::EditRole) override;
    bool setHeaderData(int section, Qt::Orientation orientation,
                       const QVariant &value, int role = Qt::EditRole) override;
    Qt::ItemFlags flags(const QModelIndex &index) const override;
protected:
    void setupModelData(MainDbCommonItem *parent);
signals:
    void updateByDelegate(QModelIndex);
};

class MainDbTableCombineModel:public MainDbCommonViewModel{
    Q_OBJECT
public:
    MainDbTableCombineModel(MainDbManager * dbMng, QObject *parent = 0,int i=0);
    MainDbTableCombineModel(MainDbManager * dbMng, QObject *parent = 0,QModelIndex clickedItemIndex=QModelIndex());
    ~MainDbTableCombineModel(){}
    QVariant data(const QModelIndex &index, int role) const override;
    QVariant headerData(int section, Qt::Orientation orientation,
                        int role = Qt::DisplayRole) const override;
    bool setData(const QModelIndex &index, const QVariant &value,
                 int role = Qt::EditRole) override;
    bool setHeaderData(int section, Qt::Orientation orientation,
                       const QVariant &value, int role = Qt::EditRole) override;
    Qt::ItemFlags flags(const QModelIndex &index) const override;
    void setRow(int row){
        this->Row=row;
    }


protected:
    void setupModelData(MainDbCommonItem *parent);
 private:
    int Row;
    QModelIndex clickedItemIndex;
signals:
    void updateByDelegate(QModelIndex);

};

#endif // MAINDBEDITOR_H
