#include "maindbeditor.h"
#include <QMessageBox>
#include <QCloseEvent>
#include <QDebug>
#include"msgeditor.h"
#include<QTreeWidgetItem>
#include <QSplitter>
#include "tabdialog.h"
#include "tabdialogSignalMessage.h"
#include <QGridLayout>
MainDbEditor::MainDbEditor(QWidget *parent , QString  path ):
    QMainWindow(parent),
    m_mainDbManager(NULL),
    m_MsgEditorWidget(NULL)
{
    setupUi(this);
    QSplitter * splitter = new QSplitter(Qt::Horizontal,this);
    splitter->addWidget(m_treeWidget);
    splitter->addWidget(m_stackedWidget);
    QGridLayout * gridLayout = new QGridLayout;
    gridLayout->addWidget(splitter);
    centralWidget()->setLayout(gridLayout);
    m_stackedWidget->removeWidget(m_pageCom);
    m_stackedWidget->removeWidget(m_pageSignals);
    m_stackedWidget->removeWidget(m_pageMsgs);
    m_stackedWidget->addWidget(m_MsgsTableWidget);
    m_stackedWidget->addWidget(m_SignsTableWidget);
    m_stackedWidget->addWidget(m_ComTableWidget);

    m_mainDbManager = new MainDbManager();
    m_mainDbManager->loadDbFile(path);

    m_treeViewModel = new MainDbTreeViewModel(m_mainDbManager,this);
    m_treeWidget->setModel(m_treeViewModel);

    m_tblMsgModel = new MainDbTableMsgsModel(m_mainDbManager,this);
    m_MsgsTableWidget->setModel(m_tblMsgModel);
    lineEditDelegate *lineEditTestDelegate = new lineEditDelegate;
    m_MsgsTableWidget->setItemDelegate(lineEditTestDelegate);
    comboDelegate *messageFormatDelegate= new comboDelegate;
    messageFormatDelegate->listComBovalue=QString("Standard;Extended").split(";");
    m_MsgsTableWidget->setItemDelegateForColumn(2,messageFormatDelegate);
    SpinBoxDelegate *dlcMessageDelegate= new SpinBoxDelegate;
    m_MsgsTableWidget->setItemDelegateForColumn(3,dlcMessageDelegate);

    m_tblSignModel = new MainDbTableSignsModel(m_mainDbManager,this);
    m_SignsTableWidget->setModel(m_tblSignModel);
    m_SignsTableWidget->setItemDelegate(lineEditTestDelegate);
    comboDelegate *signalOderTableDelegate= new comboDelegate;
    signalOderTableDelegate->listComBovalue=QString("Intel;Motorola").split(";");
    m_SignsTableWidget->setItemDelegateForColumn(2,signalOderTableDelegate);
    comboDelegate *signalTypeTableDelegate= new comboDelegate;
    signalTypeTableDelegate->listComBovalue=QString("Signed;Unsigned;Float;Double").split(";");
    m_SignsTableWidget->setItemDelegateForColumn(3,signalTypeTableDelegate);
    checkboxDelegate * checkboxTestDelegate = new checkboxDelegate;
    m_SignsTableWidget->setItemDelegateForColumn(4,checkboxTestDelegate);
// combineTableModel
    m_tblCombineModel=new MainDbTableCombineModel(m_mainDbManager,this,0);
   // m_ComTableWidget->setModel(m_tblCombineModel);
// end combineTableModel
    m_MsgsTableWidget->setShowGrid(false);
    m_SignsTableWidget->setShowGrid(false);
    m_ComTableWidget->setShowGrid(false);

    m_MsgsTableWidget->verticalHeader()->hide();
    m_SignsTableWidget->verticalHeader()->hide();
    m_ComTableWidget->verticalHeader()->hide();

    m_MsgsTableWidget->horizontalHeader()->setDefaultAlignment(Qt::AlignLeft);
    m_SignsTableWidget->horizontalHeader()->setDefaultAlignment(Qt::AlignLeft);
    m_ComTableWidget->horizontalHeader()->setDefaultAlignment(Qt::AlignLeft);

    m_MsgsTableWidget->setContextMenuPolicy(Qt::CustomContextMenu);
    m_SignsTableWidget->setContextMenuPolicy(Qt::CustomContextMenu);
    m_ComTableWidget->setContextMenuPolicy(Qt::CustomContextMenu);
    m_treeWidget->setContextMenuPolicy(Qt::CustomContextMenu);

    connect(m_treeWidget,SIGNAL(clicked(QModelIndex)),this, SLOT(slotOneClickTree(QModelIndex)));
    connect(m_treeWidget,SIGNAL(doubleClicked(QModelIndex)),this, SLOT(slotDoubleClickTree(QModelIndex)));
    connect(m_treeWidget,SIGNAL(customContextMenuRequested(QPoint)),this, SLOT(slotContextMenuTreeWidget(QPoint)));

    connect(m_MsgsTableWidget,SIGNAL(clicked(QModelIndex)),this, SLOT(slotOneClickMsgsTab(QModelIndex)));
    connect(m_MsgsTableWidget,SIGNAL(doubleClicked(QModelIndex)),this, SLOT(slotDoubleClickMsgsTab(QModelIndex)));
    connect(m_MsgsTableWidget,SIGNAL(customContextMenuRequested(QPoint)),this, SLOT(slotContextMenuMsgTable(QPoint)));

    connect(m_SignsTableWidget,SIGNAL(customContextMenuRequested(QPoint)),this, SLOT(slotContextMenuSignsTable(QPoint)));
    connect(m_SignsTableWidget,SIGNAL(doubleClicked(QModelIndex)),this, SLOT(slotDoubleClickSignsTab(QModelIndex)));
    connect(m_tblMsgModel,SIGNAL(dataChanged(QModelIndex,QModelIndex,QVector<int>)),
            m_treeViewModel,SLOT(changeByTblMess(QModelIndex,QModelIndex,QVector<int>)));
    connect(m_tblSignModel,SIGNAL(dataChanged(QModelIndex,QModelIndex,QVector<int>)),
            m_treeViewModel,SLOT(changeByTblSig(QModelIndex,QModelIndex,QVector<int>)));
//    connect(m_tblCombineModel,SIGNAL(dataChanged(QModelIndex,QModelIndex,QVector<int>)),
//            m_treeViewModel,SLOT(changeByCombTbl(QModelIndex,QModelIndex,QVector<int>)));
    connect(m_tblMsgModel,SIGNAL(updateByDelegate(QModelIndex)),
            m_mainDbManager,SLOT(updateByDelegateOnMessTbl(QModelIndex)));
    connect(m_tblSignModel,SIGNAL(updateByDelegate(QModelIndex)),
            m_mainDbManager,SLOT(updateByDelegateOnSigTbl(QModelIndex)));
    connect(m_tblCombineModel,SIGNAL(updateByDelegate(QModelIndex)),
            this,SLOT(updateByDelegateOnCombineTbl(QModelIndex)));


    //connect(m_ComTableWidget,SIGNAL(doubleClicked(QModelIndex)),this, SLOT(slotDoubleClickCombTab(QModelIndex)));

    connect(m_ComTableWidget,SIGNAL(customContextMenuRequested(QPoint)),this, SLOT(slotContextMenuCombTable(QPoint)));
    connect(m_ComTableWidget,SIGNAL(doubleClicked(QModelIndex)),this, SLOT(slotDoubleClickCombTab(QModelIndex)));
    CANSignal *newSign = new CANSignal;
    newSign->m_Name = QString("dont_delegate_me!");
    newSign->m_Length =8;
    newSign->m_ValueType = E_CANSignalSign_UnSigned;
    newSign->m_ByteOrder = E_CANByteOrder_Motorola;
    newSign->m_Factor.dValue = 1;
    newSign->m_Offset.dValue = 0;
    newSign->m_Min.dValue =0;
    newSign->m_Max.dValue =100;
    newSign->m_InitValue.dValue = 0;
    qDebug()<<"size = "<<m_mainDbManager->m_CANSignals.size();
    m_mainDbManager->m_CANSignals.append(const_cast<CANSignal*>(newSign));
    CANSignalInMessage newMessSig;
    newMessSig.m_Signal=newSign;
    newMessSig.m_StartBit=0;
    m_mainDbManager->m_CANMessages.at(0)->m_Signals.append(newMessSig);
    qDebug()<<"size = "<<m_mainDbManager->m_CANSignals.size();
    //MainDbCommonItem *item ;

    QVector<QVariant*> data;
    data<<(new QVariant("change or die"));
    qDebug()<<data.at(0)->toString();
}

MainDbEditor::~MainDbEditor()
{
    /*TODO: remove db list*/
    if(m_mainDbManager) delete m_mainDbManager;
    if(m_MsgEditorWidget) delete m_MsgEditorWidget;
}

void MainDbEditor::slotOneClickTree(QModelIndex index){
    switch (m_treeViewModel->getItem(index)->getType()) {

    case E_DbItemType_Header:
        if(m_treeViewModel->getItem(index)->data(0) == QString("Messages")){
            m_MsgsTableWidget->setVisible(true);
            m_SignsTableWidget->setVisible(false);
            m_ComTableWidget->setVisible(false);
            delete m_tblMsgModel;
            m_tblMsgModel = new MainDbTableMsgsModel(m_mainDbManager,this);
            m_MsgsTableWidget->setModel(m_tblMsgModel);
            lineEditDelegate *lineEditTestDelegate = new lineEditDelegate;
            m_MsgsTableWidget->setItemDelegate(lineEditTestDelegate);
            comboDelegate *messageFormatDelegate= new comboDelegate;
            messageFormatDelegate->listComBovalue=QString("Standard;Extended").split(";");
            m_MsgsTableWidget->setItemDelegateForColumn(2,messageFormatDelegate);
            SpinBoxDelegate *dlcMessageDelegate= new SpinBoxDelegate;
            m_MsgsTableWidget->setItemDelegateForColumn(3,dlcMessageDelegate);
            connect(m_tblMsgModel,SIGNAL(dataChanged(QModelIndex,QModelIndex,QVector<int>)),
                    m_treeViewModel,SLOT(changeByTblMess(QModelIndex,QModelIndex,QVector<int>)));

        //    connect(m_tblCombineModel,SIGNAL(dataChanged(QModelIndex,QModelIndex,QVector<int>)),
        //            m_treeViewModel,SLOT(changeByCombTbl(QModelIndex,QModelIndex,QVector<int>)));
            connect(m_tblMsgModel,SIGNAL(updateByDelegate(QModelIndex)),
                    m_mainDbManager,SLOT(updateByDelegateOnMessTbl(QModelIndex)));



        }else if(m_treeViewModel->getItem(index)->data(0) == QString("Signals")){
            m_MsgsTableWidget->setVisible(false);
            m_SignsTableWidget->setVisible(true);
            m_ComTableWidget->setVisible(false);
            delete m_tblSignModel;
            m_tblSignModel = new MainDbTableSignsModel(m_mainDbManager,this);
            m_SignsTableWidget->setModel(m_tblSignModel);
            lineEditDelegate *lineEditTestDelegate = new lineEditDelegate;
            m_SignsTableWidget->setItemDelegate(lineEditTestDelegate);
            comboDelegate *signalOderTableDelegate= new comboDelegate;
            signalOderTableDelegate->listComBovalue=QString("Intel;Motorola").split(";");
            m_SignsTableWidget->setItemDelegateForColumn(2,signalOderTableDelegate);
            comboDelegate *signalTypeTableDelegate= new comboDelegate;
            signalTypeTableDelegate->listComBovalue=QString("Signed;Unsigned;Float;Double").split(";");
            m_SignsTableWidget->setItemDelegateForColumn(3,signalTypeTableDelegate);
            checkboxDelegate * checkboxTestDelegate = new checkboxDelegate;
            m_SignsTableWidget->setItemDelegateForColumn(4,checkboxTestDelegate);
            connect(m_tblSignModel,SIGNAL(dataChanged(QModelIndex,QModelIndex,QVector<int>)),
                    m_treeViewModel,SLOT(changeByTblSig(QModelIndex,QModelIndex,QVector<int>)));
            connect(m_tblSignModel,SIGNAL(updateByDelegate(QModelIndex)),
                    m_mainDbManager,SLOT(updateByDelegateOnSigTbl(QModelIndex)));
        }
        break;

     case E_DbItemType_Signal:
    {
        //delete m_tblCombineModel;
        delete m_tblCombineModel;
        m_tblCombineModel=new MainDbTableCombineModel(m_mainDbManager,this,index);
        m_ComTableWidget->setModel(m_tblCombineModel);
        comboDelegate *signalOderTableDelegate= new comboDelegate;
        signalOderTableDelegate->listComBovalue=QString("Intel;Motorola").split(";");
        m_ComTableWidget->setItemDelegateForColumn(5,signalOderTableDelegate);
        comboDelegate *signalTypeTableDelegate= new comboDelegate;
        signalTypeTableDelegate->listComBovalue=QString("Signed;Unsigned;Float;Double").split(";");
        m_ComTableWidget->setItemDelegateForColumn(6,signalTypeTableDelegate);
        connect(m_tblCombineModel,SIGNAL(updateByDelegate(QModelIndex)),
                this,SLOT(updateTreeViewByDelegateOnCombineTbl(QModelIndex)));
        connect(m_tblCombineModel,SIGNAL(updateByDelegate(QModelIndex)),
                this,SLOT(updateByDelegateOnCombineTbl(QModelIndex)));
        m_MsgsTableWidget->setVisible(false);
        m_SignsTableWidget->setVisible(false);
        m_ComTableWidget->setVisible(true);
        break;
    }

     case E_DbItemType_SignalInMessage:
    {
        //delete m_tblCombineModel;
        m_tblCombineModel=new MainDbTableCombineModel(m_mainDbManager,this,index);
        m_ComTableWidget->setModel(m_tblCombineModel);
            comboDelegate *signalOderTableDelegate= new comboDelegate;
            signalOderTableDelegate->listComBovalue=QString("Intel;Motorola").split(";");
            m_ComTableWidget->setItemDelegateForColumn(5,signalOderTableDelegate);
            comboDelegate *signalTypeTableDelegate= new comboDelegate;
            signalTypeTableDelegate->listComBovalue=QString("Signed;Unsigned;Float;Double").split(";");
            m_ComTableWidget->setItemDelegateForColumn(6,signalTypeTableDelegate);
            connect(m_tblCombineModel,SIGNAL(updateByDelegate(QModelIndex)),
                    this,SLOT(updateTreeViewByDelegateOnCombineTbl(QModelIndex)));
            connect(m_tblCombineModel,SIGNAL(updateByDelegate(QModelIndex)),
                    this,SLOT(updateByDelegateOnCombineTbl(QModelIndex)));
            m_MsgsTableWidget->setVisible(false);
            m_SignsTableWidget->setVisible(false);
            m_ComTableWidget->setVisible(true);
            break;
    }

     case E_DbItemType_Message:{
        //delete m_tblCombineModel;
        m_tblCombineModel=new MainDbTableCombineModel(m_mainDbManager,this,index);
        m_ComTableWidget->setModel(m_tblCombineModel);
        comboDelegate *signalOderTableDelegate= new comboDelegate;
        signalOderTableDelegate->listComBovalue=QString("Intel;Motorola").split(";");
        m_ComTableWidget->setItemDelegateForColumn(5,signalOderTableDelegate);
        comboDelegate *signalTypeTableDelegate= new comboDelegate;
        signalTypeTableDelegate->listComBovalue=QString("Signed;Unsigned;Float;Double").split(";");
        m_ComTableWidget->setItemDelegateForColumn(6,signalTypeTableDelegate);
        connect(m_tblCombineModel,SIGNAL(updateByDelegate(QModelIndex)),
                this,SLOT(updateTreeViewByDelegateOnCombineTbl(QModelIndex)));
        connect(m_tblCombineModel,SIGNAL(updateByDelegate(QModelIndex)),
                this,SLOT(updateByDelegateOnCombineTbl(QModelIndex)));
        m_MsgsTableWidget->setVisible(false);
        m_SignsTableWidget->setVisible(false);
        m_ComTableWidget->setVisible(true);
        break;
    }
    default:
        break;
    }
    m_MsgsTableWidget->resize(m_stackedWidget->size());
    m_SignsTableWidget->resize(m_stackedWidget->size());
    m_ComTableWidget->resize(m_stackedWidget->size());
}

void MainDbEditor::slotDoubleClickTree(QModelIndex index){
    switch (m_treeViewModel->getItem(index)->getType()) {
    case E_DbItemType_Header:
    {
        //TODO: collapse/expand
    }
        break;
    case E_DbItemType_Message:
    {
        //TODO: Open editor message
        qDebug()<<"open mesage editor";
//       QModelIndex table_index= m_MsgsTableWidget->model()->index(index.row(),index.column());
//       MainDbCommonItem *item = static_cast<MainDbCommonItem*>( table_index.internalPointer());
       MainDbCommonItem *item = static_cast<MainDbCommonItem*>(index.internalPointer());
       m_MsgEditorWidget = new MsgEditor(item);
       connect(m_MsgEditorWidget,SIGNAL(editMessage(QString)),this,SLOT(slotEditMess(QString)));
      // m_MsgEditorWidget->atTab->
       m_MsgEditorWidget->show();
       m_MsgEditorWidget->setWindowIcon(QPixmap(":/logo.png"));
    }
        break;
    case E_DbItemType_Signal:
    {
        //TODO: Open editor signal
         QModelIndex table_index= m_SignsTableWidget->model()->index(index.row(),index.column());
         MainDbCommonItem *item = static_cast<MainDbCommonItem*>( table_index.internalPointer());
         m_SignalEditorWidget = new TabDialogMess(item);
         m_SignalEditorWidget->show();
         m_SignalEditorWidget->setWindowIcon(QPixmap(":/logo.png"));
    }
        break;
    case E_DbItemType_SignalInMessage:
    {
        //TODO: Open editor signal in message
        MainDbCommonItem *item = static_cast<MainDbCommonItem*>(index.internalPointer());
        m_SignMsgEditorWidget = new TabDialogSignalMessage(item);
        m_SignMsgEditorWidget->show();
        m_SignMsgEditorWidget->setWindowIcon(QPixmap(":/logo.png"));
    }
        break;
    default:
        break;
    }

}

void MainDbEditor::slotOneClickMsgsTab(QModelIndex index)
{
    //    qDebug() << index.column() << "x" << index.row();
}


void  MainDbEditor::slotContextMenuMsgTable(QPoint  point)
{
    QMenu *rightClickMenu = new QMenu(this);

    QAction *actionEdit = new QAction(QIcon(":icons/edit.png"),QString("Edit"),this);
    //    connect(actionEdit, SIGNAL(triggered()),  this, SLOT(slotOpenMessageEditor()));

    QAction *actionRemove = new QAction(QIcon(":icons/remove.png"),QString("Remove"),this);
    //    connect(actionRemove, SIGNAL(triggered()),  this, SLOT(slotRemoveMessage()));

    rightClickMenu->addAction(actionEdit);
    rightClickMenu->addSeparator();
    rightClickMenu->addAction(actionRemove);

    QPoint globalPos = m_MsgsTableWidget->mapToGlobal(point);
    rightClickMenu->popup(globalPos);
}

void MainDbEditor::slotDoubleClickMsgsTab(QModelIndex index)
{
    MainDbCommonItem *item = static_cast<MainDbCommonItem*>(index.internalPointer());
    m_MsgEditorWidget = new MsgEditor(item);
    m_MsgEditorWidget->show();
}

void MainDbEditor::slotOneClickSignsTab(QModelIndex index)
{

}

void MainDbEditor::slotDoubleClickSignsTab(QModelIndex index)
{
    MainDbCommonItem *item = static_cast<MainDbCommonItem*>(index.internalPointer());
    m_SignalEditorWidget = new TabDialogMess(item);
    m_SignalEditorWidget->show();
}

void MainDbEditor::slotOneClickCombTab(QModelIndex index)
{

}

void MainDbEditor::slotDoubleClickCombTab(QModelIndex index)
{
    MainDbCommonItem *item = static_cast<MainDbCommonItem*>(index.internalPointer());
   m_SignalEditorWidget = new TabDialogMess(item);
   m_SignalEditorWidget->show();
}

void  MainDbEditor::slotContextMenuSignsTable(QPoint  point)
{
    QMenu *rightClickMenu = new QMenu(this);

    QAction *actionEdit = new QAction(QIcon(":icons/edit.png"),QString("Edit"),this);
    //    connect(actionEdit, SIGNAL(triggered()),  this, SLOT(slotOpenSignalEditor()));

    QAction *actionRemove = new QAction(QIcon(":icons/remove.png"),QString("Remove"),this);
    //    connect(actionRemove, SIGNAL(triggered()),  this, SLOT(slotRemoveSignal()));

    rightClickMenu->addAction(actionEdit);
    rightClickMenu->addSeparator();
    rightClickMenu->addAction(actionRemove);

    QPoint globalPos = m_MsgsTableWidget->mapToGlobal(point);

    rightClickMenu->popup(globalPos);
}

void  MainDbEditor::slotContextMenuCombTable(QPoint  point)
{

    QMenu *rightClickMenu = new QMenu(this);

    QAction *actionEdit = new QAction(QIcon(":icons/edit.png"),QString("Edit"),this);
    //    connect(actionEdit, SIGNAL(triggered()),  this, SLOT(slotOpenSignalInMsgEditor()));

    QAction *actionRemove = new QAction(QIcon(":icons/remove.png"),QString("Remove"),this);
    //    connect(actionRemove, SIGNAL(triggered()),  this, SLOT(slotRemoveSignalInMsg()));

    rightClickMenu->addAction(actionEdit);
    rightClickMenu->addSeparator();
    rightClickMenu->addAction(actionRemove);

    QPoint globalPos = m_MsgsTableWidget->mapToGlobal(point);

    rightClickMenu->popup(globalPos);

}

void  MainDbEditor::slotContextMenuTreeWidget(QPoint  point)
{
    QMenu *rightClickMenu = new QMenu(this);

    switch (m_treeViewModel->getItem(m_treeWidget->selectionModel()->currentIndex())->getType()) {
    case E_DbItemType_Header:
    {
        if(m_treeViewModel->getItem(m_treeWidget->selectionModel()->currentIndex())->data(0) == QString("Messages")){
            QAction *actionNew = new QAction(QIcon(":icons/new.png"),QString("New message"),this);
            //    connect(actionEdit, SIGNAL(triggered()),  this, SLOT(slotOpenSignalInMsgEditor()));

            QAction *actionPaste = new QAction(QIcon(":icons/paste.png"),QString("Paste"),this);
            //    connect(actionRemove, SIGNAL(triggered()),  this, SLOT(slotRemoveSignalInMsg()));
            actionPaste->setEnabled(false);
            rightClickMenu->addAction(actionNew);
            rightClickMenu->addSeparator();
            rightClickMenu->addAction(actionPaste);
//            QPoint globalPos = m_treeWidget->mapToGlobal(point);
//            rightClickMenu->popup(globalPos);
            rightClickMenu->popup(point);
        }else if(m_treeViewModel->getItem(m_treeWidget->selectionModel()->currentIndex())->data(0) == QString("Signals")){
            QAction *actionNew = new QAction(QIcon(":icons/new.png"),QString("New signal"),this);
            //    connect(actionEdit, SIGNAL(triggered()),  this, SLOT(slotOpenSignalInMsgEditor()));

            QAction *actionPaste = new QAction(QIcon(":icons/paste.png"),QString("Paste"),this);
            //    connect(actionRemove, SIGNAL(triggered()),  this, SLOT(slotRemoveSignalInMsg()));
            actionPaste->setEnabled(false);
            rightClickMenu->addAction(actionNew);
            rightClickMenu->addSeparator();
            rightClickMenu->addAction(actionPaste);
            QPoint globalPos = m_treeWidget->mapToGlobal(point);
            rightClickMenu->popup(globalPos);
        }
    }
        break;
    case E_DbItemType_Message:
    {
        QAction *actionNew = new QAction(QIcon(":icons/new.png"),QString("New message"),this);
        //connect(actionNew, SIGNAL(triggered()),  this, SLOT(slotOpenMessageEditor()));

        QAction *actionEdit = new QAction(QIcon(":icons/edit.png"),QString("Edit message"),this);
        connect(actionEdit, SIGNAL(triggered()),  this, SLOT(slotOpenMessageEditor()));

        QAction *actionCopy= new QAction(QIcon(":icons/copy.png"),QString("Copy"),this);
        //    connect(actionRemove, SIGNAL(triggered()),  this, SLOT(slotRemoveSignalInMsg()));

        QAction *actionPaste = new QAction(QIcon(":icons/paste.png"),QString("Paste"),this);
        //    connect(actionRemove, SIGNAL(triggered()),  this, SLOT(slotRemoveSignalInMsg()));
        actionPaste->setEnabled(false);

        QAction *actionDelete = new QAction(QIcon(":icons/remove.png"),QString("Delete"),this);
        //    connect(actionRemove, SIGNAL(triggered()),  this, SLOT(slotRemoveSignalInMsg()));

        rightClickMenu->addAction(actionNew);
        rightClickMenu->addSeparator();

        rightClickMenu->addAction(actionEdit);
        rightClickMenu->addSeparator();

        rightClickMenu->addAction(actionCopy);
        rightClickMenu->addAction(actionPaste);
        rightClickMenu->addSeparator();

        rightClickMenu->addAction(actionDelete);

        QPoint globalPos = m_treeWidget->mapToGlobal(point);
        rightClickMenu->popup(globalPos);
    }
        break;

    case E_DbItemType_Signal:
    {
        QAction *actionNew = new QAction(QIcon(":icons/new.png"),QString("New signal"),this);
        //    connect(actionEdit, SIGNAL(triggered()),  this, SLOT(slotOpenSignalInMsgEditor()));

        QAction *actionEdit = new QAction(QIcon(":icons/edit.png"),QString("Edit signal"),this);
         connect(actionEdit, SIGNAL(triggered()),  this, SLOT(slotOpenSignalEditor()));
        //    connect(actionRemove, SIGNAL(triggered()),  this, SLOT(slotRemoveSignalInMsg()));

        QAction *actionCopy= new QAction(QIcon(":icons/copy.png"),QString("Copy"),this);
        //    connect(actionRemove, SIGNAL(triggered()),  this, SLOT(slotRemoveSignalInMsg()));

        QAction *actionPaste = new QAction(QIcon(":icons/paste.png"),QString("Paste"),this);
        //    connect(actionRemove, SIGNAL(triggered()),  this, SLOT(slotRemoveSignalInMsg()));
        actionPaste->setEnabled(false);

        QAction *actionDelete = new QAction(QIcon(":icons/remove.png"),QString("Delete"),this);
        //    connect(actionRemove, SIGNAL(triggered()),  this, SLOT(slotRemoveSignalInMsg()));

        rightClickMenu->addAction(actionNew);
        rightClickMenu->addSeparator();

        rightClickMenu->addAction(actionEdit);
        rightClickMenu->addSeparator();

        rightClickMenu->addAction(actionCopy);
        rightClickMenu->addAction(actionPaste);
        rightClickMenu->addSeparator();

        rightClickMenu->addAction(actionDelete);

        QPoint globalPos = m_treeWidget->mapToGlobal(point);
        rightClickMenu->popup(globalPos);
    }
        break;

    case E_DbItemType_SignalInMessage:
    {
        QAction *actionEdit = new QAction(QIcon(":icons/edit.png"),QString("Edit signal"),this);
        connect(actionEdit, SIGNAL(triggered()),  this, SLOT(slotOpenSignalEditor()));
        //    connect(actionRemove, SIGNAL(triggered()),  this, SLOT(slotRemoveSignalInMsg()));

        QAction *actionCopy= new QAction(QIcon(":icons/copy.png"),QString("Copy"),this);
        //    connect(actionRemove, SIGNAL(triggered()),  this, SLOT(slotRemoveSignalInMsg()));

        QAction *actionDelete = new QAction(QIcon(":icons/remove.png"),QString("Remove"),this);
        //    connect(actionRemove, SIGNAL(triggered()),  this, SLOT(slotRemoveSignalInMsg()));

        rightClickMenu->addAction(actionEdit);
        rightClickMenu->addSeparator();

        rightClickMenu->addAction(actionCopy);
        rightClickMenu->addSeparator();

        rightClickMenu->addAction(actionDelete);

        QPoint globalPos = m_treeWidget->mapToGlobal(point);
        rightClickMenu->popup(globalPos);
    }
        break;
    default:
        break;
    }
}

void MainDbEditor::updateByDelegateOnCombineTbl(QModelIndex index)
{
    qDebug()<<"call slot respone";
MainDbCommonItem * tblItem = static_cast<MainDbCommonItem*>(index.internalPointer());
QModelIndex  treeIndex= this->m_treeWidget->currentIndex();
MainDbCommonItem * treeItem = static_cast<MainDbCommonItem*>(treeIndex.internalPointer());
if(treeItem->getType()==E_DbItemType_SignalInMessage)
    {
        QModelIndex  messIndex= treeIndex.parent();
        CANMessage *editMess= this->m_mainDbManager->getMessagesList().at(messIndex.row());
        CANSignalInMessage editMessSig= this->m_mainDbManager->getMessagesList().at(messIndex.row())->m_Signals.at(treeIndex.row());
        CANSignal *editSignal= this->m_mainDbManager->getMessagesList().at(messIndex.row())->m_Signals.at(treeIndex.row()).m_Signal;
        editSignal->m_Name=tblItem->data(0).toString();
        qDebug()<<"edit signal name "<<editSignal->m_Name;
        editSignal->m_Length=tblItem->data(1).toUInt();

        editSignal->m_ByteOrder=(E_CANByteOrder)(tblItem->data(5).toString().compare("Intel")?1:0);
        qDebug()<<"edit signal byorder "<<(int)editSignal->m_ByteOrder;
        editMess->m_Name=tblItem->data(2).toString();
        editMessSig.m_StartBit=tblItem->data(4).toUInt();
        //editSignal->m_ValueType=(E_CANSignalSign)tblItem->data(6).toUInt();
        if(!tblItem->data(6).toString().compare("Signed")){
            editSignal->m_ValueType=(E_CANSignalSign)0;
        }else if(!tblItem->data(6).toString().compare("Unsigned")){
            editSignal->m_ValueType=(E_CANSignalSign)1;
        }else if(!tblItem->data(6).toString().compare("Float")){
            editSignal->m_ValueType=(E_CANSignalSign)2;
        }else{
            editSignal->m_ValueType=(E_CANSignalSign)3;
        }
        editSignal->m_InitValue.dValue=tblItem->data(7).toDouble();
        editSignal->m_Factor.dValue=tblItem->data(8).toDouble();
        editSignal->m_Offset.dValue=tblItem->data(9).toDouble();
        editSignal->m_Min.dValue=tblItem->data(10).toDouble();
        editSignal->m_Max.dValue=tblItem->data(11).toDouble();
        editSignal->m_Comment=tblItem->data(12).toString();
        // we must find another solution to replace for this temporary one.
//        m_treeViewModel = new MainDbTreeViewModel(m_mainDbManager,this);
//        m_treeWidget->setModel(m_treeViewModel);
//        m_tblMsgModel= new MainDbTableMsgsModel(m_mainDbManager,this);
//        m_MsgsTableWidget->setModel(m_tblMsgModel);
//        m_tblSignModel= new MainDbTableSignsModel(m_mainDbManager,this);
//        m_SignsTableWidget->setModel(m_tblSignModel);



//        QModelIndex par =QModelIndex();
//        MainDbCommonItem *parItem = static_cast<MainDbCommonItem*> (par.internalPointer());
//        m_treeViewModel->setupModelData(parItem);

    }
else if(treeItem->getType()==E_DbItemType_Message)
    {
    CANMessage *editMess= this->m_mainDbManager->getMessagesList().at(treeIndex.row());
    CANSignalInMessage editMessSig= this->m_mainDbManager->getMessagesList().at(treeIndex.row())->m_Signals.at(index.row());
    CANSignal *editSignal= this->m_mainDbManager->getMessagesList().at(treeIndex.row())->m_Signals.at(index.row()).m_Signal;
    editSignal->m_Name=tblItem->data(0).toString();
    qDebug()<<"edit signal name "<<editSignal->m_Name;
    editSignal->m_Length=tblItem->data(1).toUInt();
    editSignal->m_ByteOrder=(E_CANByteOrder)(tblItem->data(5).toString().compare("Intel")?1:0);
    qDebug()<<"edit signal byorder "<<editSignal->m_ByteOrder;
    editMess->m_Name=tblItem->data(2).toString();
    editMessSig.m_StartBit=tblItem->data(4).toUInt();
    //editSignal->m_ValueType=(E_CANSignalSign)tblItem->data(6).toUInt();
    if(!tblItem->data(6).toString().compare("Signed")){
        editSignal->m_ValueType=(E_CANSignalSign)0;
    }else if(!tblItem->data(6).toString().compare("Unsigned")){
        editSignal->m_ValueType=(E_CANSignalSign)1;
    }else if(!tblItem->data(6).toString().compare("Float")){
        editSignal->m_ValueType=(E_CANSignalSign)2;
    }else{
        editSignal->m_ValueType=(E_CANSignalSign)3;
    }
    editSignal->m_InitValue.dValue=tblItem->data(7).toDouble();
    editSignal->m_Factor.dValue=tblItem->data(8).toDouble();
    editSignal->m_Offset.dValue=tblItem->data(9).toDouble();
    editSignal->m_Min.dValue=tblItem->data(10).toDouble();
    editSignal->m_Max.dValue=tblItem->data(11).toDouble();
    editSignal->m_Comment=tblItem->data(12).toString();
    // we must find another solution to replace for this temporary one.
//    m_treeViewModel = new MainDbTreeViewModel(m_mainDbManager,this);
//    m_treeWidget->setModel(m_treeViewModel);
//    m_tblMsgModel= new MainDbTableMsgsModel(m_mainDbManager,this);
//    m_MsgsTableWidget->setModel(m_tblMsgModel);
//    m_tblSignModel= new MainDbTableSignsModel(m_mainDbManager,this);
//    m_SignsTableWidget->setModel(m_tblSignModel);

    }
else if(treeItem->getType()==E_DbItemType_Signal)
    {
        CANSignal *editSignal= this->m_mainDbManager->getSignalsList().at(treeIndex.row());
        editSignal->m_Name=tblItem->data(0).toString();
        editSignal->m_Length=tblItem->data(1).toUInt();
        editSignal->m_ByteOrder=(E_CANByteOrder)(tblItem->data(5).toString().compare("Intel")?1:0);
       // editSignal->m_ValueType=(E_CANSignalSign)tblItem->data(6).toUInt();
        qDebug()<<"sign = "<<tblItem->data(6).toString();
        if(!tblItem->data(6).toString().compare("Signed")){
            editSignal->m_ValueType=(E_CANSignalSign)0;
        }else if(!tblItem->data(6).toString().compare("Unsigned")){
            editSignal->m_ValueType=(E_CANSignalSign)1;
        }else if(!tblItem->data(6).toString().compare("Float")){
            editSignal->m_ValueType=(E_CANSignalSign)2;
        }else{
            editSignal->m_ValueType=(E_CANSignalSign)3;
        }
        editSignal->m_InitValue.dValue=tblItem->data(7).toDouble();
        editSignal->m_Factor.dValue=tblItem->data(8).toDouble();
        editSignal->m_Offset.dValue=tblItem->data(9).toDouble();
        editSignal->m_Min.dValue=tblItem->data(10).toDouble();
        editSignal->m_Max.dValue=tblItem->data(11).toDouble();
        editSignal->m_Comment=tblItem->data(12).toString();
        // we must find another solution to replace for this temporary one.
//        m_treeViewModel = new MainDbTreeViewModel(m_mainDbManager,this);
//        m_treeWidget->setModel(m_treeViewModel);
//        m_tblMsgModel= new MainDbTableMsgsModel(m_mainDbManager,this);
//        m_MsgsTableWidget->setModel(m_tblMsgModel);
//        m_tblSignModel= new MainDbTableSignsModel(m_mainDbManager,this);
//        m_SignsTableWidget->setModel(m_tblSignModel);
}
}

void MainDbEditor::updateTreeViewByDelegateOnCombineTbl(QModelIndex index)
{
// update tree model view to map with any changing from table model view
    qDebug()<<"connected!";
    MainDbCommonItem *tblItem = static_cast<MainDbCommonItem*>(index.internalPointer());
    QModelIndex currentIndex=this->m_treeWidget->currentIndex();
    MainDbCommonItem *currentItem =static_cast<MainDbCommonItem*>(currentIndex.internalPointer());
    if(currentItem->getType()==E_DbItemType_Message){
//        QModelIndex childIndex = currentIndex.child(index.row(),index.column());
//        MainDbCommonItem *childItem = static_cast<MainDbCommonItem*>(childIndex.internalPointer());
        if(index.column()==2){
            currentItem->setData(0,tblItem->data(index.column()));
        }else{
        MainDbCommonItem *childItem=currentItem->child(index.row());
        childItem->setData(index.column(),tblItem->data(index.column()));
        }

    }
    if(currentItem->getType()==E_DbItemType_SignalInMessage){
        if(index.column()==2){
            MainDbCommonItem *parentItem=currentItem->parent();
            parentItem->setData(0,tblItem->data(index.column()));
        }else{
        currentItem->setData(index.column(),tblItem->data(index.column()));
        }

    }
    if(currentItem->getType()==E_DbItemType_Signal){
        if(index.column()!=2)
        currentItem->setData(index.column(),tblItem->data(index.column()));
    }


}

void MainDbEditor::slotEditMess(QString messName)
{
    qDebug()<<"hehe";
QModelIndex messIndex= this->m_treeWidget->currentIndex();
MainDbCommonItem *messItem = static_cast<MainDbCommonItem*> (messIndex.internalPointer());
messItem->setData(0,messName);
QModelIndex tblIndex=this->m_MsgsTableWidget->currentIndex();
MainDbCommonItem * tablItem = static_cast<MainDbCommonItem*>(tblIndex.internalPointer());
tablItem->setData(0,messName);

}

void MainDbEditor::closeEvent(QCloseEvent *event)
{
    //TODO: need to check change before asking
    QMessageBox::StandardButton resBtn = QMessageBox::question( this, "CANdb Editor",
                                                                tr("Do you want to save changes?\n"),
                                                                QMessageBox::Cancel | QMessageBox::No | QMessageBox::Yes,
                                                                QMessageBox::Cancel);
    if (resBtn == QMessageBox::Yes) {
        //TODO: Saving to database file
        event->accept();
    } else if (resBtn == QMessageBox::Cancel) {
        event->ignore();
    }else{
        //TODO: do not savingdb
        event->accept();
    }
}

void MainDbEditor::slotLoadDb(QString & path)
{
    /*TODO: remove db list*/
}

void MainDbEditor::slotSaveDb(QString & path)
{

}

void MainDbEditor::slotOpenMessageEditor()
{
    slotDoubleClickTree(m_treeWidget->currentIndex());
}

void MainDbEditor::slotOpenSignalEditor()
{
    slotDoubleClickTree(m_treeWidget->currentIndex());
}

MainDbManager::MainDbManager()
{

}

MainDbManager::~MainDbManager()
{

}

bool MainDbManager::slotAddMessage(CANMessage & message)
{

}

bool MainDbManager::slotAddSignal(CANSignal & signal)
{

}

bool MainDbManager::slotAddSignal2Message(CANSignal & signal)
{

}

void MainDbManager::updateByDelegateOnMessTbl(QModelIndex index)
{
MainDbCommonItem * tblItem = static_cast<MainDbCommonItem *>(index.internalPointer());
CANMessage * editMessage =static_cast<CANMessage*>( m_CANMessages.at(index.row()));
editMessage->m_Name=tblItem->data(0).toString();
editMessage->m_ID=tblItem->data(1).toUInt();
editMessage->m_IdType=(E_CANMsgIDType)tblItem->data(2).toInt();
editMessage->m_Length=tblItem->data(3).toUInt();

}

void MainDbManager::updateByDelegateOnSigTbl(QModelIndex index)
{
    MainDbCommonItem * tblItem = static_cast<MainDbCommonItem *>(index.internalPointer());
    CANSignal * editSignal =static_cast<CANSignal*>( m_CANSignals.at(index.row()));
    editSignal->m_Name=tblItem->data(0).toString();
    editSignal->m_Length=tblItem->data(1).toUInt();
    editSignal->m_ByteOrder=(E_CANByteOrder)tblItem->data(2).toInt();
    editSignal->m_ValueType=(E_CANSignalSign)tblItem->data(3).toUInt();
    editSignal->m_InitValue.dValue=tblItem->data(4).toDouble();
    editSignal->m_Factor.dValue=tblItem->data(5).toDouble();
    editSignal->m_Offset.dValue=tblItem->data(6).toDouble();
    editSignal->m_Min.dValue=tblItem->data(7).toDouble();
    editSignal->m_Max.dValue=tblItem->data(8).toDouble();
    editSignal->m_Comment=tblItem->data(9).toString();
}

QVector<CANSignalInMessage> MainDbManager::getSignalsInMessage(QString & messageName)
{
    QVector<CANSignalInMessage> ret;
    ret.empty();
    CANMessage * item;
    for(int i = 0; i< m_CANMessages.size();i++)
    {
        item = m_CANMessages.at(i);
        if(item && item->m_Name == messageName){
            ret = item->m_Signals;
        }
    }
    return ret;
}
bool compareSignal(CANSignal *newSig,CANSignal *oldSig){
    if(newSig->m_Name.compare(oldSig->m_Name)) return false;
    if(newSig->m_ByteOrder!=oldSig->m_ByteOrder) return false;
    //if(newSig->m_Factor!=oldSig->m_Factor) return false;
    if(newSig->m_Length!=oldSig->m_Length) return false;
    //if(newSig->m_Offset!=oldSig->m_Offset) return false;
    if(newSig->m_ValueType!=oldSig->m_ValueType) return false;
    return true;
}

QVector<CANMessagesOfSignal> MainDbManager::getMessagesOfSignal(int index)
{
    QVector<CANMessagesOfSignal> ret;
    CANMessagesOfSignal newItem;
    ret.empty();
    if(index>= m_CANSignals.size()){
        return ret;
    }
    CANSignal * signal = m_CANSignals.at(index);
    CANMessage * item;

    for(int i = 0; i< m_CANMessages.size();i++)
    {
        item = m_CANMessages.at(i);
        for (int j=0; j<item->m_Signals.size();j++){
            qDebug()<<signal->m_Name;
            qDebug()<<const_cast<CANSignal*>(item->m_Signals.at(j).m_Signal)->m_Name;
            if(compareSignal(const_cast<CANSignal*>(item->m_Signals.at(j).m_Signal),signal))
            {
                newItem.m_msgName = item->m_Name;
                newItem.m_StartBit = item->m_Signals.at(j).m_StartBit;
                ret.append(newItem);
            }
        }
    }
    return ret;
}

void MainDbManager::loadDbFile(QString & path)
{
    if(path.isEmpty()) return;
    m_CANMessages.clear();
    m_CANSignals.clear();
    CANMessage * newMsg=NULL;
    CANSignal * newSign=NULL;
    QFile file(path);
    file.open(QIODevice::ReadOnly);
    QString string = file.readAll();
    QStringList lines = string.split(QString("\n"),QString::SkipEmptyParts);
    foreach (QString line, lines) {
        QStringList lineItems =  line.split(QRegularExpression(":| |@|\\||\\(|\\)|\\[|\\]|,|\\+"),QString::SkipEmptyParts);
        /*SG_ PWM_CVVAL : 48|16@1+ (6.103515625E-005,0) [0|1] ""  NODE1
      -->"SG_", "PWM_CVVAL", "48", "16", "1+", "6.103515625E-005", "0", "0", "1", """", "NODE1"
          0            1       2     3    4          5             6    7    8     9     10
          0: SG_
          1: signal name
          2: start bit
          3: length in bit
          4: format intel/motorola
          5: factor
          6: offset
          7: min
          8: max
        */
        if(lineItems.size()>=10 && lineItems.at(0) == QString("SG_")){
            CANSignalInMessage newSignalInMsg;
            newSign = new CANSignal;
            newSign->m_Name = lineItems.at(1);
            newSignalInMsg.m_StartBit = (unsigned char)lineItems.at(2).toInt();
            newSign->m_Length = (unsigned char)lineItems.at(3).toInt();
            if(lineItems.at(4)[lineItems.at(4).length()-1] == '+'){
                newSign->m_ValueType = E_CANSignalSign_UnSigned;
            }else{
                newSign->m_ValueType = E_CANSignalSign_Signed;
            }
            int sz = lineItems.at(4).length()-1;
            QString tmp(lineItems.at(4));
            tmp.resize(sz);
            newSign->m_ByteOrder = (E_CANByteOrder)(tmp.toInt());
            newSign->m_Factor.dValue = lineItems.at(5).toDouble();
            newSign->m_Offset.dValue = lineItems.at(6).toDouble();
            newSign->m_Min.dValue = lineItems.at(7).toDouble();
            newSign->m_Max.dValue = lineItems.at(8).toDouble();
//            newSign->m_ = lineItems.at(8).toDouble();
            newSign->m_InitValue.dValue = 0;
            if(m_CANSignals.isEmpty()){
                m_CANSignals.append(newSign);
                newSignalInMsg.m_Signal = newSign;
            }else{
                for(int i=0;i<m_CANSignals.size();i++){
                    if(compareSignal(newSign,m_CANSignals.at(i))){
                        newSignalInMsg.m_Signal = m_CANSignals.at(i);
                        break;
                    }
                    newSignalInMsg.m_Signal = newSign;
                    if(i==(m_CANSignals.size()-1)){
                        m_CANSignals.append(newSign);
                    }
                }
            }

            newMsg->m_Signals.append(newSignalInMsg);
        }else {
            QStringList lineItems =  line.split(QRegularExpression(":| |@|\\||\\(|\\)|\\[|\\]|,"),QString::SkipEmptyParts);
            if(lineItems.size()>=4 && lineItems.at(0) == QString("BO_")){
                qDebug()<<lineItems.size() << lineItems;
                newMsg = new CANMessage;
                newMsg->m_ID = lineItems.at(1).toUInt();
//                int sz = lineItems.at(2).size();
                newMsg->m_Name = lineItems.at(2);
//                newMsg->m_Name.resize(sz-1);
                newMsg->m_Length  = lineItems.at(3).toInt();
                newMsg->m_IdType  = (newMsg->m_ID & 0x80000000) ? E_CANMsgIDType_Extended: E_CANMsgIDType_Standard;
                newMsg->m_Signals.clear();
                m_CANMessages.append(newMsg);
            }
        }
    }
    file.close();
}

void MainDbManager::saveDbFile(QString &path)
{
if(path.isEmpty()) return;
QFile file(path);
file.open(QIODevice::WriteOnly);
QTextStream out(&file);
out<<"VERSION \"\"\n\n\n"


         <<"NS_ :\n"
         <<"NS_DESC_\n"
         <<"CM_"
         <<"BA_DEF_\n"
         <<"BA_\n"
         <<"VAL_\n"
         <<"CAT_DEF_\n"
         <<"CAT_\n"
         <<"FILTER\n"
         <<"BA_DEF_DEF_\n"
         <<"EV_DATA_\n"
         <<"ENVVAR_DATA_\n"
         <<"SGTYPE_\n"
         <<"SGTYPE_VAL_\n"
         <<"BA_DEF_SGTYPE_\n"
         <<"BA_SGTYPE_\n"
         <<"SIG_TYPE_REF_\n"
         <<"VAL_TABLE_\n"
         <<"SIG_GROUP_\n"
         <<"SIG_VALTYPE_\n"
         <<"SIGTYPE_VALTYPE_\n"
         <<"BO_TX_BU_\n"
         <<"BA_DEF_REL_\n"
         <<"BA_REL_\n"
        <<"BA_DEF_DEF_REL_\n"
         <<"BU_SG_REL_\n"
         <<"BU_EV_REL_\n"
         <<"BU_BO_REL_\n"
         <<"SG_MUL_VAL_\n\n"

     <<"BS_:\n";
foreach (CANMessage *message, m_CANMessages) {
out<<"BO_ "<<message->m_ID<<" "<<message->m_Name<<" "<<message->m_Length<<" "<<"Vector_XXX\n";
foreach (CANSignalInMessage signal, message->m_Signals) {
  out<<" SG_ "<<signal.m_Signal->m_Name<<" : "<<signal.m_StartBit<<"|"<<signal.m_Signal->m_Length<<"@"<<signal.m_Signal->m_ByteOrder<<""
  <<signal.m_Signal->m_ValueType<<" ("<<signal.m_Signal->m_Factor.dValue<<","<<signal.m_Signal->m_Offset.dValue<<") ["<<signal.m_Signal->m_Min.dValue<<"|"
  <<signal.m_Signal->m_Max.dValue<<"] "<<"\""<<signal.m_Signal->m_Unit.dValue<<"\""<<" Vector_XXX\n";
}
}
}

MainDbCommonViewModel::MainDbCommonViewModel(MainDbManager * dbMng,QObject *parent)
    : QAbstractItemModel(parent),
      m_dbManager(dbMng),
      rootItem(NULL)
{
    //    QVector<QVariant> rootData;
    //    rootData << "";
    //    rootItem = new MainDbCommonItem(rootData, E_DbItemType_Header);
    //    setupModelData(rootItem);
}

MainDbCommonViewModel::~MainDbCommonViewModel()
{
    delete rootItem;
}

int MainDbCommonViewModel::columnCount(const QModelIndex & /* parent */) const
{
    return rootItem->columnCount();
}

QModelIndex MainDbCommonViewModel::index(int row, int column, const QModelIndex &parent) const
{
    if (parent.isValid() && parent.column() != 0)
        return QModelIndex();
    MainDbCommonItem *parentItem = getItem(parent);

    MainDbCommonItem *childItem = parentItem->child(row);
    if (childItem)
        return createIndex(row, column, childItem);
    else
        return QModelIndex();
}

bool MainDbCommonViewModel::insertColumns(int position, int columns, const QModelIndex &parent)
{
    bool success = true;
    beginInsertColumns(parent, position, position + columns - 1);
    success = rootItem->insertColumns(position, columns);
    endInsertColumns();
    return success;
}

bool MainDbCommonViewModel::insertRows(int position, int rows, const QModelIndex &parent)
{
    bool success = true;
    MainDbCommonItem *parentItem = getItem(parent);
    beginInsertRows(parent, position, position + rows - 1);
    success = parentItem->insertChildren(position, rows, rootItem->columnCount(),E_DbItemType_Header);
    endInsertRows();
    return success;
}

QModelIndex MainDbCommonViewModel::parent(const QModelIndex &index) const
{
    if (!index.isValid())
        return QModelIndex();
    MainDbCommonItem *childItem = getItem(index);
    MainDbCommonItem *parentItem = childItem->parent();
    if (parentItem == rootItem)
        return QModelIndex();
    return createIndex(parentItem->childNumber(), 0, parentItem);
}

bool MainDbCommonViewModel::removeColumns(int position, int columns, const QModelIndex &parent)
{
    bool success = true;
    beginRemoveColumns(parent, position, position + columns - 1);
    success = rootItem->removeColumns(position, columns);
    endRemoveColumns();
    if (rootItem->columnCount() == 0)
        removeRows(0, rowCount());
    return success;
}

bool MainDbCommonViewModel::removeRows(int position, int rows, const QModelIndex &parent)
{
    bool success = true;
    MainDbCommonItem *parentItem = getItem(parent);
    beginRemoveRows(parent, position, position + rows - 1);
    success = parentItem->removeChildren(position, rows);
    endRemoveRows();
    return success;
}

int MainDbCommonViewModel::rowCount(const QModelIndex &parent) const
{
    MainDbCommonItem *parentItem = getItem(parent);
    return parentItem->childCount();
}

MainDbCommonItem *MainDbCommonViewModel::getItem(const QModelIndex &index) const
{
    if (index.isValid()) {
        MainDbCommonItem *item = static_cast<MainDbCommonItem*>(index.internalPointer());
        if (item)
            return item;
    }
    return rootItem;
}

//MainDbTreeViewModel method define area

QVariant MainDbTreeViewModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid())
        return QVariant();

    if (role != Qt::DisplayRole && role != Qt::DecorationRole && role != Qt::ForegroundRole)
        return QVariant();
    if(role == Qt::DisplayRole){
        MainDbCommonItem *item = getItem(index);
        if(item->getType() == E_DbItemType_Message){
            QString string;
//            qDebug()<< item->data(index.column());
            string.append(item->data(index.column()).toString());
            string.append("\t(0x");
            string.append(QString::number(item->data(index.column()+1).toInt() & (~0x80000000),16));
            string.append(")");
            return string;
        }else if(item->getType() == E_DbItemType_Signal){
            QString string;
            string.append(item->data(0).toString());
            return string;
        }else{
            QString string;
            for(int i=0;i<=index.column();i++){
                string.append(item->data(i).toString());
            }
            return string;
        }
        //return item->data(index.column());
    }else if(role == Qt::DecorationRole){
        MainDbCommonItem *item = getItem(index);
        switch (item->getType()) {
        case E_DbItemType_Message:
        {
            QPixmap px(":/icons/message.png");
            return px.scaled(14,14);
        }
            break;
        case E_DbItemType_Signal:
        case E_DbItemType_SignalInMessage:
        {

            QPixmap px(":/icons/signal.png");
            return px.scaled(14,14);
        }
            break;
        default:
            break;
        }
    }else if(role == Qt::ForegroundRole){
        MainDbCommonItem *item = getItem(index);
        switch (item->getType()) {
        case E_DbItemType_Header:
        {
            return QVariant( QColor( Qt::darkRed ) );
        }
            break;
        }
    }
}

bool MainDbTreeViewModel::setData(const QModelIndex &index, const QVariant &value, int role)
{
    bool result = true;
    if (role != Qt::EditRole)
        return false;
    MainDbCommonItem *item = getItem(index);
    result = item->setData(index.column(), value);
    if (result)
        emit dataChanged(index, index);
    return result;
}

bool MainDbTreeViewModel::setHeaderData(int section, Qt::Orientation orientation,
                                        const QVariant &value, int role)
{
    if (role != Qt::EditRole || orientation != Qt::Horizontal)
        return false;
    bool result = rootItem->setData(section, value);
    if (result)
        emit headerDataChanged(orientation, section, section);
    return result;
}

Qt::ItemFlags MainDbTreeViewModel::flags(const QModelIndex &index) const
{
    if (!index.isValid())
        return 0;

    return QAbstractItemModel::flags(index);
}

QVariant MainDbTreeViewModel::headerData(int section, Qt::Orientation orientation,
                                         int role) const
{
    if (orientation == Qt::Horizontal && role == Qt::DisplayRole)
        return rootItem->data(section);
    return QVariant();
}

void MainDbTreeViewModel::setupModelData(MainDbCommonItem *parent)
{
    QVector <QVariant> data;
    data<< "Messages";
    parent->insertChildren(parent->childCount(), 1, rootItem->columnCount(),E_DbItemType_Header);
    parent->child(parent->childCount() - 1)->setData(0, data[0]);
    data.clear();
    data<< "Signals";
    parent->insertChildren(parent->childCount(), 1, rootItem->columnCount(),E_DbItemType_Header);
    parent->child(parent->childCount() - 1)->setData(0, data[0]);
    QModelIndex index;
    index = this->index(0,0);
    insertRows(0,m_dbManager->getMessagesList().size(),index);
    int cnt=0;
    foreach (CANMessage * msg, m_dbManager->getMessagesList()) {
        if(msg){
            index = index.child(cnt,0);
            qDebug()<<"column = "<<getItem(index)->columnCount();
            getItem(index)->setData(0,QVariant(msg->m_Name));
            getItem(index)->insertColumns(1,4);
            getItem(index)->setData(1,QVariant(msg->m_ID & (~0x80000000)));
            getItem(index)->setData(2,QVariant(msg->m_IdType));
            getItem(index)->setData(3,QVariant(msg->m_Length));
            getItem(index)->setData(4,QVariant(msg->m_Comment));
            for(int i=0;i<getItem(index)->columnCount();i++){
                qDebug()<<"column i = "<<getItem(index)->data(i);
            }
            qDebug()<<"getItem(index)= "<<getItem(index)->data(1);
            getItem(index)->setType(E_DbItemType_Message);
            insertRows(0,msg->m_Signals.size(),index);
            int cnt2=0;
            foreach (CANSignalInMessage sgnInMsg, msg->m_Signals) {

                index = index.child(cnt2,0);
                getItem(index)->setData(0,sgnInMsg.m_Signal->m_Name);
                getItem(index)->insertColumns(1,11);
                //getItem(index)->setData(1,sgnInMsg.m_Signal);
                getItem(index)->setData(1,sgnInMsg.m_StartBit);
                getItem(index)->setData(2,sgnInMsg.m_Signal->m_Length);
                getItem(index)->setData(3,sgnInMsg.m_Signal->m_ByteOrder);
                getItem(index)->setData(4,sgnInMsg.m_Signal->m_Unit.dValue);
                getItem(index)->setData(5,sgnInMsg.m_Signal->m_ValueType);
                getItem(index)->setData(6,sgnInMsg.m_Signal->m_InitValue.dValue);
                getItem(index)->setData(7,sgnInMsg.m_Signal->m_Factor.dValue);
                getItem(index)->setData(8,sgnInMsg.m_Signal->m_Offset.dValue);
                getItem(index)->setData(9,sgnInMsg.m_Signal->m_Min.dValue);
                getItem(index)->setData(10,sgnInMsg.m_Signal->m_Max.dValue);
                getItem(index)->setData(11,sgnInMsg.m_Signal->m_Comment);
                getItem(index)->setType(E_DbItemType_SignalInMessage);
                index = index.parent();
                cnt2++;
            }
            index = index.parent();
        }
        cnt++;
    }
    index = this->index(1,0);
    insertRows(0,m_dbManager->getSignalsList().size(),index);
    cnt=0;
    foreach (CANSignal * sgn, m_dbManager->getSignalsList()) {
        if(sgn){
            index = index.child(cnt,0);
            getItem(index)->setData(0,sgn->m_Name);
            getItem(index)->insertColumns(1,8);
            getItem(index)->setData(1,sgn->m_Length);
            getItem(index)->setData(2,(sgn->m_ByteOrder == E_CANByteOrder_Intel ? "Intel": "Motorola"));
            getItem(index)->setData(3,(sgn->m_ValueType == E_CANSignalSign_Signed ? "Signed" : "Unsigned"));
            getItem(index)->setData(4, sgn->m_InitValue.dValue);
            getItem(index)->setData(5,sgn->m_Offset.dValue);
            getItem(index)->setData(6,sgn->m_Min.dValue);
            getItem(index)->setData(7,sgn->m_Max.dValue);
            getItem(index)->setData(8,sgn->m_Comment);
            getItem(index)->setType(E_DbItemType_Signal);
            //insert children for index
//           insertRows(0,m_dbManager->getMessagesOfSignal(cnt).size(),index);
//            int cnt2=0;
//            qDebug()<<"cnt = "<<cnt;
//            foreach (CANMessagesOfSignal msgOfSig, m_dbManager->getMessagesOfSignal(cnt)) {
//                qDebug()<<" cnt2= "<<cnt2;
//                index = index.child(cnt2,0);
//                getItem(index)->setData(0,msgOfSig.m_msgName);
//                getItem(index)->insertColumns(1,1);
//                getItem(index)->setData(1,msgOfSig.m_StartBit);
//                cnt2++;
//                index = index.parent();
//            }

            // insert children for item
//            getItem(index)->insertChildren(0,m_dbManager->getMessagesOfSignal(cnt).size(),2,E_DbItemType_Signal);
//            int temp=0;
//            foreach (CANMessagesOfSignal msgOfSig,  m_dbManager->getMessagesOfSignal(cnt)) {
//                getItem(index)->child(temp)->setData(0,msgOfSig.m_msgName);
//                getItem(index)->child(temp)->setData(1,msgOfSig.m_StartBit);
//                temp++;
//            }

        }
        cnt++;
        index = index.parent();
    }
}

void MainDbTreeViewModel::changeByTblMess(QModelIndex index1, QModelIndex index2, QVector<int> vector)
{
MainDbCommonItem * tblItem = static_cast<MainDbCommonItem*>(index1.internalPointer());
QModelIndex messIndex = this->index(0,0,QModelIndex());
MainDbCommonItem *treeItem = static_cast<MainDbCommonItem*>(messIndex.child(index1.row(),index1.column()).internalPointer());
treeItem->setData(index1.column(),tblItem->data(index1.column()));
}

void MainDbTreeViewModel::changeByTblSig(QModelIndex index1, QModelIndex index2, QVector<int> vector)
{
    MainDbCommonItem * tblItem = static_cast<MainDbCommonItem*>(index1.internalPointer());
    QModelIndex messIndex = this->index(1,0,QModelIndex());
    MainDbCommonItem *treeItem = static_cast<MainDbCommonItem*>(messIndex.child(index1.row(),index1.column()).internalPointer());
    treeItem->setData(index1.column(),tblItem->data(index1.column()));
}

void MainDbTreeViewModel::changeByCombTbl(QModelIndex index1, QModelIndex index2, QVector<int> vector)
{
//    MainDbCommonItem * tblItem = static_cast<MainDbCommonItem*>(index1.internalPointer());
//    QModelIndex messIndex =this->index(0,0,QModelIndex());
//    MainDbCommonItem *treeItem = static_cast<MainDbCommonItem*>(messIndex.child(index1.row(),index1.column()).internalPointer());
//    treeItem->setData(index1.column(),tblItem->data(index1.column()));
}

//MainDbTableMsgsModel method define  area

MainDbTableMsgsModel::MainDbTableMsgsModel(MainDbManager * dbMng, QObject *parent ):
    MainDbCommonViewModel(dbMng,parent)
{
    QVector<QVariant> rootData;
    rootData <<  "Name" << "ID" << "ID-format" << "DLC [Byte]" << "Comment";
    rootItem = new MainDbCommonItem(rootData, E_DbItemType_Header);
    setupModelData(rootItem);
}

QVariant MainDbTableMsgsModel::data(const QModelIndex &index, int role) const
{
    //    qDebug()<< __FUNCTION__ << __LINE__;
    if (!index.isValid())
        return QVariant();

    if (role != Qt::DisplayRole && role != Qt::EditRole && role != Qt::DecorationRole &&  role != Qt::BackgroundColorRole && role !=Qt::TextAlignmentRole)
        return QVariant();
    if(role == Qt::DisplayRole || role == Qt::EditRole){
        MainDbCommonItem *item = getItem(index);
        if(index.column() == 1){
            //This is message ID column
            QString tmp("0x");
            tmp.append(QString::number(item->data(index.column()).toUInt()& (~0x80000000),16));
            return tmp;
        }
        return item->data(index.column());
    }else if(role == Qt::DecorationRole  && index.column() == 0){
        MainDbCommonItem *item = getItem(index);
        switch (item->getType()) {
        case E_DbItemType_Message:
        {
            QPixmap px(":/icons/message.png");
            return px.scaled(16,16);
        }
            break;
        case E_DbItemType_Signal:
        case E_DbItemType_SignalInMessage:
        {
            QPixmap px(":/icons/signal.png");
            return px.scaled(16,16);
        }
            break;
        default:
            break;
        }
    }else if(role == Qt::BackgroundColorRole){
        if(index.row()%2 == 0){
            return QVariant( QColor( 215, 227, 229 ) );
        }
    }else if (role ==Qt::TextAlignmentRole)   {

    }
    return QVariant();
}

bool MainDbTableMsgsModel::setData(const QModelIndex &index, const QVariant &value, int role)
{
    bool result = true;
    if (role != Qt::EditRole)
        return false;
    MainDbCommonItem *item = getItem(index);
    result = item->setData(index.column(), value);
    if (result){
        emit dataChanged(index, index);
        emit updateByDelegate(index);
    }
    return result;
}

bool MainDbTableMsgsModel::setHeaderData(int section, Qt::Orientation orientation,
                                         const QVariant &value, int role)
{
    if (role != Qt::EditRole || orientation != Qt::Horizontal)
        return false;

    bool result = rootItem->setData(section, value);
    if (result)
        emit headerDataChanged(orientation, section, section);
    return result;
}

Qt::ItemFlags MainDbTableMsgsModel::flags(const QModelIndex &index) const
{
    if (!index.isValid())
        return 0;
    return Qt::ItemIsEditable | QAbstractItemModel::flags(index);
}

QVariant MainDbTableMsgsModel::headerData(int section, Qt::Orientation orientation,
                                          int role) const
{
    if (orientation == Qt::Horizontal && role == Qt::DisplayRole)
        return rootItem->data(section);
    return QVariant();
}

void MainDbTableMsgsModel::setupModelData(MainDbCommonItem *parent)
{
    QVector <QVariant> data;
    int cnt=0,idx=0;
    foreach (CANMessage * msg, m_dbManager->getMessagesList()) {
        if(msg){
            idx=0;
            parent->insertChildren(parent->childCount(), 1, rootItem->columnCount(),E_DbItemType_Message);
            data << msg->m_Name;
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data << msg->m_ID;
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data << ((msg->m_IdType == E_CANMsgIDType_Extended) ? QString("Extended") :QString("Standard"));
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data << msg->m_Length;
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data.clear();
        }
        cnt++;
    }
}

//MainDbTableSignsModel method define area

MainDbTableSignsModel::MainDbTableSignsModel(MainDbManager * dbMng, QObject *parent ):
    MainDbCommonViewModel(dbMng,parent){
    QVector<QVariant> rootData;
    rootData <<  "Name" << "Length [Bit]" << "Byte Order" << "Value Type" << "Initial Value" << "Factor"<< "Offset"<< "Minimum" << "Maximum" << "Comment";
    rootItem = new MainDbCommonItem(rootData, E_DbItemType_Header);
    setupModelData(rootItem);
}

QVariant MainDbTableSignsModel::data(const QModelIndex &index, int role) const
{
    //    qDebug()<< __FUNCTION__ << __LINE__;
    if (!index.isValid())
        return QVariant();

    if (role != Qt::DisplayRole && role != Qt::EditRole && role != Qt::DecorationRole &&  role != Qt::BackgroundColorRole && role !=Qt::TextAlignmentRole)
        return QVariant();
    if(role == Qt::DisplayRole || role == Qt::EditRole){
        MainDbCommonItem *item = getItem(index);
        return item->data(index.column());
    }else if(role == Qt::DecorationRole && index.column() == 0){
        MainDbCommonItem *item = getItem(index);
        switch (item->getType() ) {
        case E_DbItemType_Message:
        {
            QPixmap px(":/icons/message.png");
            return px.scaled(16,16);
        }
            break;
        case E_DbItemType_Signal:
        case E_DbItemType_SignalInMessage:
        {
            QPixmap px(":/icons/signal.png");
            return px.scaled(16,16);
        }
            break;
        default:
            break;
        }
    }else if(role == Qt::BackgroundColorRole){
        if(index.row()%2 == 0){
            return QVariant( QColor( 215, 227, 229 ) );
        }
    }
    return QVariant();
}

bool MainDbTableSignsModel::setData(const QModelIndex &index, const QVariant &value, int role)
{
    bool result = true;
    if (role != Qt::EditRole)
        return false;
    MainDbCommonItem *item = getItem(index);
    result = item->setData(index.column(), value);
    if (result)
    {
        emit dataChanged(index, index);
        emit updateByDelegate(index);
    }
    return result;
}
bool MainDbTableSignsModel::setHeaderData(int section, Qt::Orientation orientation,
                                          const QVariant &value, int role)
{
    if (role != Qt::EditRole || orientation != Qt::Horizontal)
        return false;

    bool result = rootItem->setData(section, value);
    if (result)
        emit headerDataChanged(orientation, section, section);
    return result;
}

Qt::ItemFlags MainDbTableSignsModel::flags(const QModelIndex &index) const
{
    if (!index.isValid())
        return 0;
    return Qt::ItemIsEditable | QAbstractItemModel::flags(index);
}

QVariant MainDbTableSignsModel::headerData(int section, Qt::Orientation orientation,
                                           int role) const
{
    if (orientation == Qt::Horizontal && role == Qt::DisplayRole)
        return rootItem->data(section);
    return QVariant();
}

void MainDbTableSignsModel::setupModelData(MainDbCommonItem *parent)
{
    QVector <QVariant> data;
    //static const QStringList byOrderArray[2] = {"Intel","Motorola"};

    int cnt=0, idx = 0;
    foreach (CANSignal * sgn, m_dbManager->getSignalsList()) {
        if(sgn){
            //qDebug()<<"child count signal = "<<parent->childCount();
            //qDebug()<<"root count signal = "<<rootItem->columnCount();
            //"Name" << "Length [Bit]" << "Byte Order" << "Value Type" << "Initial Value" << "Factor"<< "Offset"<< "Minimum" << "Maximum" ;
            idx = 0;
            parent->insertChildren(parent->childCount(), 1, rootItem->columnCount(),E_DbItemType_Signal);
            data << sgn->m_Name;
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data << sgn->m_Length;
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data << (sgn->m_ByteOrder == E_CANByteOrder_Intel ? "Intel": "Motorola");
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            if(sgn->m_ValueType == E_CANSignalSign_Signed){
                data <<"Signed";
            }else if(sgn->m_ValueType == E_CANSignalSign_UnSigned){
                data <<"Unsigned";
            }else if(sgn->m_ValueType == E_CANSignalSign_Float){
                data <<"Float";
            }else{
                data <<"Double";
            }
            //data << (sgn->m_ValueType == E_CANSignalSign_Signed ? "Signed" : "Unsigned");
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data <<  sgn->m_InitValue.dValue;
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data <<  sgn->m_Factor.dValue;
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data <<  sgn->m_Offset.dValue;
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data <<  sgn->m_Min.dValue;
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data <<  sgn->m_Max.dValue;
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data <<  sgn->m_Comment;
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);

//            switch(sgn->m_ValueType){
//            case E_CANSignalSign_Signed:
//                data << sgn->m_Factor.lValue;
//                data << sgn->m_Offset.lValue;
//                data << sgn->m_Min.lValue;
//                data << sgn->m_Max.lValue;
//                break;
//            case E_CANSignalSign_UnSigned:
//                data << sgn->m_Factor.uValue;
//                data << sgn->m_Offset.uValue;
//                data << sgn->m_Min.uValue;
//                data << sgn->m_Max.uValue;
//                break;

//            case E_CANSignalSign_Double:
//                data << sgn->m_Factor.dValue;
//                data << sgn->m_Offset.dValue;
//                data << sgn->m_Min.dValue;
//                data << sgn->m_Max.dValue;
//                break;

//            case E_CANSignalSign_Float:
//                data << sgn->m_Factor.fValue;
//                data << sgn->m_Offset.fValue;
//                data << sgn->m_Min.fValue;
//                data << sgn->m_Max.fValue;
//                break;

//            default: break;
//            }

            data.clear();
        }
        cnt++;
    }
}

// MainDbCommonItem method define area

MainDbCommonItem::MainDbCommonItem(QVector<QVariant> &data,E_DbItemType itemType, MainDbCommonItem *parent)
{
    parentItem = parent;
    itemData = data;
    m_itemType = itemType;
}

MainDbCommonItem::~MainDbCommonItem()
{
    qDeleteAll(childItems);
}

MainDbCommonItem *MainDbCommonItem::child(int number)
{
    return childItems.value(number);
}

int MainDbCommonItem::childCount() const
{
    return childItems.count();
}

int MainDbCommonItem::childNumber() const
{
    if (parentItem)
        return parentItem->childItems.indexOf(const_cast<MainDbCommonItem*>(this));
    return 0;
}

int MainDbCommonItem::columnCount() const
{
    return itemData.size();
}

QVariant  MainDbCommonItem::data(int column) const
{
    return itemData.value(column);
}
bool MainDbCommonItem::insertChildren(int position, int count, int columns, E_DbItemType type)
{
    qDebug()<<"columns ="<<columns;
    if (position < 0 || position > childItems.size())
        return false;
    for (int row = 0; row < count; ++row) {
        QVector<QVariant> data(columns);
        MainDbCommonItem *item = new MainDbCommonItem(data,type,this);
        childItems.insert(position, item);
    }

    return true;
}



bool MainDbCommonItem::insertColumns(int position, int columns)
{
    if (position < 0 || position > itemData.size())
        return false;

    for (int column = 0; column < columns; ++column)
        itemData.insert(position, QVariant());

    foreach (MainDbCommonItem *child, childItems)
        child->insertColumns(position, columns);

    return true;
}

MainDbCommonItem *MainDbCommonItem::parent()
{
    return parentItem;
}

bool MainDbCommonItem::removeChildren(int position, int count)
{
    if (position < 0 || position + count > childItems.size())
        return false;

    for (int row = 0; row < count; ++row)
        delete childItems.takeAt(position);

    return true;
}

bool MainDbCommonItem::removeColumns(int position, int columns)
{
    if (position < 0 || position + columns > itemData.size())
        return false;

    for (int column = 0; column < columns; ++column)
        itemData.removeAt(position);

    foreach (MainDbCommonItem *child, childItems)
        child->removeColumns(position, columns);

    return true;
}

bool MainDbCommonItem::setData(int column, const QVariant &value)
{
    if (column < 0 || column >= itemData.size())
        return false;

    itemData[column] = value;
    return true;
}
// MainDbTableCombineModel define area

MainDbTableCombineModel::MainDbTableCombineModel(MainDbManager *dbMng, QObject *parent, int i):MainDbCommonViewModel(dbMng,parent)
{
// do nothing , just call to construct a address for this model
// we should find another approach to fix this problem
}

MainDbTableCombineModel::MainDbTableCombineModel(MainDbManager * dbMng, QObject *parent,QModelIndex clickedIndex):
    MainDbCommonViewModel(dbMng,parent),clickedItemIndex(clickedIndex){
    QVector<QVariant> rootData;
    rootData <<  "Name" << "Length [Bit]" <<"Message"<<"Multiplexing/Group"<<"Startbit"<< "Byte Order" << "Value Type" << "Initial Value" << "Factor"<< "Offset"<< "Minimum" << "Maximum" << "Comment";
    rootItem = new MainDbCommonItem(rootData, E_DbItemType_Header);
    setupModelData(rootItem);
}

QVariant MainDbTableCombineModel::data(const QModelIndex &index, int role) const
{
    //    qDebug()<< __FUNCTION__ << __LINE__;
    if (!index.isValid())
        return QVariant();

    if (role != Qt::DisplayRole && role != Qt::EditRole && role != Qt::DecorationRole &&  role != Qt::BackgroundColorRole && role !=Qt::TextAlignmentRole)
        return QVariant();
    if(role == Qt::DisplayRole || role == Qt::EditRole){
        MainDbCommonItem *item = getItem(index);
        return item->data(index.column());
    }else if(role == Qt::DecorationRole && index.column() == 0){
        MainDbCommonItem *item = getItem(index);
        switch (item->getType() ) {
        case E_DbItemType_Message:
        {
            QPixmap px(":/icons/message.png");
            return px.scaled(16,16);
        }
            break;
        case E_DbItemType_Signal:
        case E_DbItemType_SignalInMessage:
        {
            QPixmap px(":/icons/signal.png");
            return px.scaled(16,16);
        }
            break;
        default:
            break;
        }
    }else if(role == Qt::BackgroundColorRole){
        if(index.row()%2 == 0){
            return QVariant( QColor( 215, 227, 229 ) );
        }
    }
    return QVariant();
}

bool MainDbTableCombineModel::setData(const QModelIndex &index, const QVariant &value, int role)
{
    qDebug()<<"setdata called";
    bool result = true;
    if (role != Qt::EditRole)
        return false;
    MainDbCommonItem *item = getItem(index);
    result = item->setData(index.column(), value);
    if (result)
    {
        emit dataChanged(index, index);
        emit updateByDelegate(index);
    }
    return result;
}
bool MainDbTableCombineModel::setHeaderData(int section, Qt::Orientation orientation,
                                          const QVariant &value, int role)
{
    if (role != Qt::EditRole || orientation != Qt::Horizontal)
        return false;

    bool result = rootItem->setData(section, value);
    if (result)
        emit headerDataChanged(orientation, section, section);
    return result;
}

Qt::ItemFlags MainDbTableCombineModel::flags(const QModelIndex &index) const
{
    if (!index.isValid())
        return 0;
    return Qt::ItemIsEditable | QAbstractItemModel::flags(index);
}

QVariant MainDbTableCombineModel::headerData(int section, Qt::Orientation orientation,
                                           int role) const
{
    if (orientation == Qt::Horizontal && role == Qt::DisplayRole)
        return rootItem->data(section);
    return QVariant();
}

void MainDbTableCombineModel::setupModelData(MainDbCommonItem *parent)
{

    MainDbCommonItem *inputItem = static_cast<MainDbCommonItem *> (clickedItemIndex.internalPointer());
    if(inputItem->getType()==E_DbItemType_Message){
    //qDebug()<<"row = "<<Row;
    QVector <QVariant> data;
    //static const QStringList byOrderArray[2] = {"Intel","Motorola"};
    int cnt=0, idx = 0;
    foreach (CANSignalInMessage sgn, m_dbManager->getMessagesList().at(clickedItemIndex.row())->m_Signals) {
        if(sgn.m_Signal){
            //"Name" << "Length [Bit]" <<"Message"<<"Multiplexing/Group"<<"Startbit"<< "Byte Order" <<
           qDebug()<<"child count = "<<parent->childCount();
           qDebug()<<"root count = "<<rootItem->columnCount();
            //"Value Type"<< "Initial Value" << "Factor"<< "Offset"<< "Minimum" << "Maximum" << "Comment";
          // insertChildren(int position, int count, int columns, E_DbItemType type)

           parent->insertChildren(parent->childCount(), 1, rootItem->columnCount(),E_DbItemType_Signal);
           data << sgn.m_Signal->m_Name;
            qDebug()<<sgn.m_Signal->m_Name;
            qDebug()<<parent->childCount();
            qDebug()<<idx;
            qDebug()<<data[idx];
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data << sgn.m_Signal->m_Length;
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data <<m_dbManager->getMessagesList().at(clickedItemIndex.row())->m_Name;
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data <<"mul";
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data <<sgn.m_StartBit;
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data << (sgn.m_Signal->m_ByteOrder == E_CANByteOrder_Intel ? "Intel": "Motorola");
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            //data << (sgn.m_Signal->m_ValueType == E_CANSignalSign_Signed ? "Signed" : "Unsigned");
            if(sgn.m_Signal->m_ValueType == E_CANSignalSign_Signed){
                data <<"Signed";
            }else if(sgn.m_Signal->m_ValueType  == E_CANSignalSign_UnSigned){
                data <<"Unsigned";
            }else if(sgn.m_Signal->m_ValueType  == E_CANSignalSign_Float){
                data <<"Float";
            }else{
                data <<"Double";
            }
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data <<  sgn.m_Signal->m_InitValue.dValue;
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data <<  sgn.m_Signal->m_Factor.dValue;
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data <<  sgn.m_Signal->m_Offset.dValue;
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data <<  sgn.m_Signal->m_Min.dValue;
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data <<  sgn.m_Signal->m_Max.dValue;
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data <<  sgn.m_Signal->m_Comment;
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            idx=0;
            data.clear();
        }
        cnt++;
    }}else if(inputItem->getType()==E_DbItemType_SignalInMessage){
        //qDebug()<<"row = "<<Row;
        QVector <QVariant> data;
        //static const QStringList byOrderArray[2] = {"Intel","Motorola"};
        int idx = 0;
        CANSignalInMessage sgn= m_dbManager->getMessagesList().at(clickedItemIndex.parent().row())->m_Signals.at(clickedItemIndex.row());
            if(sgn.m_Signal){
                //"Name" << "Length [Bit]" <<"Message"<<"Multiplexing/Group"<<"Startbit"<< "Byte Order" <<
               qDebug()<<"child count = "<<parent->childCount();
               qDebug()<<"root count = "<<rootItem->columnCount();
                //"Value Type"<< "Initial Value" << "Factor"<< "Offset"<< "Minimum" << "Maximum" << "Comment";
              // insertChildren(int position, int count, int columns, E_DbItemType type)

               parent->insertChildren(parent->childCount(), 1, rootItem->columnCount(),E_DbItemType_Signal);
               data << sgn.m_Signal->m_Name;
               qDebug()<<sgn.m_Signal->m_Name;
               qDebug()<<parent->childCount();
               qDebug()<<idx;
               qDebug()<<data[idx];
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                data << sgn.m_Signal->m_Length;
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                data <<m_dbManager->getMessagesList().at(clickedItemIndex.parent().row())->m_Name;
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                data <<"mul";
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                data <<sgn.m_StartBit;
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                data << (sgn.m_Signal->m_ByteOrder == E_CANByteOrder_Intel ? "Intel": "Motorola");
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                //data << (sgn.m_Signal->m_ValueType == E_CANSignalSign_Signed ? "Signed" : "Unsigned");
                if(sgn.m_Signal->m_ValueType == E_CANSignalSign_Signed){
                    data <<"Signed";
                }else if(sgn.m_Signal->m_ValueType  == E_CANSignalSign_UnSigned){
                    data <<"Unsigned";
                }else if(sgn.m_Signal->m_ValueType == E_CANSignalSign_Float){
                    data <<"Float";
                }else{
                    data <<"Double";
                }
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                data <<  sgn.m_Signal->m_InitValue.dValue;
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                data <<  sgn.m_Signal->m_Factor.dValue;
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                data <<  sgn.m_Signal->m_Offset.dValue;
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                data <<  sgn.m_Signal->m_Min.dValue;
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                data <<  sgn.m_Signal->m_Max.dValue;
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                data <<  sgn.m_Signal->m_Comment;
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                idx=0;
                data.clear();
            }
    }else if(inputItem->getType()==E_DbItemType_Signal){
        qDebug()<<"signal click  row =  "<<clickedItemIndex.row();
        CANSignal *sgn = m_dbManager->getSignalsList().at(clickedItemIndex.row());
        if(sgn){
        qDebug()<<"ok hehe"<<m_dbManager->getMessagesOfSignal(clickedItemIndex.row()).size();
        }
        QVector <QVariant> data;
        int idx = 0;
        foreach (CANMessagesOfSignal msg_sgn, m_dbManager->getMessagesOfSignal(clickedItemIndex.row())) {
            if(sgn){
               parent->insertChildren(parent->childCount(), 1, rootItem->columnCount(),E_DbItemType_Signal);
               data << sgn->m_Name;
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                data << sgn->m_Length;
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                data <<msg_sgn.m_msgName;
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                data <<"mul";
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                data <<msg_sgn.m_StartBit;
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                data << (sgn->m_ByteOrder == E_CANByteOrder_Intel ? "Intel": "Motorola");
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                if(sgn->m_ValueType == E_CANSignalSign_Signed){
                    data <<"Signed";
                }else if(sgn->m_ValueType  == E_CANSignalSign_UnSigned){
                    data <<"Unsigned";
                }else if(sgn->m_ValueType  == E_CANSignalSign_Float){
                    data <<"Float";
                }else{
                    data <<"Double";
                }
                //data << (sgn->m_ValueType == E_CANSignalSign_Signed ? "Signed" : "Unsigned");
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                data <<  sgn->m_InitValue.dValue;
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                data <<  sgn->m_Factor.dValue;
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                data <<  sgn->m_Offset.dValue;
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                data <<  sgn->m_Min.dValue;
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                data <<  sgn->m_Max.dValue;
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                data <<  sgn->m_Comment;
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                idx=0;
                data.clear();
            }
    }
    }
}
