#ifndef DELEGATEWIDGET_H
#define DELEGATEWIDGET_H

class DelegateWidget
{
public:
    DelegateWidget();
};

#endif // DELEGATEWIDGET_H
