/****************************************************************************
**
** Copyright (C) 2016 The Qt Company Ltd.
** Contact: https://www.qt.io/licensing/
**
** This file is part of the examples of the Qt Toolkit.
**
** $QT_BEGIN_LICENSE:BSD$
** Commercial License Usage
** Licensees holding valid commercial Qt licenses may use this file in
** accordance with the commercial license agreement provided with the
** Software or, alternatively, in accordance with the terms contained in
** a written agreement between you and The Qt Company. For licensing terms
** and conditions see https://www.qt.io/terms-conditions. For further
** information use the contact form at https://www.qt.io/contact-us.
**
** BSD License Usage
** Alternatively, you may use this file under the terms of the BSD license
** as follows:
**
** "Redistribution and use in source and binary forms, with or without
** modification, are permitted provided that the following conditions are
** met:
**   * Redistributions of source code must retain the above copyright
**     notice, this list of conditions and the following disclaimer.
**   * Redistributions in binary form must reproduce the above copyright
**     notice, this list of conditions and the following disclaimer in
**     the documentation and/or other materials provided with the
**     distribution.
**   * Neither the name of The Qt Company Ltd nor the names of its
**     contributors may be used to endorse or promote products derived
**     from this software without specific prior written permission.
**
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
** "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
** LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
** A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
** OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
** DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
** THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
** (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
** OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
**
** $QT_END_LICENSE$
**
****************************************************************************/

#include <QtWidgets>

#include "tabdialogSignalMessage.h"

//! [0]
TabDialogSignalMessage::TabDialogSignalMessage(const MainDbCommonItem *item, const MainDbEditor *editor, QWidget *parent)
    : QDialog(parent)
{
    //QString *s= new QString("aaaaa");
    this->treeCurIndex=const_cast<MainDbEditor *>(editor)->getTreeWidget()->currentIndex();
    this->tblCurIndex=const_cast<MainDbEditor *>(editor)->getMessageTableWidget()->currentIndex();
    this->combTblIndex=const_cast<MainDbEditor *>(editor)->getComTableWidget()->currentIndex();
    tabWidget = new QTabWidget;
    DeTabMsgSign = new DefinitionTabMsgSign(item);
    MsgTabMsgSign = new MessageTabMsgSign(item);
    SignTabMsgSign = new SignalsTabMsgSign(item);
    ReceiTabMsgSign = new ReceiversTabMsgSign(item);
    ValueTabMsgSign = new ValueDescriptionsTabMsgSign(item);
    AtTabMsgSign = new AttributesTabMsgSign(item);
    ComTabMsgSign = new CommentTabMsgSign(item);
    tabWidget->addTab(DeTabMsgSign, tr("Definition"));
    tabWidget->addTab(MsgTabMsgSign, QIcon(":/icons/message.png"), tr("Message"));
    tabWidget->addTab(SignTabMsgSign, QIcon(":/icons/signal.png"), tr("Signals"));
    tabWidget->addTab(ReceiTabMsgSign, QIcon(":/icons/network.png"), tr("Receivers"));
    tabWidget->addTab(ValueTabMsgSign, tr("Value Descriptions"));
    tabWidget->addTab(AtTabMsgSign, QIcon(":/icons/edit.png"), tr("Attributes"));
    tabWidget->addTab(ComTabMsgSign, tr("Comment"));

    buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok
                                     | QDialogButtonBox::Cancel
                                     | QDialogButtonBox::Apply
                                     | QDialogButtonBox::Help);

    connect(buttonBox, &QDialogButtonBox::accepted, this, &QDialog::accept);
    connect(buttonBox, &QDialogButtonBox::rejected, this, &QDialog::reject);
    QPushButton *applyButton = buttonBox->button(QDialogButtonBox::Apply);
    connect(applyButton, SIGNAL(clicked()), this, SLOT(slotClickApply()));

    QVBoxLayout *mainLayout = new QVBoxLayout;
    mainLayout->addWidget(tabWidget);
    mainLayout->addWidget(buttonBox);
    setLayout(mainLayout);

    setWindowTitle(("Message Signal '"+ item->data(0).toString() + "'"));
        qDebug()<<"gdsgdfg";
   }

void TabDialogSignalMessage::accept()
{
  slotClickApply();
  delete this;
}

void TabDialogSignalMessage::slotClickApply()
{
    CANSignal *editedSignal =new CANSignal();
    editedSignal->m_Name=this->SignTabMsgSign->fileNameEdit->text();
    editedSignal->m_Length=this->SignTabMsgSign->LengthEdit->text().toInt();
    editedSignal->m_ByteOrder=(E_CANByteOrder)this->SignTabMsgSign->ByteOrderEdit->currentIndex();
    qDebug()<<"value type= "<<this->SignTabMsgSign->ValueTypeEdit->currentText();
    editedSignal->m_ValueType=(E_CANSignalSign)this->SignTabMsgSign->ValueTypeEdit->currentIndex();
    editedSignal->m_Factor.dValue=this->SignTabMsgSign->FactorEdit->text().toDouble();
    editedSignal->m_InitValue.dValue=this->SignTabMsgSign->IntValueEdit->text().toDouble();
    editedSignal->m_Min.dValue =this->SignTabMsgSign->MinimumEdit->text().toDouble();
    editedSignal->m_Max.dValue=this->SignTabMsgSign->MaximumEdit->text().toDouble();
    editedSignal->m_Offset.dValue=this->SignTabMsgSign->OffsetEdit->text().toDouble();
    editedSignal->m_Unit.dValue=this->SignTabMsgSign->UnitEdit->text().toDouble();
  //    qDebug()<<"accept "<<this->DeTabSign->fileNameEdit->text();
  //    emit editMessage(this->DeTabSign->fileNameEdit->text());
    CANMessage *mess = new CANMessage();
    mess->m_ID=this->MsgTabMsgSign->IDEdit->text().toInt();
    mess->m_IdType= (E_CANMsgIDType)this->MsgTabMsgSign->TypeEdit->currentIndex();
    mess->m_Length=this->MsgTabMsgSign->DLCEdit->value();
    mess->m_Name= this->MsgTabMsgSign->fileNameEdit->text();
    emit editsBit(this->DeTabMsgSign->StartBitEdit->text().toInt());
    emit editSignal(editedSignal);
    emit editMess(mess,this->treeCurIndex,this->tblCurIndex,this->combTblIndex);

}

DefinitionTabMsgSign::DefinitionTabMsgSign(const MainDbCommonItem *item, QWidget *parent)
    : QWidget(parent)
{
    MainDbCommonItem * testItem =const_cast<MainDbCommonItem *>(item);
    QLabel *fileNameLabel = new QLabel(tr("Message Name:"));
    QLineEdit *fileNameEdit = new QLineEdit(testItem->parent()->data(0).toString());
    fileNameEdit->setEnabled(false);

    QLabel *fileNameLabel1 = new QLabel(tr("Signal Name:"));
    QLineEdit *fileNameEdit1 = new QLineEdit(item->data(0).toString());
    fileNameEdit1->setEnabled(false);
    QLabel *StartBit = new QLabel(tr("Start[Bit]:"));
    StartBitEdit = new QLineEdit(item->data(1).toString());

    QLabel *Multiplexortype = new QLabel(tr("Multiplexortype:"));
    QComboBox *MultiplexortypeEdit = new QComboBox;
    MultiplexortypeEdit->addItem("Signal");
    MultiplexortypeEdit->addItem("Multiplexor Signal");
    MultiplexortypeEdit->addItem("Multiplexed Signal");
    MultiplexortypeEdit->setEnabled(false);

    QGridLayout *mainLayout = new QGridLayout;
    mainLayout->addWidget(fileNameLabel,0,0,1,1);
    mainLayout->addWidget(fileNameEdit,0,1,1,3);
    mainLayout->addWidget(fileNameLabel1,1,0,1,1);
    mainLayout->addWidget(fileNameEdit1,1,1,1,3);
    mainLayout->addWidget(StartBit,2,0,1,1);
    mainLayout->addWidget(StartBitEdit,2,1,1,1);
    mainLayout->addWidget(Multiplexortype,3,0,1,1);
    mainLayout->addWidget(MultiplexortypeEdit,3,1,1,3);
    setFixedSize(200,200);
    setLayout(mainLayout);
}
MessageTabMsgSign::MessageTabMsgSign(const MainDbCommonItem *item, QWidget *parent)
    : QWidget(parent)
{
    MainDbCommonItem * testItem =const_cast<MainDbCommonItem *>(item);
    QLabel *fileNameLabel = new QLabel(tr("Name:"));
    fileNameEdit = new QLineEdit(testItem->parent()->data(0).toString());

    QLabel *Type = new QLabel(tr("Type:"));
    TypeEdit = new QComboBox;
    TypeEdit->addItem("Standard");
    TypeEdit->addItem("Extended");
    if(!QString("Extended").compare(testItem->parent()->data(2).toString())){
        TypeEdit->setCurrentIndex(1);
    }else{
        TypeEdit->setCurrentIndex(0);
    }
    QLabel *ID = new QLabel(tr("ID:"));
    IDEdit = new QLineEdit(testItem->parent()->data(1).toString());


    QLabel *DLC = new QLabel(tr("DLC:"));
    DLCEdit = new QSpinBox;
    DLCEdit->setMinimum(0);
    DLCEdit->setMaximum(8);
    DLCEdit->setValue(testItem->parent()->data(3).toInt());

    QLabel *Transmitter = new QLabel(tr("Transmitter:"));
    TransmitterEdit = new QComboBox;
    TransmitterEdit->addItem("ABS");
    TransmitterEdit->setEnabled(false);

    QLabel *TxMethod = new QLabel(tr("Tx Method:"));
    TxMethodEdit = new QComboBox;
    TxMethodEdit->addItem(testItem->parent()->data(2).toString());
    TxMethodEdit->setEnabled(false);

    QLabel *CycleTime = new QLabel(tr("Cycle Time:"));
    CycleTimeEdit = new QLineEdit(testItem->parent()->data(3).toString());
    CycleTimeEdit->setEnabled(false);

    QGridLayout *mainLayout = new QGridLayout;
    mainLayout->addWidget(fileNameLabel,0,0,1,1);
    mainLayout->addWidget(fileNameEdit,0,1,1,3);
    mainLayout->addWidget(Type,1,0,1,1);
    mainLayout->addWidget(TypeEdit,1,1,1,3);
    mainLayout->addWidget(ID,2,0,1,1);
    mainLayout->addWidget(IDEdit,2,1,1,1);
    mainLayout->addWidget(DLC,2,2,1,1);
    mainLayout->addWidget(DLCEdit,2,3,1,1);
    mainLayout->addWidget(Transmitter,3,0,1,1);
    mainLayout->addWidget(TransmitterEdit,3,1,1,3);
    mainLayout->addWidget(TxMethod,4,0,1,1);
    mainLayout->addWidget(TxMethodEdit,4,1,1,3);
    mainLayout->addWidget(CycleTime,5,0,1,1);
    mainLayout->addWidget(CycleTimeEdit,5,1,1,3);
    setFixedSize(300,300);
    setLayout(mainLayout);
}
SignalsTabMsgSign::SignalsTabMsgSign(const MainDbCommonItem *item, QWidget *parent)
    : QWidget(parent)
{
    QLabel *fileNameLabel = new QLabel(tr("Name:"));
    fileNameEdit = new QLineEdit(item->data(0).toString());

    QLabel *Length = new QLabel(tr("Length [Bit]:"));
    LengthEdit = new QLineEdit(item->data(2).toString());

    QLabel *ByteOrder = new QLabel(tr("Byte Order:"));
    ByteOrderEdit = new QComboBox;
    ByteOrderEdit->addItem("Intel");
    ByteOrderEdit->addItem("Motorola");
//    if(!QString("Intel").compare(item->data(5).toString())){
//        qDebug()<<"intel";
//        ByteOrderEdit->setCurrentIndex(0);
//    }else{
//        ByteOrderEdit->setCurrentIndex(1);
//        qDebug()<<"moto";
//    }
    ByteOrderEdit->setCurrentIndex(item->data(3).toInt());
    QLabel *Unit = new QLabel(tr("Unit:"));
    UnitEdit = new QLineEdit("");

    QLabel *ValueType = new QLabel(tr("Value Type:"));
    ValueTypeEdit = new QComboBox;
    ValueTypeEdit->addItem("Signed");
    ValueTypeEdit->addItem("Unsigned");
    ValueTypeEdit->addItem("Float");
    ValueTypeEdit->addItem("Double");
    qDebug()<<"Type value "<<item->data(6).toString();
//    if(!QString("Signed").compare(item->data(6).toString())){
//        qDebug()<<"signed";
//        ValueTypeEdit->setCurrentIndex(0);
//    }else if(!QString("Unsigned").compare(item->data(6).toString())){
//        qDebug()<<"unsigned";
//        ValueTypeEdit->setCurrentIndex(1);
//    }else if(!QString("Float").compare(item->data(6).toString())){
//        qDebug()<<"float";
//        ValueTypeEdit->setCurrentIndex(2);
//    }else {
//        qDebug()<<"double";
//        ValueTypeEdit->setCurrentIndex(3);
//    }
//    for(int i=0;i<item->columnCount()-1;i++){
//        qDebug()<<item->data(i).toString();
//    }
    ValueTypeEdit->setCurrentIndex(item->data(5).toInt());
    QLabel *IntValue = new QLabel(tr("Int. Value:"));
    IntValueEdit = new QLineEdit(item->data(6).toString());

    QLabel *Factor = new QLabel(tr("Factor:"));
    FactorEdit = new QLineEdit(item->data(7).toString());

    QLabel *Offset = new QLabel(tr("Offset:"));
    OffsetEdit = new QLineEdit(item->data(8).toString());

    QLabel *Minimum = new QLabel(tr("Minimum:"));
    MinimumEdit = new QLineEdit(item->data(9).toString());

    QLabel *Maximum = new QLabel(tr("Maximum:"));
    MaximumEdit = new QLineEdit(item->data(10).toString());

    QLabel *ValueTable = new QLabel(tr("Value Table:"));
    QComboBox *ValueTableEdit = new QComboBox;
    ValueTableEdit->addItem("<none>");
    ValueTableEdit->addItem("Vt Ev_EvGwSwitchlgnition");
    ValueTableEdit->addItem("VtSin_Active");

    QCheckBox *Automatic = new QCheckBox(tr("Automatic min-max calculation"));

    QGridLayout *mainLayout = new QGridLayout;
    mainLayout->addWidget(fileNameLabel,0,0,1,1);
    mainLayout->addWidget(fileNameEdit,0,1,1,3);
    mainLayout->addWidget(Length,1,0,1,1);
    mainLayout->addWidget(LengthEdit,1,1,1,1);
    mainLayout->addWidget(ByteOrder,2,0,1,1);
    mainLayout->addWidget(ByteOrderEdit,2,1,1,1);
    mainLayout->addWidget(Unit,2,2,1,1);
    mainLayout->addWidget(UnitEdit,2,3,1,1);
    mainLayout->addWidget(ValueType,3,0,1,1);
    mainLayout->addWidget(ValueTypeEdit,3,1,1,1);
    mainLayout->addWidget(IntValue,3,2,1,1);
    mainLayout->addWidget(IntValueEdit,3,3,1,1);
    mainLayout->addWidget(Factor,4,0,1,1);
    mainLayout->addWidget(FactorEdit,4,1,1,1);
    mainLayout->addWidget(Offset,4,2,1,1);
    mainLayout->addWidget(OffsetEdit,4,3,1,1);
    mainLayout->addWidget(Minimum,5,0,1,1);
    mainLayout->addWidget(MinimumEdit,5,1,1,1);
    mainLayout->addWidget(Maximum,5,2,1,1);
    mainLayout->addWidget(MaximumEdit,5,3,1,1);
    mainLayout->addWidget(ValueTable,6,0,1,1);
    mainLayout->addWidget(ValueTableEdit,6,1,1,3);
    mainLayout->addWidget(Automatic,7,0,1,2);
    setFixedSize(300,300);
    setLayout(mainLayout);
}

ReceiversTabMsgSign::ReceiversTabMsgSign(const MainDbCommonItem *item, QWidget *parent)
    : QWidget(parent)
{
    buttonView = new QPushButton(tr("View"));
    QTreeWidget *signal = new QTreeWidget;
    signal->setColumnCount(2);
    signal->setHeaderLabels(QStringList() << "Name"<< "Address");

    QGridLayout *mainLayout = new QGridLayout;
    mainLayout->addWidget(signal,0,0,10,8);
    mainLayout->addWidget(buttonView,10,10,1,1);
    //mainLayout->addStretch(1);
    setLayout(mainLayout);
}

ValueDescriptionsTabMsgSign::ValueDescriptionsTabMsgSign(const MainDbCommonItem *item, QWidget *parent)
    : QWidget(parent)
{
    buttonAdd = new QPushButton(tr("Add"));
    buttonRemove = new QPushButton(tr("Remove"));
    buttonView = new QPushButton(tr("View"));
    signal = new QTableWidget(10,2,0);
    m1_TableHeader<<"Name"<< "Address";
    signal->setHorizontalHeaderLabels(m1_TableHeader);
    signal->verticalHeader()->setVisible(false);
    signal->setShowGrid(false);

    QGridLayout *mainLayout = new QGridLayout;
    mainLayout->addWidget(signal,0,0,10,8);
    mainLayout->addWidget(buttonAdd,10,0,1,1);
    mainLayout->addWidget(buttonRemove,10,1,1,1);
    mainLayout->addWidget(buttonView,10,10,1,1);
    setLayout(mainLayout);
}

AttributesTabMsgSign::AttributesTabMsgSign(const MainDbCommonItem *item, QWidget *parent)
    : QWidget(parent)
{
    QTextEdit *CommentEdit = new QTextEdit(item->data(33).toString());
    QVBoxLayout *Layout = new QVBoxLayout;
    Layout->addWidget(CommentEdit);
    setLayout(Layout);
}

CommentTabMsgSign::CommentTabMsgSign(const MainDbCommonItem *item, QWidget *parent)
    : QWidget(parent)
{
    QTextEdit *CommentEdit = new QTextEdit(item->data(6).toString());
    QVBoxLayout *Layout = new QVBoxLayout;
    Layout->addWidget(CommentEdit);
    setLayout(Layout);
}
