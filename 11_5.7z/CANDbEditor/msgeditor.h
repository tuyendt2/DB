/****************************************************************************
**
** Copyright (C) 2016 The Qt Company Ltd.
** Contact: https://www.qt.io/licensing/
**
** This file is part of the examples of the Qt Toolkit.
**
** $QT_BEGIN_LICENSE:BSD$
** Commercial License Usage
** Licensees holding valid commercial Qt licenses may use this file in
** accordance with the commercial license agreement provided with the
** Software or, alternatively, in accordance with the terms contained in
** a written agreement between you and The Qt Company. For licensing terms
** and conditions see https://www.qt.io/terms-conditions. For further
** information use the contact form at https://www.qt.io/contact-us.
**
** BSD License Usage
** Alternatively, you may use this file under the terms of the BSD license
** as follows:
**
** "Redistribution and use in source and binary forms, with or without
** modification, are permitted provided that the following conditions are
** met:
**   * Redistributions of source code must retain the above copyright
**     notice, this list of conditions and the following disclaimer.
**   * Redistributions in binary form must reproduce the above copyright
**     notice, this list of conditions and the following disclaimer in
**     the documentation and/or other materials provided with the
**     distribution.
**   * Neither the name of The Qt Company Ltd nor the names of its
**     contributors may be used to endorse or promote products derived
**     from this software without specific prior written permission.
**
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
** "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
** LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
** A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
** OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
** DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
** THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
** (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
** OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
**
** $QT_END_LICENSE$
**
****************************************************************************/

#ifndef MSGEDITOR_H
#define MSGEDITOR_H

#include <QDialog>
#include <QApplication>
#include <QMouseEvent>
#include <QMessageBox>
#include <QTabWidget>
#include <QWidget>
#include <QDialogButtonBox>
#include <QTableWidget>
#include "maindbeditor.h"
#include "CANDefines.h"
QT_BEGIN_NAMESPACE
class QDialogButtonBox;
class QFileInfo;
class QTabWidget;
class QComboBox;
class QSpinBox;
class QTreeView;
QT_END_NAMESPACE

//! [0]
class MainDbCommonItem;
class MainDbEditor;
class MainDbManager;
class DefinitionTabMessage : public QWidget
{
    Q_OBJECT

public:
    explicit DefinitionTabMessage(const MainDbCommonItem *item, QWidget *parent = 0);
    QLineEdit *fileNameEdit ;
    QComboBox *TypeEdit;
    QLineEdit *IDEdit ;
    QSpinBox *DLCEdit;
};
//! [0]


////! [1]
class SignalsTab : public QWidget
{
    Q_OBJECT

public:
    explicit SignalsTab(const MainDbEditor *editor, QWidget *parent = 0);
         QTableWidget *signal;
private slots:
         void slotRemoveSignalInList();
private:
     QPushButton *buttonAdd;
     QPushButton *buttonRemove;
     QPushButton *buttonView;
     QStringList m1_TableHeader;
     MainDbManager * m_mainDbManager;
     QTreeView *m_treeWidget;
};
//! [1]


//! [2]
class TransmittersTabMessage : public QWidget
{
    Q_OBJECT

public:
    explicit TransmittersTabMessage(const QString *, QWidget *parent = 0);
private:
     QPushButton *buttonAdd;
     QPushButton *buttonRemove;
     QPushButton *buttonView;
     QTableWidget *signal;
     QStringList m1_TableHeader;
};
//! [2]
class ReceiversTabMessage : public QWidget
{
    Q_OBJECT

public:
    explicit ReceiversTabMessage(const QString *, QWidget *parent = 0);
    QPushButton *buttonView;
};

class LayoutTabMessage : public QWidget
{
    Q_OBJECT

public:
    explicit LayoutTabMessage(const QString *, QWidget *parent = 0);
};

class AttributesTabMessage : public QWidget
{
    Q_OBJECT

public:
    explicit AttributesTabMessage(const QString *, QWidget *parent = 0);
};

class CommentTabMessage : public QWidget
{
    Q_OBJECT

public:
    explicit CommentTabMessage(const QString , QWidget *parent = 0);
};

//! [3]
class MsgEditor : public QDialog
{
    Q_OBJECT

public:
    explicit MsgEditor(const MainDbCommonItem *item, const MainDbEditor * editor,QWidget *parent = 0);
    QTabWidget *tabWidget;
    QDialogButtonBox *buttonBox;
    AttributesTabMessage *atTabMsg;
    DefinitionTabMessage *DeTabMsg;
    SignalsTab *SignTab;
    TransmittersTabMessage *TransTabMsg;
    ReceiversTabMessage *ReceiTabMsg;
    LayoutTabMessage *LayTabMsg;
    CommentTabMessage *ComTabMsg;
   // QTableWidget *signal;
    MsgEditor   * m_MsgEditorWidget;
    QVector<CANSignalInMessage> addSignalList;
    MainDbEditor * editor;
    void addSigToMess(CANSignal *signal);
    void getListSig();
    void accept();
    void reject();
public slots:
    void slotClickApply();
    void addListSignalToMess(QVector<CANSignal*>);
//private:
signals:
    void editMessage(CANMessage *message);
    void listNewSig(QVector<CANSignalInMessage> sigListInMess);
    void cancel();
};
//! [3]

#endif
