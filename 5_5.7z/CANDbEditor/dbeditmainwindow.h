#ifndef DBEDITMAINWINDOW_H
#define DBEDITMAINWINDOW_H

#include    <QMainWindow>
#include    <maindbeditor.h>
#include    <msgeditor.h>
#include <ui_dbeditmainwindow.h>
class QWidget;

class DbEditMainWindow : public QMainWindow, Ui_MainWindow
{
    Q_OBJECT

public:
    explicit DbEditMainWindow(QWidget *parent = 0);
    ~DbEditMainWindow();

private:
    MainDbEditor * m_mainEditor;
    void setupMenu();
    void setupToolbar();

    void loadDb(QString & path);
    void saveDb(QString & path);
//    bool close();
    void closeEvent(QCloseEvent * evt);
signals:
    void testsig();
private slots:
    void slotCreateNewFile();
    void slotOpenFile();
    void slotSaveFile();
    void slotSaveAsFile();
};

#endif // DBEDITMAINWINDOW_H

