#include "maindbeditor.h"
#include <QMessageBox>
#include <QCloseEvent>
#include <QDebug>
#include"msgeditor.h"
#include<QTreeWidgetItem>
#include <QSplitter>
#include "tabdialog.h"
#include "tabdialogSignalMessage.h"
#include <QGridLayout>
#include <QTableWidget>
#include <QPushButton>
MainDbEditor::MainDbEditor(QWidget *parent , QString  path ):
    QMainWindow(parent),
    m_mainDbManager(NULL),
   m_MsgEditorWidget(NULL)
{
    setupUi(this);
    QSplitter * splitter = new QSplitter(Qt::Horizontal,this);
    splitter->addWidget(m_treeWidget);
    splitter->addWidget(m_stackedWidget);
    QGridLayout * gridLayout = new QGridLayout;
    gridLayout->addWidget(splitter);
    centralWidget()->setLayout(gridLayout);
    m_stackedWidget->removeWidget(m_pageCom);
    m_stackedWidget->removeWidget(m_pageSignals);
    m_stackedWidget->removeWidget(m_pageMsgs);
    m_stackedWidget->addWidget(m_MsgsTableWidget);
    m_stackedWidget->addWidget(m_SignsTableWidget);
    m_stackedWidget->addWidget(m_ComTableWidget);
    m_mainDbManager = new MainDbManager();
    m_mainDbManager->loadDbFile(path);

    m_treeViewModel = new MainDbTreeViewModel(m_mainDbManager,this);
    m_treeWidget->setModel(m_treeViewModel);

    m_tblMsgModel = new MainDbTableMsgsModel(m_mainDbManager,this);
    m_MsgsTableWidget->setModel(m_tblMsgModel);
    lineEditDelegate *lineEditTestDelegate = new lineEditDelegate;
    m_MsgsTableWidget->setItemDelegate(lineEditTestDelegate);
    comboDelegate *messageFormatDelegate= new comboDelegate;
    messageFormatDelegate->listComBovalue=QString("Standard;Extended").split(";");
    m_MsgsTableWidget->setItemDelegateForColumn(2,messageFormatDelegate);
    SpinBoxDelegate *dlcMessageDelegate= new SpinBoxDelegate;
    m_MsgsTableWidget->setItemDelegateForColumn(3,dlcMessageDelegate);

    m_tblSignModel = new MainDbTableSignsModel(m_mainDbManager,this);
    m_SignsTableWidget->setModel(m_tblSignModel);
    m_SignsTableWidget->setItemDelegate(lineEditTestDelegate);
    comboDelegate *signalOderTableDelegate= new comboDelegate;
    signalOderTableDelegate->listComBovalue=QString("Intel;Motorola").split(";");
    m_SignsTableWidget->setItemDelegateForColumn(2,signalOderTableDelegate);
    comboDelegate *signalTypeTableDelegate= new comboDelegate;
    signalTypeTableDelegate->listComBovalue=QString("Signed;Unsigned;Float;Double").split(";");
    m_SignsTableWidget->setItemDelegateForColumn(3,signalTypeTableDelegate);
    checkboxDelegate * checkboxTestDelegate = new checkboxDelegate;
    m_SignsTableWidget->setItemDelegateForColumn(4,checkboxTestDelegate);
// combineTableModel
    m_tblCombineModel=new MainDbTableCombineModel(m_mainDbManager,this,0);
   // m_ComTableWidget->setModel(m_tblCombineModel);
// end combineTableModel
    m_MsgsTableWidget->setShowGrid(false);
    m_SignsTableWidget->setShowGrid(false);
    m_ComTableWidget->setShowGrid(false);

    m_MsgsTableWidget->verticalHeader()->hide();
    m_SignsTableWidget->verticalHeader()->hide();
    m_ComTableWidget->verticalHeader()->hide();

    m_MsgsTableWidget->horizontalHeader()->setDefaultAlignment(Qt::AlignLeft);
    m_SignsTableWidget->horizontalHeader()->setDefaultAlignment(Qt::AlignLeft);
    m_ComTableWidget->horizontalHeader()->setDefaultAlignment(Qt::AlignLeft);

    m_MsgsTableWidget->setContextMenuPolicy(Qt::CustomContextMenu);
    m_SignsTableWidget->setContextMenuPolicy(Qt::CustomContextMenu);
    m_ComTableWidget->setContextMenuPolicy(Qt::CustomContextMenu);
    m_treeWidget->setContextMenuPolicy(Qt::CustomContextMenu);

    connect(m_treeWidget,SIGNAL(clicked(QModelIndex)),this, SLOT(slotOneClickTree(QModelIndex)));
    connect(m_treeWidget,SIGNAL(doubleClicked(QModelIndex)),this, SLOT(slotDoubleClickTree(QModelIndex)));

    connect(m_treeWidget,SIGNAL(customContextMenuRequested(QPoint)),this, SLOT(slotContextMenuTreeWidget(QPoint)));

    connect(m_MsgsTableWidget,SIGNAL(clicked(QModelIndex)),this, SLOT(slotOneClickMsgsTab(QModelIndex)));
    connect(m_MsgsTableWidget,SIGNAL(doubleClicked(QModelIndex)),this, SLOT(slotDoubleClickMsgsTab(QModelIndex)));

    connect(m_MsgsTableWidget,SIGNAL(customContextMenuRequested(QPoint)),this, SLOT(slotContextMenuMsgTable(QPoint)));
    connect(m_SignsTableWidget,SIGNAL(customContextMenuRequested(QPoint)),this, SLOT(slotContextMenuSignsTable(QPoint)));

    connect(m_SignsTableWidget,SIGNAL(doubleClicked(QModelIndex)),this, SLOT(slotDoubleClickSignsTab(QModelIndex)));

    connect(m_tblMsgModel,SIGNAL(updateByDelegate(QModelIndex)),this,SLOT(updateByDelegateOnMessTbl(QModelIndex)));
    connect(m_tblSignModel,SIGNAL(updateByDelegate(QModelIndex)),this,SLOT(updateByDelegateOnSigTbl(QModelIndex)));

    connect(m_ComTableWidget,SIGNAL(customContextMenuRequested(QPoint)),this, SLOT(slotContextMenuCombTable(QPoint)));
    connect(m_ComTableWidget,SIGNAL(doubleClicked(QModelIndex)),this, SLOT(slotDoubleClickCombTab(QModelIndex)));

//    CANSignal *newSign = new CANSignal;
//    newSign->m_Name = QString("dont_delegate_me!");
//    newSign->m_Length =8;
//    newSign->m_ValueType = E_CANSignalSign_UnSigned;
//    newSign->m_ByteOrder = E_CANByteOrder_Motorola;
//    newSign->m_Factor.dValue = 1;
//    newSign->m_Offset.dValue = 0;
//    newSign->m_Min.dValue =0;
//    newSign->m_Max.dValue =100;
//    newSign->m_InitValue.dValue = 0;
//    qDebug()<<"size = "<<m_mainDbManager->m_CANSignals.size();
//    m_mainDbManager->m_CANSignals.append(const_cast<CANSignal*>(newSign));
//    CANSignalInMessage newMessSig;
//    newMessSig.m_Signal=newSign;
//    newMessSig.m_StartBit=0;
//    m_mainDbManager->m_CANMessages.at(0)->m_Signals.append(newMessSig);
//    qDebug()<<"size = "<<m_mainDbManager->m_CANSignals.size();
//    //MainDbCommonItem *item ;

//    QVector<QVariant*> data;
//    data<<(new QVariant("change or die"));
//    qDebug()<<data.at(0)->toString();
}

MainDbEditor::~MainDbEditor()
{
    /*TODO: remove db list*/
    if(m_mainDbManager) delete m_mainDbManager;
    if(m_MsgEditorWidget!=NULL) {
        qDebug()<<"haha";
       // delete m_MsgEditorWidget;
    }
}

void MainDbEditor::slotOneClickTree(QModelIndex index){
    switch (m_treeViewModel->getItem(index)->getType()) {

    case E_DbItemType_Header:
        if(m_treeViewModel->getItem(index)->data(0) == QString("Messages")){
            m_MsgsTableWidget->setVisible(true);
            m_SignsTableWidget->setVisible(false);
            m_ComTableWidget->setVisible(false);
            delete m_tblMsgModel;
            m_tblMsgModel = new MainDbTableMsgsModel(m_mainDbManager,this);
            m_MsgsTableWidget->setModel(m_tblMsgModel);
            lineEditDelegate *lineEditTestDelegate = new lineEditDelegate;
            m_MsgsTableWidget->setItemDelegate(lineEditTestDelegate);
            comboDelegate *messageFormatDelegate= new comboDelegate;
            messageFormatDelegate->listComBovalue=QString("Standard;Extended").split(";");
            m_MsgsTableWidget->setItemDelegateForColumn(2,messageFormatDelegate);
            SpinBoxDelegate *dlcMessageDelegate= new SpinBoxDelegate;
            m_MsgsTableWidget->setItemDelegateForColumn(3,dlcMessageDelegate);
            connect(m_tblMsgModel,SIGNAL(updateByDelegate(QModelIndex)),this,SLOT(updateByDelegateOnMessTbl(QModelIndex)));
            //connect(m_MsgsTableWidget,SIGNAL(doubleClicked(QModelIndex)),this, SLOT(slotDoubleClickMsgsTab(QModelIndex)));
        }else if(m_treeViewModel->getItem(index)->data(0) == QString("Signals")){
            m_MsgsTableWidget->setVisible(false);
            m_SignsTableWidget->setVisible(true);
            m_ComTableWidget->setVisible(false);
            delete m_tblSignModel;
            m_tblSignModel = new MainDbTableSignsModel(m_mainDbManager,this);
            m_SignsTableWidget->setModel(m_tblSignModel);
            lineEditDelegate *lineEditTestDelegate = new lineEditDelegate;
            m_SignsTableWidget->setItemDelegate(lineEditTestDelegate);
            comboDelegate *signalOderTableDelegate= new comboDelegate;
            signalOderTableDelegate->listComBovalue=QString("Intel;Motorola").split(";");
            m_SignsTableWidget->setItemDelegateForColumn(2,signalOderTableDelegate);
            comboDelegate *signalTypeTableDelegate= new comboDelegate;
            signalTypeTableDelegate->listComBovalue=QString("Signed;Unsigned;Float;Double").split(";");
            m_SignsTableWidget->setItemDelegateForColumn(3,signalTypeTableDelegate);
            checkboxDelegate * checkboxTestDelegate = new checkboxDelegate;
            m_SignsTableWidget->setItemDelegateForColumn(4,checkboxTestDelegate);
            connect(m_tblSignModel,SIGNAL(updateByDelegate(QModelIndex)),this,SLOT(updateByDelegateOnSigTbl(QModelIndex)));
        }
        break;

     case E_DbItemType_Signal:
    {
        //delete m_tblCombineModel;
        delete m_tblCombineModel;
        m_tblCombineModel=new MainDbTableCombineModel(m_mainDbManager,this,index);
        m_ComTableWidget->setModel(m_tblCombineModel);
        comboDelegate *signalOderTableDelegate= new comboDelegate;
        signalOderTableDelegate->listComBovalue=QString("Intel;Motorola").split(";");
        m_ComTableWidget->setItemDelegateForColumn(5,signalOderTableDelegate);
        comboDelegate *signalTypeTableDelegate= new comboDelegate;
        signalTypeTableDelegate->listComBovalue=QString("Signed;Unsigned;Float;Double").split(";");
        m_ComTableWidget->setItemDelegateForColumn(6,signalTypeTableDelegate);
//        connect(m_tblCombineModel,SIGNAL(updateByDelegate(QModelIndex)),
//                this,SLOT(updateTreeViewByDelegateOnCombineTbl(QModelIndex)));
        connect(m_tblCombineModel,SIGNAL(updateByDelegate(QModelIndex)),
                this,SLOT(updateByDelegateOnCombineTbl(QModelIndex)));
        m_MsgsTableWidget->setVisible(false);
        m_SignsTableWidget->setVisible(false);
        m_ComTableWidget->setVisible(true);
        break;
    }

     case E_DbItemType_SignalInMessage:
    {
        //delete m_tblCombineModel;
        m_tblCombineModel=new MainDbTableCombineModel(m_mainDbManager,this,index);
        m_ComTableWidget->setModel(m_tblCombineModel);
            comboDelegate *signalOderTableDelegate= new comboDelegate;
            signalOderTableDelegate->listComBovalue=QString("Intel;Motorola").split(";");
            m_ComTableWidget->setItemDelegateForColumn(5,signalOderTableDelegate);
            comboDelegate *signalTypeTableDelegate= new comboDelegate;
            signalTypeTableDelegate->listComBovalue=QString("Signed;Unsigned;Float;Double").split(";");
            m_ComTableWidget->setItemDelegateForColumn(6,signalTypeTableDelegate);
//            connect(m_tblCombineModel,SIGNAL(updateByDelegate(QModelIndex)),
//                    this,SLOT(updateTreeViewByDelegateOnCombineTbl(QModelIndex)));
            connect(m_tblCombineModel,SIGNAL(updateByDelegate(QModelIndex)),
                    this,SLOT(updateByDelegateOnCombineTbl(QModelIndex)));
            m_MsgsTableWidget->setVisible(false);
            m_SignsTableWidget->setVisible(false);
            m_ComTableWidget->setVisible(true);
            break;
    }
     case E_DbItemType_Message:{
        //delete m_tblCombineModel;
        m_tblCombineModel=new MainDbTableCombineModel(m_mainDbManager,this,index);
        m_ComTableWidget->setModel(m_tblCombineModel);
        comboDelegate *signalOderTableDelegate= new comboDelegate;
        signalOderTableDelegate->listComBovalue=QString("Intel;Motorola").split(";");
        m_ComTableWidget->setItemDelegateForColumn(5,signalOderTableDelegate);
        comboDelegate *signalTypeTableDelegate= new comboDelegate;
        signalTypeTableDelegate->listComBovalue=QString("Signed;Unsigned;Float;Double").split(";");
        m_ComTableWidget->setItemDelegateForColumn(6,signalTypeTableDelegate);
//        connect(m_tblCombineModel,SIGNAL(updateByDelegate(QModelIndex)),
//                this,SLOT(updateTreeViewByDelegateOnCombineTbl(QModelIndex)));
        connect(m_tblCombineModel,SIGNAL(updateByDelegate(QModelIndex)),
                this,SLOT(updateByDelegateOnCombineTbl(QModelIndex)));
        m_MsgsTableWidget->setVisible(false);
        m_SignsTableWidget->setVisible(false);
        m_ComTableWidget->setVisible(true);
        break;
    }
    default:
        break;
    }
    m_MsgsTableWidget->resize(m_stackedWidget->size());
    m_SignsTableWidget->resize(m_stackedWidget->size());
    m_ComTableWidget->resize(m_stackedWidget->size());
}

void MainDbEditor::slotDoubleClickTree(QModelIndex index){
    switch (m_treeViewModel->getItem(index)->getType()) {
    case E_DbItemType_Header:
    {
        //TODO: collapse/expand
    }
        break;
    case E_DbItemType_Message:
    {
        //TODO: Open editor message
        qDebug()<<"open mesage editor";
//       QModelIndex table_index= m_MsgsTableWidget->model()->index(index.row(),index.column());
//       MainDbCommonItem *item = static_cast<MainDbCommonItem*>( table_index.internalPointer());
       MainDbCommonItem *item = static_cast<MainDbCommonItem*>(index.internalPointer());
       m_MsgEditorWidget = new MsgEditor(item,this);
      // m_MsgEditorWidget->atTab->
       m_MsgEditorWidget->show();
       m_MsgEditorWidget->setWindowIcon(QPixmap(":/logo.png"));
       connect(m_MsgEditorWidget,SIGNAL(editMessage(CANMessage*,QModelIndex,QModelIndex,QModelIndex)),this,SLOT(slotEditMess(CANMessage*,QModelIndex,QModelIndex,QModelIndex)));
       connect(m_MsgEditorWidget,SIGNAL(listNewSig(QVector<CANSignalInMessage>,QModelIndex,QModelIndex)),this,
               SLOT(updateSigListInMess(QVector<CANSignalInMessage>,QModelIndex,QModelIndex)));
    }
        break;
    case E_DbItemType_Signal:
    {
        //TODO: Open editor signal
        // QModelIndex table_index= m_SignsTableWidget->model()->index(index.row(),index.column());
         MainDbCommonItem *item = static_cast<MainDbCommonItem*>( index.internalPointer());
         m_SignalEditorWidget = new TabDialogMess(item,this);
         m_SignalEditorWidget->show();
         m_SignalEditorWidget->setWindowIcon(QPixmap(":/logo.png"));
         connect(m_SignalEditorWidget,SIGNAL(editSig(CANSignal*,QModelIndex,QModelIndex,QModelIndex)),this,SLOT(slotEditSig(CANSignal*,QModelIndex,QModelIndex,QModelIndex)));
    }
        break;
    case E_DbItemType_SignalInMessage:
    {
        //TODO: Open editor signal in message
        MainDbCommonItem *item = static_cast<MainDbCommonItem*>(index.internalPointer());
        m_SignMsgEditorWidget = new TabDialogSignalMessage(item,this);
        m_SignMsgEditorWidget->show();
        m_SignMsgEditorWidget->setWindowIcon(QPixmap(":/logo.png"));
        connect(m_SignMsgEditorWidget,SIGNAL(editSignal(CANSignal*)),this,SLOT(slotEditSignal(CANSignal*)));
        connect(m_SignMsgEditorWidget,SIGNAL(editMess(CANMessage*,QModelIndex,QModelIndex,QModelIndex)),this,SLOT(slotEditMess(CANMessage*,QModelIndex,QModelIndex,QModelIndex)));
        connect(m_SignMsgEditorWidget,SIGNAL(editsBit(int)),this,SLOT(slotsBit(int)));
    }
        break;
    default:
        break;
    }

}

void MainDbEditor::slotOneClickMsgsTab(QModelIndex index)
{
    //    qDebug() << index.column() << "x" << index.row();
}


void  MainDbEditor::slotContextMenuMsgTable(QPoint  point)
{
    QMenu *rightClickMenu = new QMenu(this);

    QAction *actionEdit = new QAction(QIcon(":icons/edit.png"),QString("Edit"),this);
    //    connect(actionEdit, SIGNAL(triggered()),  this, SLOT(slotOpenMessageEditor()));

    QAction *actionRemove = new QAction(QIcon(":icons/remove.png"),QString("Remove"),this);
       //connect(actionRemove, SIGNAL(triggered()),  this, SLOT(slotRemoveMessage()));

    rightClickMenu->addAction(actionEdit);
    rightClickMenu->addSeparator();
    rightClickMenu->addAction(actionRemove);

    QPoint globalPos = m_MsgsTableWidget->mapToGlobal(point);
    rightClickMenu->popup(globalPos);
}
void MainDbEditor::slotDoubleClickMsgsTab(QModelIndex index)
{
   // delete m_MsgEditorWidget;
    QModelIndex  messRootIndex=this->m_treeViewModel->index(0,0,QModelIndex());
    MainDbCommonItem * messRootItem = static_cast<MainDbCommonItem*>(messRootIndex.internalPointer());
    m_MsgEditorWidget = new MsgEditor(messRootItem->child(index.row()),this);
    m_MsgEditorWidget->setModal(true);
    m_MsgEditorWidget->show();
    connect(m_MsgEditorWidget,SIGNAL(editMessage(CANMessage*,QModelIndex,QModelIndex,QModelIndex)),this,SLOT(slotEditMess(CANMessage*,QModelIndex,QModelIndex,QModelIndex)));
    connect(m_MsgEditorWidget,SIGNAL(listNewSig(QVector<CANSignalInMessage>,QModelIndex,QModelIndex)),this,
            SLOT(updateSigListInMess(QVector<CANSignalInMessage>,QModelIndex,QModelIndex)));
}

void MainDbEditor::slotOneClickSignsTab(QModelIndex index)
{

}

void MainDbEditor::slotDoubleClickSignsTab(QModelIndex index)
{
    MainDbCommonItem *item = static_cast<MainDbCommonItem*>(index.internalPointer());
    m_SignalEditorWidget = new TabDialogMess(item,this);
    m_SignalEditorWidget->setModal(true);
    m_SignalEditorWidget->show();
    connect(m_SignalEditorWidget,SIGNAL(editSig(CANSignal*,QModelIndex,QModelIndex,QModelIndex)),this,SLOT(slotEditSig(CANSignal*,QModelIndex,QModelIndex,QModelIndex)));
}
void MainDbEditor::slotOneClickCombTab(QModelIndex index)
{

}

void MainDbEditor::slotDoubleClickCombTab(QModelIndex index)
{
    QModelIndex currentIndex= this->m_treeWidget->currentIndex();
    MainDbCommonItem *curItem = static_cast<MainDbCommonItem*> (currentIndex.internalPointer());
 //   QModelIndex tblIndex=this->m_ComTableWidget->currentIndex();
 //   MainDbCommonItem * tablItem = static_cast<MainDbCommonItem*>(tblIndex.internalPointer());
 //   QModelIndex treeSignalInMessIndex = currentIndex.child(tblIndex.row(),0);

 //   MainDbCommonItem * treeSignalItem =static_cast<MainDbCommonItem*> (treeSignalInMessIndex.internalPointer());
 //       treeSignalItem->setData(0,currentIndex.child());
    MainDbCommonItem *currentItem =static_cast<MainDbCommonItem*>(currentIndex.internalPointer());
 if(curItem->getType()==E_DbItemType_Message){
        MainDbCommonItem *childItem=currentItem->child(index.row());
        m_SignMsgEditorWidget = new TabDialogSignalMessage(childItem,this);
        m_SignMsgEditorWidget->setModal(true);
        m_SignMsgEditorWidget->show();
    connect(m_SignMsgEditorWidget,SIGNAL(editsBit(int)),this,SLOT(slotsBit(int)));
    connect(m_SignMsgEditorWidget,SIGNAL(editSignal(CANSignal*)),this,SLOT(slotEditSignal(CANSignal*)));
    connect(m_SignMsgEditorWidget,SIGNAL(editMess(CANMessage*,QModelIndex,QModelIndex,QModelIndex)),this,SLOT(slotEditMess(CANMessage*,QModelIndex,QModelIndex,QModelIndex)));

 }
 else if(curItem->getType()==E_DbItemType_SignalInMessage){
     qDebug()<<"E_DbItemType_SignalInMessage";
    // MainDbCommonItem *parentItem=currentItem->parent()->child(index.row());
     m_SignMsgEditorWidget = new TabDialogSignalMessage(currentItem,this);
     m_SignMsgEditorWidget->setModal(true);
     m_SignMsgEditorWidget->show();
     connect(m_SignMsgEditorWidget,SIGNAL(editsBit(int)),this,SLOT(slotsBit(int)));
     connect(m_SignMsgEditorWidget,SIGNAL(editSignal(CANSignal*)),this,SLOT(slotEditSignal(CANSignal*)));
     connect(m_SignMsgEditorWidget,SIGNAL(editMess(CANMessage*,QModelIndex,QModelIndex,QModelIndex)),this,SLOT(slotEditMess(CANMessage*,QModelIndex,QModelIndex,QModelIndex)));
 }
 else if(curItem->getType()==E_DbItemType_Signal){
     QModelIndex  messRootIndex=this->m_treeViewModel->index(0,0,QModelIndex());
     MainDbCommonItem * messRootItem = static_cast<MainDbCommonItem*>(messRootIndex.internalPointer());
     MainDbCommonItem * QSigItem;
     int k=-1;
     for(int i=0;i<this->m_mainDbManager->getMessagesList().size();i++){
         for(int j=0;j<this->m_mainDbManager->getMessagesList().at(i)->m_Signals.size();j++){
             if(compareSignal(this->m_mainDbManager->getMessagesList().at(i)->m_Signals.at(j).m_Signal,
                              this->m_mainDbManager->getSignalsList().at(currentIndex.row())))
             {
                k++;
                if(k==index.row()){
                QSigItem =messRootItem->child(i)->child(j);
                }
             }
         }
     }
     m_SignMsgEditorWidget = new TabDialogSignalMessage(QSigItem,this);
     m_SignMsgEditorWidget->setModal(true);
     m_SignMsgEditorWidget->show();
   connect(m_SignMsgEditorWidget,SIGNAL(editsBit(int)),this,SLOT(slotsBit(int)));
   connect(m_SignMsgEditorWidget,SIGNAL(editSignal(CANSignal*)),this,SLOT(slotEditSignal(CANSignal*)));
   connect(m_SignMsgEditorWidget,SIGNAL(editMess(CANMessage*,QModelIndex,QModelIndex,QModelIndex)),this,SLOT(slotEditMess(CANMessage*,QModelIndex,QModelIndex,QModelIndex)));
}
}
void  MainDbEditor::slotContextMenuSignsTable(QPoint  point)
{
    QMenu *rightClickMenu = new QMenu(this);
    QAction *actionEdit = new QAction(QIcon(":icons/edit.png"),QString("Edit"),this);
    //    connect(actionEdit, SIGNAL(triggered()),  this, SLOT(slotOpenSignalEditor()));
    QAction *actionRemove = new QAction(QIcon(":icons/remove.png"),QString("Remove"),this);
    //    connect(actionRemove, SIGNAL(triggered()),  this, SLOT(slotRemoveSignal()));
    rightClickMenu->addAction(actionEdit);
    rightClickMenu->addSeparator();
    rightClickMenu->addAction(actionRemove);
    QPoint globalPos = m_SignsTableWidget->mapToGlobal(point);
    rightClickMenu->popup(globalPos);
}

void MainDbEditor::slotEditMess(CANMessage *message,QModelIndex treeCurIndex,QModelIndex messTblIndex,QModelIndex comTblIndex){
qDebug()<<"slotEditMess";
    //QModelIndex currentIndex= this->m_treeWidget->currentIndex();
    MainDbCommonItem * curItem = static_cast<MainDbCommonItem*>(treeCurIndex.internalPointer());
    MainDbCommonItem * treeMessItem ;
    CANMessage *editMessage;
   // QModelIndex comTblIndex = this->m_ComTableWidget->currentIndex();
    QModelIndex  messRootIndex=this->m_treeViewModel->index(0,0,QModelIndex());
    MainDbCommonItem * messRootItem = static_cast<MainDbCommonItem*>(messRootIndex.internalPointer());
    if(curItem->data(0).toString()=="Messages"){
    //MainDbCommonItem *curItem = static_cast<MainDbCommonItem*> (currentIndex.internalPointer());
    //QModelIndex tblIndex=this->m_MsgsTableWidget->currentIndex();
    MainDbCommonItem * tablItem = static_cast<MainDbCommonItem*>(messTblIndex.internalPointer());
        qDebug()<<messTblIndex;
    if(messTblIndex.row()!=-1){
    //update table model

     qDebug()<<"edit message on Messtable";
    tablItem->setData(0,message->m_Name);
    tablItem->setData(1,message->m_ID);
    tablItem->setData(2,(message->m_IdType == E_CANMsgIDType_Standard ? "Standard": "Extended"));
    tablItem->setData(3,message->m_Length);
    editMessage=this->m_mainDbManager->getMessagesList().at(messTblIndex.row());
        QModelIndex treeMessIndex = treeCurIndex.child(messTblIndex.row(),0);
        treeMessItem=static_cast<MainDbCommonItem*> (treeMessIndex.internalPointer());
             qDebug()<<"edit message on Messtable 2";
    }else{
         qDebug()<<"edit with new action";
        // edit with new action
        editMessage=this->m_mainDbManager->getMessagesList().constLast();
        treeMessItem =curItem->child(curItem->childCount()-1);
    }
    }else if(curItem->getType()==E_DbItemType_Message){
        editMessage=this->m_mainDbManager->getMessagesList().at(treeCurIndex.row());
        treeMessItem =curItem;
      // emit this->m_treeWidget->clicked(currentIndex);
    }else if(curItem->getType()==E_DbItemType_SignalInMessage){
        editMessage= this->m_mainDbManager->getMessagesList().at(treeCurIndex.parent().row());
        treeMessItem = curItem->parent();
    }else if(curItem->getType()==E_DbItemType_Signal){
        //int indexSigInMess =comTblIndex.row();
        int temp =0;
        for(int i=0;i<this->m_mainDbManager->getMessagesList().size();i++){
            for(int j=0;j<this->m_mainDbManager->getMessagesList().at(i)->m_Signals.size();j++){
                if(compareSignal(this->m_mainDbManager->getSignalsList().at(treeCurIndex.row()),
                                 this->m_mainDbManager->getMessagesList().at(i)->m_Signals.at(j).m_Signal)){
                    if(temp==comTblIndex.row()){
                        editMessage= this->m_mainDbManager->getMessagesList().at(i);
                        treeMessItem = messRootItem->child(i);
                    }
                    temp++;
                }
            }
        }
    }
    treeMessItem->setData(0,message->m_Name);
    treeMessItem->setData(1,message->m_ID);
    treeMessItem->setData(2,(message->m_IdType == E_CANMsgIDType_Standard ? "Standard": "Extended"));
    treeMessItem->setData(3,message->m_Length);
    copyMessage(editMessage,message);
    //emit this->m_treeWidget->clicked(treeCurIndex);
}

void MainDbEditor::slotEditSig(CANSignal *sig,QModelIndex treeCurIndex,QModelIndex tblIndex,QModelIndex tblComIndex){
    qDebug()<<"slotEditSig";
  //  QModelIndex treeCurIndex= this->m_treeWidget->currentIndex();
    MainDbCommonItem *treeCurItem = static_cast<MainDbCommonItem*> (treeCurIndex.internalPointer());
    QModelIndex  messRootIndex=this->m_treeViewModel->index(0,0,QModelIndex());
    MainDbCommonItem * messRootItem = static_cast<MainDbCommonItem*>(messRootIndex.internalPointer());
    QModelIndex  sigRootIndex=this->m_treeViewModel->index(1,0,QModelIndex());
    MainDbCommonItem * sigRootItem = static_cast<MainDbCommonItem*>(sigRootIndex.internalPointer());
    CANSignal *editSig;
    if(treeCurItem->data(0).toString()=="Signals"){
        // edit when click on m_SignsTableWidget
  //  QModelIndex tblIndex=this->m_SignsTableWidget->currentIndex();
    if(tblIndex.row()!=-1){
    MainDbCommonItem * tablItem = static_cast<MainDbCommonItem*>(tblIndex.internalPointer());
    //update table model
    tablItem->setData(0,sig->m_Name);
    tablItem->setData(1,sig->m_Length);
    tablItem->setData(2,(sig->m_ByteOrder == E_CANByteOrder_Intel ? "Intel": "Motorola"));
    if(sig->m_ValueType== E_CANSignalSign_Signed){
        tablItem->setData(3,"Signed");
          }else if(sig->m_ValueType  == E_CANSignalSign_UnSigned){
        tablItem->setData(3,"Unsigned");
          }else if(sig->m_ValueType == E_CANSignalSign_Float){
        tablItem->setData(3,"Float");
          }else{
        tablItem->setData(3,"Double");
          }
    tablItem->setData(4,sig->m_InitValue.dValue);
    tablItem->setData(5,sig->m_Factor.dValue);
    tablItem->setData(6,sig->m_Offset.dValue);
    tablItem->setData(7,sig->m_Min.dValue);
    tablItem->setData(8,sig->m_Max.dValue);
    tablItem->setData(9,sig->m_Comment);

  //  MainDbCommonItem *curItem =sigRootItem->child(tblIndex.row());
       editSig=this->m_mainDbManager->getSignalsList().at(tblIndex.row());
        //editSig =this->m_mainDbManager->m_CANSignals.at(tblIndex.row());
    }else{
        // edit with new action
        qDebug()<<"edit with new action";
        editSig= this->m_mainDbManager->getSignalsList().constLast();

    }

  }else{
    // edit when double click on treeview
    editSig=this->m_mainDbManager->getSignalsList().at(treeCurIndex.row());
       // editSig=this->m_mainDbManager->m_CANSignals.at(treeCurIndex.row());

    }
    for(int i=0;i<this->m_mainDbManager->getMessagesList().size();i++)
    {
        for(int j=0;j<this->m_mainDbManager->getMessagesList().at(i)->m_Signals.size();j++)
        {
            if(compareSignal(this->m_mainDbManager->getMessagesList().at(i)->m_Signals.at(j).m_Signal,editSig))
            {
                MainDbCommonItem * sigItem = messRootItem->child(i)->child(j);
                sigItem->setData(0,sig->m_Name);
                sigItem->setData(1,sig->m_Length);
                //sigItem->setData(2,sig->m_ByteOrder);
                sigItem->setData(3,sig->m_ByteOrder);
                sigItem->setData(4,sig->m_ByteOrder);
                sigItem->setData(5,sig->m_ByteOrder);
                sigItem->setData(6,sig->m_ValueType);
//                sigItem->setData(7,sig->m_InitValue);
//                sigItem->setData(8,sig->m_Factor);
            }
         }
    }
    for(int i=0;i<this->m_mainDbManager->getSignalsList().size();i++){
        if(compareSignal(this->m_mainDbManager->getSignalsList().at(i),editSig)){
            MainDbCommonItem * sigItem = sigRootItem->child(i);
            sigItem->setData(0,sig->m_Name);
        }
    }
    copySignal(editSig,sig);
    //editSig=sig;
//    if(treeCurItem->data(0).toString()=="Signals"){
//    emit this->m_treeWidget->clicked(sigRootIndex);
//    }else{
//    emit this->m_treeWidget->clicked(treeCurIndex);
//    }
    if(treeCurItem->data(0).toString()!="Signals"){
    emit this->m_treeWidget->clicked(treeCurIndex);
    }



    //        curItem->setData(0,sig->m_Name);
    //        curItem->setData(2,sig->m_Length);
    //        curItem->setData(3,(sig->m_ByteOrder == E_CANByteOrder_Intel ? "Intel": "Motorola"));
    //        if(sig->m_ValueType== E_CANSignalSign_Signed){
    //            curItem->setData(5,"Signed");000.
    //              }else if(sig->m_ValueType  == E_CANSignalSign_UnSigned){
    //            curItem->setData(5,"Unsigned");
    //              }else if(sig->m_ValueType == E_CANSignalSign_Float){
    //            curItem->setData(5,"Float");
    //              }else{
    //            curItem->setData(5,"Double");
    //              }
    //        curItem->setData(4,sig->m_Unit.dValue);
    //        curItem->setData(6,sig->m_InitValue.dValue);
    //        curItem->setData(7,sig->m_Factor.dValue);
    //        curItem->setData(8,sig->m_Offset.dValue);
    //        curItem->setData(9,sig->m_Min.dValue);
    //        curItem->setData(10,sig->m_Max.dValue);
    //        curItem->setData(11,sig->m_Comment);
}

void MainDbEditor::slotEditSignal(CANSignal *signal)
{
    QModelIndex currentIndex= this->m_treeWidget->currentIndex();
    MainDbCommonItem *curItem = static_cast<MainDbCommonItem*> (currentIndex.internalPointer());
    QModelIndex tblIndex=this->m_ComTableWidget->currentIndex();
    qDebug()<<"row = "<<tblIndex.row()<<" column= "<<tblIndex.column();
    MainDbCommonItem * tablItem = static_cast<MainDbCommonItem*>(tblIndex.internalPointer());

    CANSignal *editSignal;
    QModelIndex  messRootIndex=this->m_treeViewModel->index(0,0,QModelIndex());
    MainDbCommonItem * messRootItem = static_cast<MainDbCommonItem*>(messRootIndex.internalPointer());
    QModelIndex  sigRootIndex=this->m_treeViewModel->index(1,0,QModelIndex());
    MainDbCommonItem * sigRootItem = static_cast<MainDbCommonItem*>(sigRootIndex.internalPointer());


    if(tblIndex.row()!=-1){// if click on combineTable , not on tree
    //update table model
    tablItem->setData(0,signal->m_Name);
    tablItem->setData(1,signal->m_Length);
//        tablItem->setData(2,signal->m_Name);
//        tablItem->setData(3,signal->m_Name);
//        tablItem->setData(4,signal->m_Name);
    tablItem->setData(5,(signal->m_ByteOrder == E_CANByteOrder_Intel ? "Intel": "Motorola"));
    //tablItem->setData(6,(E_CANSignalSign)signal->m_ValueType);
    if(signal->m_ValueType== E_CANSignalSign_Signed){
        tablItem->setData(6,"Signed");
          }else if(signal->m_ValueType  == E_CANSignalSign_UnSigned){
        tablItem->setData(6,"Unsigned");
          }else if(signal->m_ValueType == E_CANSignalSign_Float){
        tablItem->setData(6,"Float");
          }else{
        tablItem->setData(6,"Double");
          }
    tablItem->setData(7,signal->m_InitValue.dValue);
    tablItem->setData(8,signal->m_Factor.dValue);
    tablItem->setData(9,signal->m_Offset.dValue);
    tablItem->setData(10,signal->m_Min.dValue);
    tablItem->setData(11,signal->m_Max.dValue);
    tablItem->setData(12,signal->m_Comment);

//        qDebug()<<sgn.m_Signal->m_Name;
//        qDebug()<<parent->childCount();
//        qDebug()<<idx;
//        qDebug()<<data[idx];
//         parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
//         data << sgn.m_Signal->m_Length;
//         parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
//         data <<m_dbManager->getMessagesList().at(clickedItemIndex.parent().row())->m_Name;
//         parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
//         data <<"mul";
//         parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
//         data <<sgn.m_StartBit;
//         parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);

    if(curItem->getType()==E_DbItemType_Message){
        editSignal=this->m_mainDbManager->getMessagesList().at(currentIndex.row())->m_Signals.at(tblIndex.row()).m_Signal;
       // editSignal=this->m_mainDbManager->m_CANMessages.at(currentIndex.row())->m_Signals.at(tblIndex.row()).m_Signal;

       QModelIndex treeSignalInMessIndex = currentIndex.child(tblIndex.row(),0);
       qDebug()<<"row 2 = "<<treeSignalInMessIndex.row()<<" column 2 = "<<treeSignalInMessIndex.column();
       MainDbCommonItem * treeSignalItem =static_cast<MainDbCommonItem*> (treeSignalInMessIndex.internalPointer());
        treeSignalItem->setData(0,signal->m_Name);
        //treeSignalItem->setData(1,signal->m_Name);
        treeSignalItem->setData(2,signal->m_Length);
        treeSignalItem->setData(3,(signal->m_ByteOrder == E_CANByteOrder_Intel ? "Intel": "Motorola"));
        treeSignalItem->setData(4,signal->m_Unit.dValue);
        if(signal->m_ValueType== E_CANSignalSign_Signed){
            treeSignalItem->setData(5,"Signed");
              }else if(signal->m_ValueType  == E_CANSignalSign_UnSigned){
            treeSignalItem->setData(5,"Unsigned");
              }else if(signal->m_ValueType == E_CANSignalSign_Float){
            treeSignalItem->setData(5,"Float");
              }else{
            treeSignalItem->setData(5,"Double");
              }
        //treeSignalItem->setData(5,signal->m_ValueType);
        treeSignalItem->setData(6,signal->m_InitValue.dValue);
        treeSignalItem->setData(7,signal->m_Factor.dValue);
        treeSignalItem->setData(8,signal->m_Offset.dValue);
        treeSignalItem->setData(9,signal->m_Min.dValue);
        treeSignalItem->setData(10,signal->m_Max.dValue);
        treeSignalItem->setData(11,signal->m_Comment);
    }else if(curItem->getType()==E_DbItemType_Signal){
       editSignal=this->m_mainDbManager->getSignalsList().at(currentIndex.row());
        //editSignal=this->m_mainDbManager->m_CANSignals.at(currentIndex.row());
     //  copySignal(editSignal,signal);
       // editSignal =signal;
        curItem->setData(0,signal->m_Name);
        //treeSignalItem->setData(1,signal->m_Name);
        curItem->setData(2,signal->m_Length);
        curItem->setData(3,(signal->m_ByteOrder == E_CANByteOrder_Intel ? "Intel": "Motorola"));
        if(signal->m_ValueType== E_CANSignalSign_Signed){
            curItem->setData(5,"Signed");
              }else if(signal->m_ValueType  == E_CANSignalSign_UnSigned){
            curItem->setData(5,"Unsigned");
              }else if(signal->m_ValueType == E_CANSignalSign_Float){
            curItem->setData(5,"Float");
              }else{
            curItem->setData(5,"Double");
              }
        curItem->setData(4,signal->m_Unit.dValue);
        //treeSignalItem->setData(5,signal->m_ValueType);
        curItem->setData(6,signal->m_InitValue.dValue);
        curItem->setData(7,signal->m_Factor.dValue);
        curItem->setData(8,signal->m_Offset.dValue);
        curItem->setData(9,signal->m_Min.dValue);
        curItem->setData(10,signal->m_Max.dValue);
        curItem->setData(11,signal->m_Comment);

    }else if(curItem->getType()==E_DbItemType_SignalInMessage){
       editSignal=this->m_mainDbManager->getMessagesList().at(currentIndex.parent().row())->m_Signals.at(currentIndex.row()).m_Signal;
        //editSignal=this->m_mainDbManager->m_CANMessages.at(currentIndex.parent().row())->m_Signals.at(currentIndex.row()).m_Signal;
     //  copySignal(editSignal,signal);
        curItem->setData(0,signal->m_Name);
        //treeSignalItem->setData(1,signal->m_Name);
        curItem->setData(2,signal->m_Length);
        curItem->setData(3,(signal->m_ByteOrder == E_CANByteOrder_Intel ? "Intel": "Motorola"));
        if(signal->m_ValueType== E_CANSignalSign_Signed){
            curItem->setData(5,"Signed");
              }else if(signal->m_ValueType  == E_CANSignalSign_UnSigned){
            curItem->setData(5,"Unsigned");
              }else if(signal->m_ValueType == E_CANSignalSign_Float){
            curItem->setData(5,"Float");
              }else{
            curItem->setData(5,"Double");
              }
        curItem->setData(4,signal->m_Unit.dValue);
        //treeSignalItem->setData(5,signal->m_ValueType);
        curItem->setData(6,signal->m_InitValue.dValue);
        curItem->setData(7,signal->m_Factor.dValue);
        curItem->setData(8,signal->m_Offset.dValue);
        curItem->setData(9,signal->m_Min.dValue);
        curItem->setData(10,signal->m_Max.dValue);
        curItem->setData(11,signal->m_Comment);
    }

    }else{
        editSignal=this->m_mainDbManager->getMessagesList().at(currentIndex.parent().row())->m_Signals.at(currentIndex.row()).m_Signal;
        //editSignal=this->m_mainDbManager->m_CANMessages.at(currentIndex.parent().row())->m_Signals.at(currentIndex.row()).m_Signal;
      //  copySignal(editSignal,signal);
         curItem->setData(0,signal->m_Name);
         //treeSignalItem->setData(1,signal->m_Name);
         curItem->setData(2,signal->m_Length);
         curItem->setData(3,(signal->m_ByteOrder == E_CANByteOrder_Intel ? "Intel": "Motorola"));
         if(signal->m_ValueType== E_CANSignalSign_Signed){
             curItem->setData(5,"Signed");
               }else if(signal->m_ValueType  == E_CANSignalSign_UnSigned){
             curItem->setData(5,"Unsigned");
               }else if(signal->m_ValueType == E_CANSignalSign_Float){
             curItem->setData(5,"Float");
               }else{
             curItem->setData(5,"Double");
               }
         curItem->setData(4,signal->m_Unit.dValue);
         //treeSignalItem->setData(5,signal->m_ValueType);
         curItem->setData(6,signal->m_InitValue.dValue);
         curItem->setData(7,signal->m_Factor.dValue);
         curItem->setData(8,signal->m_Offset.dValue);
         curItem->setData(9,signal->m_Min.dValue);
         curItem->setData(10,signal->m_Max.dValue);
         curItem->setData(11,signal->m_Comment);
    }

    for(int i=0;i<this->m_mainDbManager->getMessagesList().size();i++)
    {
        for(int j=0;j<this->m_mainDbManager->getMessagesList().at(i)->m_Signals.size();j++)
        {
            if(compareSignal(this->m_mainDbManager->getMessagesList().at(i)->m_Signals.at(j).m_Signal,editSignal))
            {
                MainDbCommonItem * sigItem = messRootItem->child(i)->child(j);
                sigItem->setData(0,signal->m_Name);
            }
         }
    }
    for(int i=0;i<this->m_mainDbManager->getSignalsList().size();i++){
        if(compareSignal(this->m_mainDbManager->getSignalsList().at(i),editSignal)){
            MainDbCommonItem * sigItem = sigRootItem->child(i);
            sigItem->setData(0,signal->m_Name);
        }
    }
    copySignal(editSignal,signal);
    //editSignal=signal;
}

void MainDbEditor::slotsBit(int sBit)
{
QModelIndex curIndex = this->m_treeWidget->currentIndex();
MainDbCommonItem *curItem =static_cast<MainDbCommonItem*>(curIndex.internalPointer());
QModelIndex curTblIndex = this->m_ComTableWidget->currentIndex();
MainDbCommonItem * curTblItem = static_cast<MainDbCommonItem*>(curTblIndex.internalPointer());
QModelIndex  messRootIndex=this->m_treeViewModel->index(0,0,QModelIndex());
MainDbCommonItem * messRootItem = static_cast<MainDbCommonItem*>(messRootIndex.internalPointer());
qDebug()<<"row haha = "<<curTblIndex.row()<<" column= "<<curTblIndex.column();
if(curTblIndex.row()!=-1){
    // click combineTable
    if(curItem->getType()==E_DbItemType_Message){
        qDebug()<<"click combineTable";
        unsigned char *p =const_cast<unsigned char *>(&this->m_mainDbManager->m_CANMessages.at(curIndex.row())->m_Signals.at(curTblIndex.row()).m_StartBit);
        *p =(unsigned char)sBit;
       curItem->child(curTblIndex.row())->setData(1,sBit);
       //emit this->m_treeWidget->clicked(curIndex);
    }else if(curItem->getType()==E_DbItemType_SignalInMessage){
        unsigned char *p =const_cast<unsigned char *>(&this->m_mainDbManager->m_CANMessages.at(curIndex.parent().row())->m_Signals.at(curIndex.row()).m_StartBit);
        *p =(unsigned char)sBit;
       curItem->setData(1,sBit);
       //emit this->m_treeWidget->clicked(curIndex);
    }else if(curItem->getType()==E_DbItemType_Signal){
        int temp =0;
        for(int i=0;i<this->m_mainDbManager->getMessagesList().size();i++){
            for(int j=0;j<this->m_mainDbManager->getMessagesList().at(i)->m_Signals.size();j++){
                if(compareSignal(this->m_mainDbManager->getSignalsList().at(curIndex.row()),
                                 this->m_mainDbManager->getMessagesList().at(i)->m_Signals.at(j).m_Signal)){
                    if(temp==curTblIndex.row()){
                        unsigned char *p =const_cast<unsigned char *>(&this->m_mainDbManager->m_CANMessages.at(i)->m_Signals.at(j).m_StartBit);
                        *p =(unsigned char)sBit;
                       messRootItem->child(i)->child(j)->setData(1,sBit);
                    }
                    temp++;
                }
            }
        }
    }
}else{
    //click tree view
    qDebug()<<"click treeview";
    if(curItem->getType()==E_DbItemType_SignalInMessage){
     unsigned char *p =const_cast<unsigned char *>(&this->m_mainDbManager->m_CANMessages.at(curIndex.parent().row())->m_Signals.at(curIndex.row()).m_StartBit);
     *p =(unsigned char)sBit;
    curItem->setData(1,sBit);
    //emit this->m_treeWidget->clicked(curIndex);
    }
}
}

void MainDbEditor::updateByDelegateOnMessTbl(QModelIndex index)
{
    MainDbCommonItem * tblItem = static_cast<MainDbCommonItem *>(index.internalPointer());
    CANMessage * editMessage =static_cast<CANMessage*>( this->m_mainDbManager->getMessagesList().at(index.row()));
    editMessage->m_Name=tblItem->data(0).toString();
    editMessage->m_ID=tblItem->data(1).toUInt();
    editMessage->m_IdType=(E_CANMsgIDType)tblItem->data(2).toInt();
    editMessage->m_Length=tblItem->data(3).toUInt();
//update tree model item data
    QModelIndex messIndex = this->m_treeViewModel->index(0,0,QModelIndex());
    MainDbCommonItem *treeItem = static_cast<MainDbCommonItem*>(messIndex.child(index.row(),index.column()).internalPointer());
    if(index.column()!=2){
    treeItem->setData(index.column(),tblItem->data(index.column()));
    }else{
        if(tblItem->data(index.column()).toString().compare("Extended")){
             treeItem->setData(index.column(),0);
        }else{
            treeItem->setData(index.column(),1);
        }
    }
    qDebug()<<"tblItem->data(index.column())="<<tblItem->data(index.column()).toString();
}
void MainDbEditor::updateByDelegateOnSigTbl(QModelIndex index)
{
    MainDbCommonItem * tblItem = static_cast<MainDbCommonItem *>(index.internalPointer());
    CANSignal * editSignal =this->m_mainDbManager->getSignalsList().at(index.row());
    editSignal->m_Name=tblItem->data(0).toString();
    editSignal->m_Length=tblItem->data(1).toUInt();
    editSignal->m_ByteOrder=(E_CANByteOrder)tblItem->data(2).toInt();
    editSignal->m_ValueType=(E_CANSignalSign)tblItem->data(3).toUInt();
    editSignal->m_InitValue.dValue=tblItem->data(4).toDouble();
    editSignal->m_Factor.dValue=tblItem->data(5).toDouble();
    editSignal->m_Offset.dValue=tblItem->data(6).toDouble();
    editSignal->m_Min.dValue=tblItem->data(7).toDouble();
    editSignal->m_Max.dValue=tblItem->data(8).toDouble();
    editSignal->m_Comment=tblItem->data(9).toString();
    //update tree model data

    QModelIndex  messRootIndex=this->m_treeViewModel->index(0,0,QModelIndex());
    MainDbCommonItem * messRootItem = static_cast<MainDbCommonItem*>(messRootIndex.internalPointer());
    QModelIndex  sigRootIndex=this->m_treeViewModel->index(1,0,QModelIndex());
    MainDbCommonItem * sigRootItem = static_cast<MainDbCommonItem*>(sigRootIndex.internalPointer());
    for(int i=0;i<this->m_mainDbManager->getMessagesList().size();i++)
    {
        for(int j=0;j<this->m_mainDbManager->getMessagesList().at(i)->m_Signals.size();j++)
        {
            if(compareSignal(this->m_mainDbManager->getMessagesList().at(i)->m_Signals.at(j).m_Signal,editSignal))
            {
                MainDbCommonItem * sigItem = messRootItem->child(i)->child(j);
                sigItem->setData(0,editSignal->m_Name);
            }
         }
    }
    for(int i=0;i<this->m_mainDbManager->getSignalsList().size();i++){
        if(compareSignal(this->m_mainDbManager->getSignalsList().at(i),editSignal)){
            MainDbCommonItem * sigItem = sigRootItem->child(i);
            sigItem->setData(0,editSignal->m_Name);
        }
    }
}

void MainDbEditor::slotRemoveMessage()
{
    qDebug()<<"remove";
QModelIndex removeMessIndex = this->m_treeWidget->currentIndex();
MainDbCommonItem * rmMessItem=static_cast<MainDbCommonItem*>(removeMessIndex.internalPointer());
this->m_treeViewModel->removeRow(removeMessIndex.row(),removeMessIndex.parent());
this->m_mainDbManager->m_CANMessages.remove(removeMessIndex.row());
}

void MainDbEditor::slotRemoveSignal()
{
    QModelIndex removeSigIndex = this->m_treeWidget->currentIndex();
   // MainDbCommonItem * rmSigItem=static_cast<MainDbCommonItem*>(removeSigIndex.internalPointer());
    this->m_treeViewModel->removeRow(removeSigIndex.row(),removeSigIndex.parent());

//   CANSignal * deleteSig =this->m_mainDbManager->getSignalsList().at(removeSigIndex.row());
//   delete deleteSig;
    QModelIndex  messRootIndex=this->m_treeViewModel->index(0,0,QModelIndex());
    MainDbCommonItem * messRootItem = static_cast<MainDbCommonItem*>(messRootIndex.internalPointer());
    QModelIndex  sigRootIndex=this->m_treeViewModel->index(1,0,QModelIndex());
    MainDbCommonItem * sigRootItem = static_cast<MainDbCommonItem*>(sigRootIndex.internalPointer());
    for(int i=0;i<this->m_mainDbManager->getMessagesList().size();i++){
        for(int j=0;j<this->m_mainDbManager->getMessagesList().at(i)->m_Signals.size();j++){
            if(compareSignal(this->m_mainDbManager->getMessagesList().at(i)->m_Signals.at(j).m_Signal,
                             this->m_mainDbManager->getSignalsList().at(removeSigIndex.row()))){
                this->m_treeViewModel->removeRow(j,messRootIndex.child(i,0));
                qDebug()<<"haha";
                //messRootItem->child(i)->removeChildren(j,0);
                this->m_mainDbManager->m_CANMessages.at(i)->m_Signals.remove(j);
            }
        }
    }
    this->m_mainDbManager->m_CANSignals.remove(removeSigIndex.row());
}

void MainDbEditor::slotRemoveSignalInMsg()
{
//    qDebug()<<"slotRemoveSignalInMsg";
QModelIndex curIndex = this->m_treeWidget->currentIndex();
MainDbCommonItem * curItem = static_cast<MainDbCommonItem*>(curIndex.internalPointer());
if(curItem->getType()==E_DbItemType_SignalInMessage)
    {
        this->m_mainDbManager->m_CANMessages.at(curIndex.parent().row())->m_Signals.removeAt(curIndex.row());
        this->m_treeViewModel->removeRow(curIndex.row(),curIndex.parent());
    }
//else if(curItem->getType()==E_DbItemType_Message)
//    {
//            if(this->m_MsgEditorWidget->SignTab->signal->rowCount()>0)
//                {
//                    int removeRow = this->m_MsgEditorWidget->SignTab->signal->currentIndex().row();
//                        if(removeRow!=-1)
//                            {
//                                this->m_treeViewModel->removeRow(removeRow,curIndex);
//                                this->m_mainDbManager->m_CANMessages.at(curIndex.row())->m_Signals.remove(removeRow,1);
//                            }
//                }
//    }
//this->m_mainDbManager->m_CANMessages.at(i)->m_Signals.remove(j);
}
void  MainDbEditor::slotContextMenuCombTable(QPoint  point)
{

    QMenu *rightClickMenu = new QMenu(this);

    QAction *actionEdit = new QAction(QIcon(":icons/edit.png"),QString("Edit"),this);
    //    connect(actionEdit, SIGNAL(triggered()),  this, SLOT(slotOpenSignalInMsgEditor()));

    QAction *actionRemove = new QAction(QIcon(":icons/remove.png"),QString("Remove"),this);
    //    connect(actionRemove, SIGNAL(triggered()),  this, SLOT(slotRemoveSignalInMsg()));

    rightClickMenu->addAction(actionEdit);
    rightClickMenu->addSeparator();
    rightClickMenu->addAction(actionRemove);

    QPoint globalPos = m_MsgsTableWidget->mapToGlobal(point);

    rightClickMenu->popup(globalPos);

}

void  MainDbEditor::slotContextMenuTreeWidget(QPoint  point)
{
    QMenu *rightClickMenu = new QMenu(this);

    switch (m_treeViewModel->getItem(m_treeWidget->selectionModel()->currentIndex())->getType()) {
    case E_DbItemType_Header:
    {
        if(m_treeViewModel->getItem(m_treeWidget->selectionModel()->currentIndex())->data(0) == QString("Messages")){
            QAction *actionNew = new QAction(QIcon(":icons/new.png"),QString("New message"),this);
                connect(actionNew, SIGNAL(triggered()),  this, SLOT(slotCreateNewMess()));

            QAction *actionPaste = new QAction(QIcon(":icons/paste.png"),QString("Paste"),this);
            //    connect(actionRemove, SIGNAL(triggered()),  this, SLOT(slotRemoveSignalInMsg()));
            actionPaste->setEnabled(false);
            rightClickMenu->addAction(actionNew);
            rightClickMenu->addSeparator();
            rightClickMenu->addAction(actionPaste);
//            QPoint globalPos = m_treeWidget->mapToGlobal(point);
//            rightClickMenu->popup(globalPos);
            rightClickMenu->popup(point);
        }else if(m_treeViewModel->getItem(m_treeWidget->selectionModel()->currentIndex())->data(0) == QString("Signals")){
            QAction *actionNew = new QAction(QIcon(":icons/new.png"),QString("New signal"),this);
            //    connect(actionEdit, SIGNAL(triggered()),  this, SLOT(slotOpenSignalInMsgEditor()));
            connect(actionNew, SIGNAL(triggered()),  this, SLOT(slotOpenNewSignalEditor()));
            QAction *actionPaste = new QAction(QIcon(":icons/paste.png"),QString("Paste"),this);
            //    connect(actionRemove, SIGNAL(triggered()),  this, SLOT(slotRemoveSignalInMsg()));
            actionPaste->setEnabled(false);
            rightClickMenu->addAction(actionNew);
            rightClickMenu->addSeparator();
            rightClickMenu->addAction(actionPaste);
            QPoint globalPos = m_treeWidget->mapToGlobal(point);
            rightClickMenu->popup(globalPos);
        }
         break;
    }

    case E_DbItemType_Message:
    {
        QAction *actionNew = new QAction(QIcon(":icons/new.png"),QString("New message"),this);
        //connect(actionNew, SIGNAL(triggered()),  this, SLOT(slotOpenMessageEditor()));

        QAction *actionEdit = new QAction(QIcon(":icons/edit.png"),QString("Edit message"),this);
        connect(actionEdit, SIGNAL(triggered()),  this, SLOT(slotOpenMessageEditor()));

        QAction *actionCopy= new QAction(QIcon(":icons/copy.png"),QString("Copy"),this);
        //    connect(actionRemove, SIGNAL(triggered()),  this, SLOT(slotRemoveSignalInMsg()));

        QAction *actionPaste = new QAction(QIcon(":icons/paste.png"),QString("Paste"),this);
        //    connect(actionRemove, SIGNAL(triggered()),  this, SLOT(slotRemoveSignalInMsg()));
        actionPaste->setEnabled(false);

        QAction *actionDelete = new QAction(QIcon(":icons/remove.png"),QString("Delete"),this);
        //    connect(actionRemove, SIGNAL(triggered()),  this, SLOT(slotRemoveSignalInMsg()));
        connect(actionDelete, SIGNAL(triggered()),  this, SLOT(slotRemoveMessage()));

        rightClickMenu->addAction(actionNew);
        rightClickMenu->addSeparator();

        rightClickMenu->addAction(actionEdit);
        rightClickMenu->addSeparator();

        rightClickMenu->addAction(actionCopy);
        rightClickMenu->addAction(actionPaste);
        rightClickMenu->addSeparator();

        rightClickMenu->addAction(actionDelete);

        QPoint globalPos = m_treeWidget->mapToGlobal(point);
        rightClickMenu->popup(globalPos);
        break;
    }


    case E_DbItemType_Signal:
    {
        QAction *actionNew = new QAction(QIcon(":icons/new.png"),QString("New signal"),this);
        //    connect(actionEdit, SIGNAL(triggered()),  this, SLOT(slotOpenSignalInMsgEditor()));

        QAction *actionEdit = new QAction(QIcon(":icons/edit.png"),QString("Edit signal"),this);
         connect(actionEdit, SIGNAL(triggered()),  this, SLOT(slotOpenSignalEditor()));
        //    connect(actionRemove, SIGNAL(triggered()),  this, SLOT(slotRemoveSignalInMsg()));

        QAction *actionCopy= new QAction(QIcon(":icons/copy.png"),QString("Copy"),this);
        //    connect(actionRemove, SIGNAL(triggered()),  this, SLOT(slotRemoveSignalInMsg()));

        QAction *actionPaste = new QAction(QIcon(":icons/paste.png"),QString("Paste"),this);
        //    connect(actionRemove, SIGNAL(triggered()),  this, SLOT(slotRemoveSignalInMsg()));
        actionPaste->setEnabled(false);

        QAction *actionDelete = new QAction(QIcon(":icons/remove.png"),QString("Delete"),this);
            connect(actionDelete, SIGNAL(triggered()),  this, SLOT(slotRemoveSignal()));

        rightClickMenu->addAction(actionNew);
        rightClickMenu->addSeparator();

        rightClickMenu->addAction(actionEdit);
        rightClickMenu->addSeparator();

        rightClickMenu->addAction(actionCopy);
        rightClickMenu->addAction(actionPaste);
        rightClickMenu->addSeparator();

        rightClickMenu->addAction(actionDelete);

        QPoint globalPos = m_treeWidget->mapToGlobal(point);
        rightClickMenu->popup(globalPos);
         break;
    }


    case E_DbItemType_SignalInMessage:
    {
        QAction *actionEdit = new QAction(QIcon(":icons/edit.png"),QString("Edit signal"),this);
        connect(actionEdit, SIGNAL(triggered()),  this, SLOT(slotOpenSignalEditor()));
        //    connect(actionRemove, SIGNAL(triggered()),  this, SLOT(slotRemoveSignalInMsg()));

        QAction *actionCopy= new QAction(QIcon(":icons/copy.png"),QString("Copy"),this);
        //    connect(actionRemove, SIGNAL(triggered()),  this, SLOT(slotRemoveSignalInMsg()));

        QAction *actionDelete = new QAction(QIcon(":icons/remove.png"),QString("Remove"),this);
            connect(actionDelete, SIGNAL(triggered()),  this, SLOT(slotRemoveSignalInMsg()));

        rightClickMenu->addAction(actionEdit);
        rightClickMenu->addSeparator();

        rightClickMenu->addAction(actionCopy);
        rightClickMenu->addSeparator();

        rightClickMenu->addAction(actionDelete);

        QPoint globalPos = m_treeWidget->mapToGlobal(point);
        rightClickMenu->popup(globalPos);
         break;
    }

    default:
        break;
    }
}
void MainDbEditor::slotOpenNewSignalEditor()
{
   QModelIndex sigRootIndex = this->m_treeViewModel->index(1,0,QModelIndex());
   MainDbCommonItem *sigRootItem = static_cast<MainDbCommonItem*>(sigRootIndex.internalPointer());
   qDebug()<<sigRootItem->childCount();


   // update treeview, list signal
   this->m_treeViewModel->insertRows(sigRootItem->childCount(),1,sigRootIndex);
   qDebug()<<sigRootItem->childCount();
   MainDbCommonItem *newItem = sigRootItem->child(sigRootItem->childCount()-1);
    newItem->setData(0,"New_Signal");
     qDebug()<<"slot newsignal";
    newItem->insertColumns(1,8);
    newItem->setData(1,8);
    newItem->setData(2,"Intel");
    newItem->setData(3,"Unsigned");
    newItem->setData(4, 0);
    newItem->setData(5,1);
    newItem->setData(6,2);
    newItem->setData(7,3);
    newItem->setData(8,"hehe");
    newItem->setType(E_DbItemType_Signal);
    // update tree view, list signal in message

    QModelIndex nonMessIndex = this->m_treeViewModel->index(0,0,QModelIndex()).child(0,0);
    MainDbCommonItem *nonMessItem = static_cast<MainDbCommonItem*>(nonMessIndex.internalPointer());
    qDebug()<<nonMessItem->childCount();
    this->m_treeViewModel->insertRows(nonMessItem->childCount(),1,nonMessIndex);
    qDebug()<<nonMessItem->childCount();
    MainDbCommonItem *newNonMessItem = nonMessItem->child(nonMessItem->childCount()-1);
     newNonMessItem->setData(0,"New_Signal");
      qDebug()<<"slot newsignal";
     newNonMessItem->insertColumns(1,8);
     newNonMessItem->setData(1,8);
     newNonMessItem->setData(2,"Intel");
     newNonMessItem->setData(3,"Unsigned");
     newNonMessItem->setData(4, 0);
     newNonMessItem->setData(5,1);
     newNonMessItem->setData(6,2);
     newNonMessItem->setData(7,3);
     newNonMessItem->setData(8,"hehe");
     newNonMessItem->setType(E_DbItemType_SignalInMessage);


    CANSignal *newSign = new CANSignal;
    newSign->m_Name = newItem->data(0).toString();
    newSign->m_Length =8;
    newSign->m_ValueType = E_CANSignalSign_UnSigned;
    newSign->m_ByteOrder = E_CANByteOrder_Motorola;
    newSign->m_Factor.dValue = 1;
    newSign->m_Offset.dValue = 0;
    newSign->m_Min.dValue =0;
    newSign->m_Max.dValue =100;
    newSign->m_InitValue.dValue = 0;
    qDebug()<<"size = "<<m_mainDbManager->m_CANSignals.size();
    m_mainDbManager->m_CANSignals.append(const_cast<CANSignal*>(newSign));
    CANSignalInMessage newMessSig;
    newMessSig.m_Signal=newSign;
    newMessSig.m_StartBit=0;
    m_mainDbManager->m_CANMessages.at(0)->m_Signals.append(newMessSig);
    // update in sigTableview
 //        this->m_tblSignModel->insertRows(sigRootItem->childCount(),1);
 //       MainDbCommonItem * newItemSigTab = static_cast<MainDbCommonItem*>(this->m_tblSignModel->index(sigRootItem->childCount(),0).internalPointer());
    emit this->m_treeWidget->clicked(sigRootIndex);
    m_SignalEditorWidget = new TabDialogMess(newItem,this);
    m_SignalEditorWidget->show();
    m_SignalEditorWidget->setWindowIcon(QPixmap(":/logo.png"));
    connect(m_SignalEditorWidget,SIGNAL(editSig(CANSignal*,QModelIndex,QModelIndex,QModelIndex)),this,SLOT(slotEditSig(CANSignal*,QModelIndex,QModelIndex,QModelIndex)));
    connect(m_SignalEditorWidget,SIGNAL(cancel()),this,SLOT(slotCancelCreateNewSig()));
}

void MainDbEditor::slotCancelCreateNewSig()
{
    // delete the signal just be created
    QModelIndex index = this->m_treeWidget->currentIndex();
    MainDbCommonItem *item = static_cast<MainDbCommonItem*>(index.internalPointer());
    QModelIndex nonMessIndex = this->m_treeViewModel->index(0,0,QModelIndex()).child(0,0);
    MainDbCommonItem *nonMessItem = static_cast<MainDbCommonItem*>(nonMessIndex.internalPointer());
    QModelIndex  sigRootIndex=this->m_treeViewModel->index(1,0,QModelIndex());
    MainDbCommonItem * sigRootItem = static_cast<MainDbCommonItem*>(sigRootIndex.internalPointer());
    if((item->data(0).toString()=="Signals")&&(this->m_SignsTableWidget->currentIndex().row()==-1)){
        qDebug()<<"delete the signal just be created";
//        nonMessItem->removeChildren(nonMessItem->childCount()-1,1);
//        sigRootItem->removeChildren(sigRootItem->childCount()-1,1);
        qDebug()<<sigRootItem->childCount();
        this->m_treeViewModel->removeRow(nonMessItem->childCount()-1,nonMessIndex);
        this->m_treeViewModel->removeRow(sigRootItem->childCount()-1,sigRootIndex);
        qDebug()<<sigRootItem->childCount();
        this->m_mainDbManager->m_CANSignals.remove(sigRootItem->childCount());
        this->m_mainDbManager->m_CANMessages.at(0)->m_Signals.remove(nonMessItem->childCount());
        emit this->m_treeWidget->clicked(sigRootIndex);
    }
}

void MainDbEditor::slotCreateNewMess()
{
    QModelIndex meesRootIndex = this->m_treeViewModel->index(0,0,QModelIndex());
    MainDbCommonItem *messRootItem = static_cast<MainDbCommonItem*>(meesRootIndex.internalPointer());

    // update treeview, list message
    this->m_treeViewModel->insertRows(messRootItem->childCount(),1,meesRootIndex);
    MainDbCommonItem *newItem = messRootItem->child(messRootItem->childCount()-1);
     newItem->setData(0,"New_Message");
     newItem->insertColumns(1,4);
     newItem->setData(1,0x80000000);
     newItem->setData(2,E_CANMsgIDType_Extended);
     newItem->setData(3,8);
     newItem->setData(4,"mess comment");
//     getItem(index)->insertColumns(1,4);
//     getItem(index)->setData(1,QVariant(msg->m_ID & (~0x80000000)));
//     getItem(index)->setData(2,QVariant(msg->m_IdType));
//     getItem(index)->setData(3,QVariant(msg->m_Length));
//     getItem(index)->setData(4,QVariant(msg->m_Comment));
     newItem->setType(E_DbItemType_Message);

     CANMessage *newMess = new CANMessage;
    newMess->m_Name= newItem->data(0).toString();
    newMess->m_ID=newItem->data(1).toInt();
    newMess->m_IdType=(E_CANMsgIDType)newItem->data(2).toInt();
    newMess->m_Length=newItem->data(3).toInt();
    newMess->m_Comment=newItem->data(4).toString();
    m_mainDbManager->m_CANMessages.append(const_cast<CANMessage*>(newMess));

     // update in sigTableview
  //        this->m_tblSignModel->insertRows(sigRootItem->childCount(),1);
  //       MainDbCommonItem * newItemSigTab = static_cast<MainDbCommonItem*>(this->m_tblSignModel->index(sigRootItem->childCount(),0).internalPointer());
     emit this->m_treeWidget->clicked(meesRootIndex);
     m_MsgEditorWidget = new MsgEditor(newItem,this);
     m_MsgEditorWidget->show();
     m_MsgEditorWidget->setWindowIcon(QPixmap(":/logo.png"));
     connect(m_MsgEditorWidget,SIGNAL(editMessage(CANMessage*,QModelIndex,QModelIndex,QModelIndex)),this,SLOT(slotEditMess(CANMessage*,QModelIndex,QModelIndex,QModelIndex)));
     connect(m_MsgEditorWidget,SIGNAL(listNewSig(QVector<CANSignalInMessage>,QModelIndex,QModelIndex)),this,
             SLOT(updateSigListInMess(QVector<CANSignalInMessage>,QModelIndex,QModelIndex)));
     connect(m_MsgEditorWidget,SIGNAL(cancel()),this,SLOT(slotCancelCreateNewMess()));
}

void MainDbEditor::slotCancelCreateNewMess()
{
    // delete the message just be created
    QModelIndex index = this->m_treeWidget->currentIndex();
    MainDbCommonItem *item = static_cast<MainDbCommonItem*>(index.internalPointer());
    QModelIndex  messRootIndex=this->m_treeViewModel->index(0,0,QModelIndex());
    MainDbCommonItem * messRootItem = static_cast<MainDbCommonItem*>(messRootIndex.internalPointer());
    qDebug()<<"this->m_mainDbManager->getMessagesList().size()"<<this->m_mainDbManager->getMessagesList().size();
    qDebug()<<"messRootItem->childCount()"<<messRootItem->childCount();
    if((item->data(0).toString()=="Messages")&&(this->m_MsgsTableWidget->currentIndex().row()==-1)){
        qDebug()<<"delete the message just be created";
        this->m_treeViewModel->removeRow(messRootItem->childCount()-1,messRootIndex);
        this->m_mainDbManager->m_CANMessages.remove(messRootItem->childCount());
        emit this->m_treeWidget->clicked(messRootIndex);
    }
}

void MainDbEditor::addSignal2Mess(CANSignal *sig)
{
qDebug()<<"slot addSignal2Mess"<<sig->m_Name;
QModelIndex currentIndex= this->m_treeWidget->currentIndex();
MainDbCommonItem * curItem = static_cast<MainDbCommonItem*>(currentIndex.internalPointer());

for(int i=0;i<this->m_mainDbManager->getSignalsList().size();i++){
    if(compareSignal(sig,this->m_mainDbManager->getSignalsList().at(i))){
    CANSignalInMessage messSig;
    messSig.m_StartBit=0;
    MainDbCommonItem *newSigInMess ;
    messSig.m_Signal=this->m_mainDbManager->getSignalsList().at(i);
if(curItem->data(0).toString()=="Messages"){
this->m_mainDbManager->m_CANMessages.at(this->m_MsgsTableWidget->currentIndex().row())->m_Signals.append(messSig);
    this->m_treeViewModel->insertRows(curItem->child(this->m_MsgsTableWidget->currentIndex().row())->childCount(),1,currentIndex.child(this->m_MsgsTableWidget->currentIndex().row(),0));
    newSigInMess = curItem->child(this->m_MsgsTableWidget->currentIndex().row())->child(curItem->child(this->m_MsgsTableWidget->currentIndex().row())->childCount()-1);
    }
else{
this->m_mainDbManager->m_CANMessages.at(currentIndex.row())->m_Signals.append(messSig);
    this->m_treeViewModel->insertRows(curItem->childCount(),1,currentIndex);
    newSigInMess = curItem->child(curItem->childCount()-1);
}
newSigInMess->setData(0,this->m_mainDbManager->getSignalsList().at(i)->m_Name);
 qDebug()<<"slot newsignal";
newSigInMess->insertColumns(1,this->m_mainDbManager->getSignalsList().at(i)->m_Length);
newSigInMess->setData(1,8);
newSigInMess->setData(2,this->m_mainDbManager->getSignalsList().at(i)->m_ByteOrder);
newSigInMess->setData(3,this->m_mainDbManager->getSignalsList().at(i)->m_ValueType);
newSigInMess->setData(4, this->m_mainDbManager->getSignalsList().at(i)->m_InitValue.dValue);
newSigInMess->setData(5,this->m_mainDbManager->getSignalsList().at(i)->m_Factor.dValue);
newSigInMess->setData(6,this->m_mainDbManager->getSignalsList().at(i)->m_Offset.dValue);
newSigInMess->setData(7,this->m_mainDbManager->getSignalsList().at(i)->m_Min.dValue);
newSigInMess->setData(8,this->m_mainDbManager->getSignalsList().at(i)->m_Max.dValue);
newSigInMess->setType(E_DbItemType_Signal);
}

}
}

void MainDbEditor::updateSigListInMess(QVector<CANSignalInMessage> sigList,QModelIndex treeIndex,QModelIndex messTblIndex)
{
    qDebug()<<"updateSigListInMess";
    QModelIndex  messRootIndex=this->m_treeViewModel->index(0,0,QModelIndex());
    MainDbCommonItem * messRootItem = static_cast<MainDbCommonItem*>(messRootIndex.internalPointer());
    MainDbCommonItem * curItem = static_cast<MainDbCommonItem *>(treeIndex.internalPointer());
    MainDbCommonItem * messItem;
    QModelIndex messIndex;
    if(curItem->getType()==E_DbItemType_Message){
        messItem = curItem;
        messIndex = treeIndex;
    }else {
        qDebug()<<"this->m_MsgsTableWidget->currentIndex().row()"<<messTblIndex.row();
        messItem = curItem->child(messTblIndex.row());
        messIndex=treeIndex.child(messTblIndex.row(),0);
    }
    if(messIndex.row()==-1){
        messIndex = messRootIndex.child(messRootItem->childCount()-1,0);
        messItem= static_cast<MainDbCommonItem*>(messIndex.internalPointer());
    }
   int  messRow = messIndex.row();
   int size =this->m_mainDbManager->m_CANMessages.at(messRow)->m_Signals.size();
    // update treeview model
    if(size>0){
    this->m_treeViewModel->removeRows(0,messItem->childCount(),messIndex);
    }
    QModelIndex index=messIndex;
    if(sigList.size()!=0){
    this->m_treeViewModel->insertRows(0,sigList.size(),index);
    int cnt2=0;
    foreach (CANSignalInMessage sgnInMsg, sigList) {
        index = index.child(cnt2,0);
        this->m_treeViewModel->getItem(index)->setData(0,sgnInMsg.m_Signal->m_Name);
        this->m_treeViewModel->getItem(index)->insertColumns(1,11);
        //getItem(index)->setData(1,sgnInMsg.m_Signal);
        this->m_treeViewModel->getItem(index)->setData(1,sgnInMsg.m_StartBit);
        this->m_treeViewModel->getItem(index)->setData(2,sgnInMsg.m_Signal->m_Length);
        this->m_treeViewModel->getItem(index)->setData(3,sgnInMsg.m_Signal->m_ByteOrder);
        this->m_treeViewModel->getItem(index)->setData(4,sgnInMsg.m_Signal->m_Unit.dValue);
        this->m_treeViewModel->getItem(index)->setData(5,sgnInMsg.m_Signal->m_ValueType);
        this->m_treeViewModel->getItem(index)->setData(6,sgnInMsg.m_Signal->m_InitValue.dValue);
        this->m_treeViewModel->getItem(index)->setData(7,sgnInMsg.m_Signal->m_Factor.dValue);
        this->m_treeViewModel->getItem(index)->setData(8,sgnInMsg.m_Signal->m_Offset.dValue);
        this->m_treeViewModel->getItem(index)->setData(9,sgnInMsg.m_Signal->m_Min.dValue);
        this->m_treeViewModel->getItem(index)->setData(10,sgnInMsg.m_Signal->m_Max.dValue);
        this->m_treeViewModel->getItem(index)->setData(11,sgnInMsg.m_Signal->m_Comment);
        this->m_treeViewModel->getItem(index)->setType(E_DbItemType_SignalInMessage);
        index = index.parent();
        cnt2++;
    }
    }
    // remove all signals in this message
qDebug()<<" list size = "<<this->m_mainDbManager->m_CANMessages.at(messRow)->m_Signals.size();

if(size>0){
    for(int i=0; i<size;i++){
        this->m_mainDbManager->m_CANMessages.at(messRow)->m_Signals.removeAt(0);
    }
}
qDebug()<<"remain list size = "<<this->m_mainDbManager->m_CANMessages.at(messRow)->m_Signals.size();
    // add the list new signal to message
if(sigList.size()>0){
    for(int i=0;i<sigList.size();i++){
        this->m_mainDbManager->m_CANMessages.at(messRow)->m_Signals.append(sigList.at(i));
    }
}
if(curItem->getType()!=E_DbItemType_Header){
    emit this->m_treeWidget->clicked(treeIndex);
}
    disconnect(m_MsgEditorWidget,SIGNAL(cancel()),this,SLOT(slotCancelCreateNewMess()));
//    int listSize =sigList.size();
//    for(int i=0; i<listSize;i++){
//    delete sigList.at(0).m_Signal;
//    }
}
void MainDbEditor::slotShowSigList()
{
qDebug()<<"show signal list ";
addSigEditor = new addSigDialog(this);
addSigEditor->setModal(true);
addSigEditor->show();
//connect(addSigEditor,SIGNAL(addSig2Mess(CANSignal*)),this,SLOT(addSignal2Mess(CANSignal*)));
connect(addSigEditor,SIGNAL(addListSig2Mess(QVector<CANSignal*>)),m_MsgEditorWidget,
        SLOT(addListSignalToMess(QVector<CANSignal*>)));
}
void MainDbEditor::updateByDelegateOnCombineTbl(QModelIndex index)
{
    qDebug()<<"call slot respone";
MainDbCommonItem * tblItem = static_cast<MainDbCommonItem*>(index.internalPointer());
QModelIndex  treeIndex= this->m_treeWidget->currentIndex();
MainDbCommonItem * treeItem = static_cast<MainDbCommonItem*>(treeIndex.internalPointer());

QModelIndex  messRootIndex=this->m_treeViewModel->index(0,0,QModelIndex());
MainDbCommonItem * messRootItem = static_cast<MainDbCommonItem*>(messRootIndex.internalPointer());
QModelIndex  sigRootIndex=this->m_treeViewModel->index(1,0,QModelIndex());
MainDbCommonItem * sigRootItem = static_cast<MainDbCommonItem*>(sigRootIndex.internalPointer());
if(treeItem->getType()==E_DbItemType_SignalInMessage)
    {
        QModelIndex  messIndex= treeIndex.parent();
        CANMessage *editMess= this->m_mainDbManager->getMessagesList().at(messIndex.row());
        CANSignalInMessage editMessSig= this->m_mainDbManager->getMessagesList().at(messIndex.row())->m_Signals.at(treeIndex.row());
        CANSignal *editSignal= this->m_mainDbManager->getMessagesList().at(messIndex.row())->m_Signals.at(treeIndex.row()).m_Signal;
        editSignal->m_Name=tblItem->data(0).toString();
        qDebug()<<"edit signal name "<<editSignal->m_Name;
        editSignal->m_Length=tblItem->data(1).toUInt();

        editSignal->m_ByteOrder=(E_CANByteOrder)(tblItem->data(5).toString().compare("Intel")?1:0);
        qDebug()<<"edit signal byorder "<<(int)editSignal->m_ByteOrder;
        editMess->m_Name=tblItem->data(2).toString();
        editMessSig.m_StartBit=tblItem->data(4).toUInt();
        //editSignal->m_ValueType=(E_CANSignalSign)tblItem->data(6).toUInt();
        if(!tblItem->data(6).toString().compare("Signed")){
            editSignal->m_ValueType=(E_CANSignalSign)0;
        }else if(!tblItem->data(6).toString().compare("Unsigned")){
            editSignal->m_ValueType=(E_CANSignalSign)1;
        }else if(!tblItem->data(6).toString().compare("Float")){
            editSignal->m_ValueType=(E_CANSignalSign)2;
        }else{
            editSignal->m_ValueType=(E_CANSignalSign)3;
        }
        editSignal->m_InitValue.dValue=tblItem->data(7).toDouble();
        editSignal->m_Factor.dValue=tblItem->data(8).toDouble();
        editSignal->m_Offset.dValue=tblItem->data(9).toDouble();
        editSignal->m_Min.dValue=tblItem->data(10).toDouble();
        editSignal->m_Max.dValue=tblItem->data(11).toDouble();
        editSignal->m_Comment=tblItem->data(12).toString();

//        QModelIndex par =QModelIndex();
//        MainDbCommonItem *parItem = static_cast<MainDbCommonItem*> (par.internalPointer());
//        m_treeViewModel->setupModelData(parItem);

        //update tree model data
        for(int i=0;i<this->m_mainDbManager->getMessagesList().size();i++)
        {
            for(int j=0;j<this->m_mainDbManager->getMessagesList().at(i)->m_Signals.size();j++)
            {
                if(compareSignal(this->m_mainDbManager->getMessagesList().at(i)->m_Signals.at(j).m_Signal,editSignal))
                {
                    MainDbCommonItem * sigItem = messRootItem->child(i)->child(j);
                    sigItem->setData(0,editSignal->m_Name);
                }
             }
        }
        for(int i=0;i<this->m_mainDbManager->getSignalsList().size();i++){
            if(compareSignal(this->m_mainDbManager->getSignalsList().at(i),editSignal)){
                MainDbCommonItem * sigItem = sigRootItem->child(i);
                sigItem->setData(0,editSignal->m_Name);
            }
        }


    }
else if(treeItem->getType()==E_DbItemType_Message)
    {
    CANMessage *editMess= this->m_mainDbManager->getMessagesList().at(treeIndex.row());
    CANSignalInMessage editMessSig= this->m_mainDbManager->getMessagesList().at(treeIndex.row())->m_Signals.at(index.row());
    CANSignal *editSignal= this->m_mainDbManager->getMessagesList().at(treeIndex.row())->m_Signals.at(index.row()).m_Signal;
    editSignal->m_Name=tblItem->data(0).toString();
    qDebug()<<"edit signal name "<<editSignal->m_Name;
    editSignal->m_Length=tblItem->data(1).toUInt();
    editSignal->m_ByteOrder=(E_CANByteOrder)(tblItem->data(5).toString().compare("Intel")?1:0);
    qDebug()<<"edit signal byorder "<<editSignal->m_ByteOrder;
    editMess->m_Name=tblItem->data(2).toString();
    editMessSig.m_StartBit=tblItem->data(4).toUInt();
    //editSignal->m_ValueType=(E_CANSignalSign)tblItem->data(6).toUInt();
    if(!tblItem->data(6).toString().compare("Signed")){
        editSignal->m_ValueType=(E_CANSignalSign)0;
    }else if(!tblItem->data(6).toString().compare("Unsigned")){
        editSignal->m_ValueType=(E_CANSignalSign)1;
    }else if(!tblItem->data(6).toString().compare("Float")){
        editSignal->m_ValueType=(E_CANSignalSign)2;
    }else{
        editSignal->m_ValueType=(E_CANSignalSign)3;
    }
    editSignal->m_InitValue.dValue=tblItem->data(7).toDouble();
    editSignal->m_Factor.dValue=tblItem->data(8).toDouble();
    editSignal->m_Offset.dValue=tblItem->data(9).toDouble();
    editSignal->m_Min.dValue=tblItem->data(10).toDouble();
    editSignal->m_Max.dValue=tblItem->data(11).toDouble();
    editSignal->m_Comment=tblItem->data(12).toString();
    // we must find another solution to replace for this temporary one.
//    m_treeViewModel = new MainDbTreeViewModel(m_mainDbManager,this);
//    m_treeWidget->setModel(m_treeViewModel);
//    m_tblMsgModel= new MainDbTableMsgsModel(m_mainDbManager,this);
//    m_MsgsTableWidget->setModel(m_tblMsgModel);
//    m_tblSignModel= new MainDbTableSignsModel(m_mainDbManager,this);
//    m_SignsTableWidget->setModel(m_tblSignModel);

    //update tree model data

    for(int i=0;i<this->m_mainDbManager->getMessagesList().size();i++)
    {
        for(int j=0;j<this->m_mainDbManager->getMessagesList().at(i)->m_Signals.size();j++)
        {
            if(compareSignal(this->m_mainDbManager->getMessagesList().at(i)->m_Signals.at(j).m_Signal,editSignal))
            {
                MainDbCommonItem * sigItem = messRootItem->child(i)->child(j);
                sigItem->setData(0,editSignal->m_Name);
            }
         }
    }
    for(int i=0;i<this->m_mainDbManager->getSignalsList().size();i++){
        if(compareSignal(this->m_mainDbManager->getSignalsList().at(i),editSignal)){
            MainDbCommonItem * sigItem = sigRootItem->child(i);
            sigItem->setData(0,editSignal->m_Name);
        }
    }

    }
else if(treeItem->getType()==E_DbItemType_Signal)
    {
        CANSignal *editSignal= this->m_mainDbManager->getSignalsList().at(treeIndex.row());
        editSignal->m_Name=tblItem->data(0).toString();
        editSignal->m_Length=tblItem->data(1).toUInt();
        editSignal->m_ByteOrder=(E_CANByteOrder)(tblItem->data(5).toString().compare("Intel")?1:0);
       // editSignal->m_ValueType=(E_CANSignalSign)tblItem->data(6).toUInt();
        qDebug()<<"sign = "<<tblItem->data(6).toString();
        if(!tblItem->data(6).toString().compare("Signed")){
            editSignal->m_ValueType=(E_CANSignalSign)0;
        }else if(!tblItem->data(6).toString().compare("Unsigned")){
            editSignal->m_ValueType=(E_CANSignalSign)1;
        }else if(!tblItem->data(6).toString().compare("Float")){
            editSignal->m_ValueType=(E_CANSignalSign)2;
        }else{
            editSignal->m_ValueType=(E_CANSignalSign)3;
        }
        editSignal->m_InitValue.dValue=tblItem->data(7).toDouble();
        editSignal->m_Factor.dValue=tblItem->data(8).toDouble();
        editSignal->m_Offset.dValue=tblItem->data(9).toDouble();
        editSignal->m_Min.dValue=tblItem->data(10).toDouble();
        editSignal->m_Max.dValue=tblItem->data(11).toDouble();
        editSignal->m_Comment=tblItem->data(12).toString();
        // we must find another solution to replace for this temporary one.
//        m_treeViewModel = new MainDbTreeViewModel(m_mainDbManager,this);
//        m_treeWidget->setModel(m_treeViewModel);
//        m_tblMsgModel= new MainDbTableMsgsModel(m_mainDbManager,this);
//        m_MsgsTableWidget->setModel(m_tblMsgModel);
//        m_tblSignModel= new MainDbTableSignsModel(m_mainDbManager,this);
//        m_SignsTableWidget->setModel(m_tblSignModel);

        //update tree model data
        for(int i=0;i<this->m_mainDbManager->getMessagesList().size();i++)
        {
            for(int j=0;j<this->m_mainDbManager->getMessagesList().at(i)->m_Signals.size();j++)
            {
                if(compareSignal(this->m_mainDbManager->getMessagesList().at(i)->m_Signals.at(j).m_Signal,editSignal))
                {
                    MainDbCommonItem * sigItem = messRootItem->child(i)->child(j);
                    sigItem->setData(0,editSignal->m_Name);
                }
             }
        }
        for(int i=0;i<this->m_mainDbManager->getSignalsList().size();i++){
            if(compareSignal(this->m_mainDbManager->getSignalsList().at(i),editSignal)){
                MainDbCommonItem * sigItem = sigRootItem->child(i);
                sigItem->setData(0,editSignal->m_Name);
            }
        }
}
}

//void MainDbEditor::updateTreeViewByDelegateOnCombineTbl(QModelIndex index)
//{
//// update tree model view to map with any changing from table model view
//    qDebug()<<"connected!";
//    MainDbCommonItem *tblItem = static_cast<MainDbCommonItem*>(index.internalPointer());
//    QModelIndex currentIndex=this->m_treeWidget->currentIndex();
//    MainDbCommonItem *currentItem =static_cast<MainDbCommonItem*>(currentIndex.internalPointer());
//    if(currentItem->getType()==E_DbItemType_Message){
////        QModelIndex childIndex = currentIndex.child(index.row(),index.column());
////        MainDbCommonItem *childItem = static_cast<MainDbCommonItem*>(childIndex.internalPointer());
//        if(index.column()==2){
//            currentItem->setData(0,tblItem->data(index.column()));
//        }else{
//        MainDbCommonItem *childItem=currentItem->child(index.row());
//        childItem->setData(index.column(),tblItem->data(index.column()));
//        }

//    }
//    if(currentItem->getType()==E_DbItemType_SignalInMessage){
//        if(index.column()==2){
//            MainDbCommonItem *parentItem=currentItem->parent();
//            parentItem->setData(0,tblItem->data(index.column()));
//        }else{
//        currentItem->setData(index.column(),tblItem->data(index.column()));
//        }

//    }
//    if(currentItem->getType()==E_DbItemType_Signal){
//        if(index.column()!=2)
//        currentItem->setData(index.column(),tblItem->data(index.column()));
//    }


//}

void MainDbEditor::closeEvent(QCloseEvent *event)
{
    //TODO: need to check change before asking
    QMessageBox::StandardButton resBtn = QMessageBox::question( this, "CANdb Editor",
                                                                tr("Do you want to save changes?\n"),
                                                                QMessageBox::Cancel | QMessageBox::No | QMessageBox::Yes,
                                                                QMessageBox::Cancel);
    if (resBtn == QMessageBox::Yes) {
        //TODO: Saving to database file
        event->accept();
    } else if (resBtn == QMessageBox::Cancel) {
        event->ignore();
    }else{
        //TODO: do not savingdb
        event->accept();
    }
}

void MainDbEditor::slotLoadDb(QString & path)
{
    /*TODO: remove db list*/
}

void MainDbEditor::slotSaveDb(QString & path)
{

}

void MainDbEditor::slotOpenMessageEditor()
{
    slotDoubleClickTree(m_treeWidget->currentIndex());
}

void MainDbEditor::slotOpenSignalEditor()
{
    slotDoubleClickTree(m_treeWidget->currentIndex());
}

MainDbManager::MainDbManager()
{

}

MainDbManager::~MainDbManager()
{

}

bool MainDbManager::slotAddMessage(CANMessage & message)
{

}

bool MainDbManager::slotAddSignal(CANSignal & signal)
{

}

bool MainDbManager::slotAddSignal2Message(CANSignal & signal)
{

}

//void MainDbManager::updateByDelegateOnMessTbl(QModelIndex index)
//{
//MainDbCommonItem * tblItem = static_cast<MainDbCommonItem *>(index.internalPointer());
//CANMessage * editMessage =static_cast<CANMessage*>( m_CANMessages.at(index.row()));
//editMessage->m_Name=tblItem->data(0).toString();
//editMessage->m_ID=tblItem->data(1).toUInt();
//editMessage->m_IdType=(E_CANMsgIDType)tblItem->data(2).toInt();
//editMessage->m_Length=tblItem->data(3).toUInt();

//}

//void MainDbManager::updateByDelegateOnSigTbl(QModelIndex index)
//{
//    MainDbCommonItem * tblItem = static_cast<MainDbCommonItem *>(index.internalPointer());
//    CANSignal * editSignal =static_cast<CANSignal*>( m_CANSignals.at(index.row()));
//    editSignal->m_Name=tblItem->data(0).toString();
//    editSignal->m_Length=tblItem->data(1).toUInt();
//    editSignal->m_ByteOrder=(E_CANByteOrder)tblItem->data(2).toInt();
//    editSignal->m_ValueType=(E_CANSignalSign)tblItem->data(3).toUInt();
//    editSignal->m_InitValue.dValue=tblItem->data(4).toDouble();
//    editSignal->m_Factor.dValue=tblItem->data(5).toDouble();
//    editSignal->m_Offset.dValue=tblItem->data(6).toDouble();
//    editSignal->m_Min.dValue=tblItem->data(7).toDouble();
//    editSignal->m_Max.dValue=tblItem->data(8).toDouble();
//    editSignal->m_Comment=tblItem->data(9).toString();
//}

QVector<CANSignalInMessage> MainDbManager::getSignalsInMessage(QString & messageName)
{
    QVector<CANSignalInMessage> ret;
    ret.empty();
    CANMessage * item;
    for(int i = 0; i< m_CANMessages.size();i++)
    {
        item = m_CANMessages.at(i);
        if(item && item->m_Name == messageName){
            ret = item->m_Signals;
        }
    }
    return ret;
}
bool compareSignal(CANSignal *newSig,CANSignal *oldSig){
    if(newSig->m_Name.compare(oldSig->m_Name)) return false;
    if(newSig->m_ByteOrder!=oldSig->m_ByteOrder) return false;
    //if(newSig->m_Factor!=oldSig->m_Factor) return false;
    if(newSig->m_Length!=oldSig->m_Length) return false;
    //if(newSig->m_Offset!=oldSig->m_Offset) return false;
    if(newSig->m_ValueType!=oldSig->m_ValueType) return false;
    return true;
}

QVector<CANMessagesOfSignal> MainDbManager::getMessagesOfSignal(int index)
{
    QVector<CANMessagesOfSignal> ret;
    CANMessagesOfSignal newItem;
    ret.empty();
    if(index>= m_CANSignals.size()){
        return ret;
    }
    CANSignal * signal = m_CANSignals.at(index);
    CANMessage * item;

    for(int i = 0; i< m_CANMessages.size();i++)
    {
        item = m_CANMessages.at(i);
        for (int j=0; j<item->m_Signals.size();j++){
            qDebug()<<signal->m_Name;
            qDebug()<<const_cast<CANSignal*>(item->m_Signals.at(j).m_Signal)->m_Name;
            if(compareSignal(const_cast<CANSignal*>(item->m_Signals.at(j).m_Signal),signal))
            {
                newItem.m_msgName = item->m_Name;
                newItem.m_StartBit = item->m_Signals.at(j).m_StartBit;
                ret.append(newItem);
            }
        }
    }
    return ret;
}

void MainDbManager::loadDbFile(QString & path)
{
    if(path.isEmpty()) return;
    m_CANMessages.clear();
    m_CANSignals.clear();
    CANMessage * newMsg=NULL;
    CANSignal * newSign=NULL;
    QFile file(path);
    file.open(QIODevice::ReadOnly);
    QString string = file.readAll();
    QStringList lines = string.split(QString("\n"),QString::SkipEmptyParts);
    foreach (QString line, lines) {
        QStringList lineItems =  line.split(QRegularExpression(":| |@|\\||\\(|\\)|\\[|\\]|,|\\+"),QString::SkipEmptyParts);
        /*SG_ PWM_CVVAL : 48|16@1+ (6.103515625E-005,0) [0|1] ""  NODE1
      -->"SG_", "PWM_CVVAL", "48", "16", "1+", "6.103515625E-005", "0", "0", "1", """", "NODE1"
          0            1       2     3    4          5             6    7    8     9     10
          0: SG_
          1: signal name
          2: start bit
          3: length in bit
          4: format intel/motorola
          5: factor
          6: offset
          7: min
          8: max
        */
        if(lineItems.size()>=10 && lineItems.at(0) == QString("SG_")){
            CANSignalInMessage newSignalInMsg;
            newSign = new CANSignal;
            newSign->m_Name = lineItems.at(1);
            newSignalInMsg.m_StartBit = (unsigned char)lineItems.at(2).toInt();
            newSign->m_Length = (unsigned char)lineItems.at(3).toInt();
            if(lineItems.at(4)[lineItems.at(4).length()-1] == '+'){
                newSign->m_ValueType = E_CANSignalSign_UnSigned;
            }else{
                newSign->m_ValueType = E_CANSignalSign_Signed;
            }
            int sz = lineItems.at(4).length()-1;
            QString tmp(lineItems.at(4));
            tmp.resize(sz);
            newSign->m_ByteOrder = (E_CANByteOrder)(tmp.toInt());
            newSign->m_Factor.dValue = lineItems.at(5).toDouble();
            newSign->m_Offset.dValue = lineItems.at(6).toDouble();
            newSign->m_Min.dValue = lineItems.at(7).toDouble();
            newSign->m_Max.dValue = lineItems.at(8).toDouble();
//            newSign->m_ = lineItems.at(8).toDouble();
            newSign->m_InitValue.dValue = 0;
            if(m_CANSignals.isEmpty()){
                m_CANSignals.append(newSign);
                newSignalInMsg.m_Signal = newSign;
            }else{
                for(int i=0;i<m_CANSignals.size();i++){
                    if(compareSignal(newSign,m_CANSignals.at(i))){
                        newSignalInMsg.m_Signal = m_CANSignals.at(i);
                        break;
                    }
                    newSignalInMsg.m_Signal = newSign;
                    if(i==(m_CANSignals.size()-1)){
                        m_CANSignals.append(newSign);
                    }
                }
            }

            newMsg->m_Signals.append(newSignalInMsg);
        }else {
            QStringList lineItems =  line.split(QRegularExpression(":| |@|\\||\\(|\\)|\\[|\\]|,"),QString::SkipEmptyParts);
            if(lineItems.size()>=4 && lineItems.at(0) == QString("BO_")){
                qDebug()<<lineItems.size() << lineItems;
                newMsg = new CANMessage;
                newMsg->m_ID = lineItems.at(1).toUInt();
//                int sz = lineItems.at(2).size();
                newMsg->m_Name = lineItems.at(2);
//                newMsg->m_Name.resize(sz-1);
                newMsg->m_Length  = lineItems.at(3).toInt();
                newMsg->m_IdType  = (newMsg->m_ID & 0x80000000) ? E_CANMsgIDType_Extended: E_CANMsgIDType_Standard;
                newMsg->m_Signals.clear();
                m_CANMessages.append(newMsg);
            }
        }
    }
    file.close();
}

void MainDbManager::saveDbFile(QString &path)
{
if(path.isEmpty()) return;
QFile file(path);
file.open(QIODevice::WriteOnly);
QTextStream out(&file);
out<<"VERSION \"\"\n\n\n"


         <<"NS_ :\n"
         <<"NS_DESC_\n"
         <<"CM_"
         <<"BA_DEF_\n"
         <<"BA_\n"
         <<"VAL_\n"
         <<"CAT_DEF_\n"
         <<"CAT_\n"
         <<"FILTER\n"
         <<"BA_DEF_DEF_\n"
         <<"EV_DATA_\n"
         <<"ENVVAR_DATA_\n"
         <<"SGTYPE_\n"
         <<"SGTYPE_VAL_\n"
         <<"BA_DEF_SGTYPE_\n"
         <<"BA_SGTYPE_\n"
         <<"SIG_TYPE_REF_\n"
         <<"VAL_TABLE_\n"
         <<"SIG_GROUP_\n"
         <<"SIG_VALTYPE_\n"
         <<"SIGTYPE_VALTYPE_\n"
         <<"BO_TX_BU_\n"
         <<"BA_DEF_REL_\n"
         <<"BA_REL_\n"
        <<"BA_DEF_DEF_REL_\n"
         <<"BU_SG_REL_\n"
         <<"BU_EV_REL_\n"
         <<"BU_BO_REL_\n"
         <<"SG_MUL_VAL_\n\n"

     <<"BS_:\n";
foreach (CANMessage *message, m_CANMessages) {
out<<"BO_ "<<message->m_ID<<" "<<message->m_Name<<" "<<message->m_Length<<" "<<"Vector_XXX\n";
foreach (CANSignalInMessage signal, message->m_Signals) {
  out<<" SG_ "<<signal.m_Signal->m_Name<<" : "<<signal.m_StartBit<<"|"<<signal.m_Signal->m_Length<<"@"<<signal.m_Signal->m_ByteOrder<<""
  <<signal.m_Signal->m_ValueType<<" ("<<signal.m_Signal->m_Factor.dValue<<","<<signal.m_Signal->m_Offset.dValue<<") ["<<signal.m_Signal->m_Min.dValue<<"|"
  <<signal.m_Signal->m_Max.dValue<<"] "<<"\""<<signal.m_Signal->m_Unit.dValue<<"\""<<" Vector_XXX\n";
}
}
}

MainDbCommonViewModel::MainDbCommonViewModel(MainDbManager * dbMng,QObject *parent)
    : QAbstractItemModel(parent),
      m_dbManager(dbMng),
      rootItem(NULL)
{
    //    QVector<QVariant> rootData;
    //    rootData << "";
    //    rootItem = new MainDbCommonItem(rootData, E_DbItemType_Header);
    //    setupModelData(rootItem);
}

MainDbCommonViewModel::~MainDbCommonViewModel()
{
    delete rootItem;
}

int MainDbCommonViewModel::columnCount(const QModelIndex & /* parent */) const
{
    return rootItem->columnCount();
}

QModelIndex MainDbCommonViewModel::index(int row, int column, const QModelIndex &parent) const
{
    if (parent.isValid() && parent.column() != 0)
        return QModelIndex();
    MainDbCommonItem *parentItem = getItem(parent);

    MainDbCommonItem *childItem = parentItem->child(row);
    if (childItem)
        return createIndex(row, column, childItem);
    else
        return QModelIndex();
}

bool MainDbCommonViewModel::insertColumns(int position, int columns, const QModelIndex &parent)
{
    bool success = true;
    beginInsertColumns(parent, position, position + columns - 1);
    success = rootItem->insertColumns(position, columns);
    endInsertColumns();
    return success;
}

bool MainDbCommonViewModel::insertRows(int position, int rows, const QModelIndex &parent)
{
    bool success = true;
    MainDbCommonItem *parentItem = getItem(parent);
    beginInsertRows(parent, position, position + rows - 1);
    success = parentItem->insertChildren(position, rows, rootItem->columnCount(),E_DbItemType_Header);
    endInsertRows();
    return success;
}

QModelIndex MainDbCommonViewModel::parent(const QModelIndex &index) const
{
    if (!index.isValid())
        return QModelIndex();
    MainDbCommonItem *childItem = getItem(index);
    MainDbCommonItem *parentItem = childItem->parent();
    if (parentItem == rootItem)
        return QModelIndex();
    return createIndex(parentItem->childNumber(), 0, parentItem);
}

bool MainDbCommonViewModel::removeColumns(int position, int columns, const QModelIndex &parent)
{
    bool success = true;
    beginRemoveColumns(parent, position, position + columns - 1);
    success = rootItem->removeColumns(position, columns);
    endRemoveColumns();
    if (rootItem->columnCount() == 0)
        removeRows(0, rowCount());
    return success;
}

bool MainDbCommonViewModel::removeRows(int position, int rows, const QModelIndex &parent)
{
    bool success = true;
    MainDbCommonItem *parentItem = getItem(parent);
    beginRemoveRows(parent, position, position + rows - 1);
    success = parentItem->removeChildren(position, rows);
    endRemoveRows();
    return success;
}

int MainDbCommonViewModel::rowCount(const QModelIndex &parent) const
{
    MainDbCommonItem *parentItem = getItem(parent);
    return parentItem->childCount();
}

MainDbCommonItem *MainDbCommonViewModel::getItem(const QModelIndex &index) const
{
    if (index.isValid()) {
        MainDbCommonItem *item = static_cast<MainDbCommonItem*>(index.internalPointer());
        if (item)
            return item;
    }
    return rootItem;
}

//MainDbTreeViewModel method define area

QVariant MainDbTreeViewModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid())
        return QVariant();

    if (role != Qt::DisplayRole && role != Qt::DecorationRole && role != Qt::ForegroundRole)
        return QVariant();
    if(role == Qt::DisplayRole){
        MainDbCommonItem *item = getItem(index);
        if(item->getType() == E_DbItemType_Message){
            QString string;
//            qDebug()<< item->data(index.column());
            string.append(item->data(index.column()).toString());
            string.append("\t(0x");
            string.append(QString::number(item->data(index.column()+1).toInt() & (~0x80000000),16));
            string.append(")");
            return string;
        }else if(item->getType() == E_DbItemType_Signal){
            QString string;
            string.append(item->data(0).toString());
            return string;
        }else{
            QString string;
            for(int i=0;i<=index.column();i++){
                string.append(item->data(i).toString());
            }
            return string;
        }
        //return item->data(index.column());
    }else if(role == Qt::DecorationRole){
        MainDbCommonItem *item = getItem(index);
        switch (item->getType()) {
        case E_DbItemType_Message:
        {
            QPixmap px(":/icons/message.png");
            return px.scaled(14,14);
        }
            break;
        case E_DbItemType_Signal:
        case E_DbItemType_SignalInMessage:
        {

            QPixmap px(":/icons/signal.png");
            return px.scaled(14,14);
        }
            break;
        default:
            break;
        }
    }else if(role == Qt::ForegroundRole){
        MainDbCommonItem *item = getItem(index);
        switch (item->getType()) {
        case E_DbItemType_Header:
        {
            return QVariant( QColor( Qt::darkRed ) );
        }
            break;
        }
    }
}

bool MainDbTreeViewModel::setData(const QModelIndex &index, const QVariant &value, int role)
{
    bool result = true;
    if (role != Qt::EditRole)
        return false;
    MainDbCommonItem *item = getItem(index);
    result = item->setData(index.column(), value);
    if (result)
        emit dataChanged(index, index);
    return result;
}

bool MainDbTreeViewModel::setHeaderData(int section, Qt::Orientation orientation,
                                        const QVariant &value, int role)
{
    if (role != Qt::EditRole || orientation != Qt::Horizontal)
        return false;
    bool result = rootItem->setData(section, value);
    if (result)
        emit headerDataChanged(orientation, section, section);
    return result;
}

Qt::ItemFlags MainDbTreeViewModel::flags(const QModelIndex &index) const
{
    if (!index.isValid())
        return 0;

    return QAbstractItemModel::flags(index);
}

QVariant MainDbTreeViewModel::headerData(int section, Qt::Orientation orientation,
                                         int role) const
{
    if (orientation == Qt::Horizontal && role == Qt::DisplayRole)
        return rootItem->data(section);
    return QVariant();
}

void MainDbTreeViewModel::setupModelData(MainDbCommonItem *parent)
{
    QVector <QVariant> data;
    data<< "Messages";
    parent->insertChildren(parent->childCount(), 1, rootItem->columnCount(),E_DbItemType_Header);
    parent->child(parent->childCount() - 1)->setData(0, data[0]);
    data.clear();
    data<< "Signals";
    parent->insertChildren(parent->childCount(), 1, rootItem->columnCount(),E_DbItemType_Header);
    parent->child(parent->childCount() - 1)->setData(0, data[0]);
    QModelIndex index;
    index = this->index(0,0);
    int cnt=0;
    if(m_dbManager->getMessagesList().size()!=0){
    insertRows(0,m_dbManager->getMessagesList().size(),index);

    foreach (CANMessage * msg, m_dbManager->getMessagesList()) {
        if(msg){
            index = index.child(cnt,0);
            qDebug()<<"column = "<<getItem(index)->columnCount();
            getItem(index)->setData(0,QVariant(msg->m_Name));
            getItem(index)->insertColumns(1,4);
            getItem(index)->setData(1,QVariant(msg->m_ID & (~0x80000000)));
            getItem(index)->setData(2,QVariant(msg->m_IdType));
            getItem(index)->setData(3,QVariant(msg->m_Length));
            getItem(index)->setData(4,QVariant(msg->m_Comment));
            for(int i=0;i<getItem(index)->columnCount();i++){
                qDebug()<<"column i = "<<getItem(index)->data(i);
            }
            qDebug()<<"getItem(index)= "<<getItem(index)->data(1);
            getItem(index)->setType(E_DbItemType_Message);
            if(msg->m_Signals.size()!=0){
            insertRows(0,msg->m_Signals.size(),index);
            int cnt2=0;
            foreach (CANSignalInMessage sgnInMsg, msg->m_Signals) {

                index = index.child(cnt2,0);
                getItem(index)->setData(0,sgnInMsg.m_Signal->m_Name);
                getItem(index)->insertColumns(1,11);
                //getItem(index)->setData(1,sgnInMsg.m_Signal);
                getItem(index)->setData(1,sgnInMsg.m_StartBit);
                getItem(index)->setData(2,sgnInMsg.m_Signal->m_Length);
                getItem(index)->setData(3,sgnInMsg.m_Signal->m_ByteOrder);
                getItem(index)->setData(4,sgnInMsg.m_Signal->m_Unit.dValue);
                getItem(index)->setData(5,sgnInMsg.m_Signal->m_ValueType);
                getItem(index)->setData(6,sgnInMsg.m_Signal->m_InitValue.dValue);
                getItem(index)->setData(7,sgnInMsg.m_Signal->m_Factor.dValue);
                getItem(index)->setData(8,sgnInMsg.m_Signal->m_Offset.dValue);
                getItem(index)->setData(9,sgnInMsg.m_Signal->m_Min.dValue);
                getItem(index)->setData(10,sgnInMsg.m_Signal->m_Max.dValue);
                getItem(index)->setData(11,sgnInMsg.m_Signal->m_Comment);
                getItem(index)->setType(E_DbItemType_SignalInMessage);
                index = index.parent();
                cnt2++;
            }}
            index = index.parent();
        }
        cnt++;
    }}
    index = this->index(1,0);
    if(m_dbManager->getSignalsList().size()!=0){
    insertRows(0,m_dbManager->getSignalsList().size(),index);
    cnt=0;
    foreach (CANSignal * sgn, m_dbManager->getSignalsList()) {
        if(sgn){
            index = index.child(cnt,0);
            getItem(index)->setData(0,sgn->m_Name);
            getItem(index)->insertColumns(1,8);
            getItem(index)->setData(1,sgn->m_Length);
            getItem(index)->setData(2,(sgn->m_ByteOrder == E_CANByteOrder_Intel ? "Intel": "Motorola"));
            getItem(index)->setData(3,(sgn->m_ValueType == E_CANSignalSign_Signed ? "Signed" : "Unsigned"));
            getItem(index)->setData(4, sgn->m_InitValue.dValue);
            getItem(index)->setData(5,sgn->m_Offset.dValue);
            getItem(index)->setData(6,sgn->m_Min.dValue);
            getItem(index)->setData(7,sgn->m_Max.dValue);
            getItem(index)->setData(8,sgn->m_Comment);
            getItem(index)->setType(E_DbItemType_Signal);
            //insert children for index
//           insertRows(0,m_dbManager->getMessagesOfSignal(cnt).size(),index);
//            int cnt2=0;
//            qDebug()<<"cnt = "<<cnt;
//            foreach (CANMessagesOfSignal msgOfSig, m_dbManager->getMessagesOfSignal(cnt)) {
//                qDebug()<<" cnt2= "<<cnt2;
//                index = index.child(cnt2,0);
//                getItem(index)->setData(0,msgOfSig.m_msgName);
//                getItem(index)->insertColumns(1,1);
//                getItem(index)->setData(1,msgOfSig.m_StartBit);
//                cnt2++;
//                index = index.parent();
//            }

            // insert children for item
//            getItem(index)->insertChildren(0,m_dbManager->getMessagesOfSignal(cnt).size(),2,E_DbItemType_Signal);
//            int temp=0;
//            foreach (CANMessagesOfSignal msgOfSig,  m_dbManager->getMessagesOfSignal(cnt)) {
//                getItem(index)->child(temp)->setData(0,msgOfSig.m_msgName);
//                getItem(index)->child(temp)->setData(1,msgOfSig.m_StartBit);
//                temp++;
//            }

        }
        cnt++;
        index = index.parent();
    }}
}


//MainDbTableMsgsModel method define  area

MainDbTableMsgsModel::MainDbTableMsgsModel(MainDbManager * dbMng, QObject *parent ):
    MainDbCommonViewModel(dbMng,parent)
{
    QVector<QVariant> rootData;
    rootData <<  "Name" << "ID" << "ID-format" << "DLC [Byte]" << "Comment";
    rootItem = new MainDbCommonItem(rootData, E_DbItemType_Header);
    setupModelData(rootItem);
}

QVariant MainDbTableMsgsModel::data(const QModelIndex &index, int role) const
{
    //    qDebug()<< __FUNCTION__ << __LINE__;
    if (!index.isValid())
        return QVariant();

    if (role != Qt::DisplayRole && role != Qt::EditRole && role != Qt::DecorationRole &&  role != Qt::BackgroundColorRole && role !=Qt::TextAlignmentRole)
        return QVariant();
    if(role == Qt::DisplayRole || role == Qt::EditRole){
        MainDbCommonItem *item = getItem(index);
        if(index.column() == 1){
            //This is message ID column
            QString tmp("0x");
            tmp.append(QString::number(item->data(index.column()).toUInt()& (~0x80000000),16));
            return tmp;
        }
        return item->data(index.column());
    }else if(role == Qt::DecorationRole  && index.column() == 0){
        MainDbCommonItem *item = getItem(index);
        switch (item->getType()) {
        case E_DbItemType_Message:
        {
            QPixmap px(":/icons/message.png");
            return px.scaled(16,16);
        }
            break;
        case E_DbItemType_Signal:
        case E_DbItemType_SignalInMessage:
        {
            QPixmap px(":/icons/signal.png");
            return px.scaled(16,16);
        }
            break;
        default:
            break;
        }
    }else if(role == Qt::BackgroundColorRole){
        if(index.row()%2 == 0){
            return QVariant( QColor( 215, 227, 229 ) );
        }
    }else if (role ==Qt::TextAlignmentRole)   {

    }
    return QVariant();
}

bool MainDbTableMsgsModel::setData(const QModelIndex &index, const QVariant &value, int role)
{
    bool result = true;
    if (role != Qt::EditRole)
        return false;
    MainDbCommonItem *item = getItem(index);
    result = item->setData(index.column(), value);
    if (result){
        emit dataChanged(index, index);
        emit updateByDelegate(index);
    }
    return result;
}

bool MainDbTableMsgsModel::setHeaderData(int section, Qt::Orientation orientation,
                                         const QVariant &value, int role)
{
    if (role != Qt::EditRole || orientation != Qt::Horizontal)
        return false;

    bool result = rootItem->setData(section, value);
    if (result)
        emit headerDataChanged(orientation, section, section);
    return result;
}

Qt::ItemFlags MainDbTableMsgsModel::flags(const QModelIndex &index) const
{
    if (!index.isValid())
        return 0;
    return Qt::ItemIsEditable | QAbstractItemModel::flags(index);
}

QVariant MainDbTableMsgsModel::headerData(int section, Qt::Orientation orientation,
                                          int role) const
{
    if (orientation == Qt::Horizontal && role == Qt::DisplayRole)
        return rootItem->data(section);
    return QVariant();
}

void MainDbTableMsgsModel::setupModelData(MainDbCommonItem *parent)
{
    QVector <QVariant> data;
    int cnt=0,idx=0;
    foreach (CANMessage * msg, m_dbManager->getMessagesList()) {
        if(msg){
            idx=0;
            parent->insertChildren(parent->childCount(), 1, rootItem->columnCount(),E_DbItemType_Message);
            data << msg->m_Name;
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data << msg->m_ID;
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data << ((msg->m_IdType == E_CANMsgIDType_Extended) ? QString("Extended") :QString("Standard"));
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data << msg->m_Length;
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data.clear();
        }
        cnt++;
    }
}

//MainDbTableSignsModel method define area

MainDbTableSignsModel::MainDbTableSignsModel(MainDbManager * dbMng, QObject *parent ):
    MainDbCommonViewModel(dbMng,parent){
    QVector<QVariant> rootData;
    rootData <<  "Name" << "Length [Bit]" << "Byte Order" << "Value Type" << "Initial Value" << "Factor"<< "Offset"<< "Minimum" << "Maximum" << "Comment";
    rootItem = new MainDbCommonItem(rootData, E_DbItemType_Header);
    setupModelData(rootItem);
}

QVariant MainDbTableSignsModel::data(const QModelIndex &index, int role) const
{
    //    qDebug()<< __FUNCTION__ << __LINE__;
    if (!index.isValid())
        return QVariant();

    if (role != Qt::DisplayRole && role != Qt::EditRole && role != Qt::DecorationRole &&  role != Qt::BackgroundColorRole && role !=Qt::TextAlignmentRole)
        return QVariant();
    if(role == Qt::DisplayRole || role == Qt::EditRole){
        MainDbCommonItem *item = getItem(index);
        return item->data(index.column());
    }else if(role == Qt::DecorationRole && index.column() == 0){
        MainDbCommonItem *item = getItem(index);
        switch (item->getType() ) {
        case E_DbItemType_Message:
        {
            QPixmap px(":/icons/message.png");
            return px.scaled(16,16);
        }
            break;
        case E_DbItemType_Signal:
        case E_DbItemType_SignalInMessage:
        {
            QPixmap px(":/icons/signal.png");
            return px.scaled(16,16);
        }
            break;
        default:
            break;
        }
    }else if(role == Qt::BackgroundColorRole){
        if(index.row()%2 == 0){
            return QVariant( QColor( 215, 227, 229 ) );
        }
    }
    return QVariant();
}

bool MainDbTableSignsModel::setData(const QModelIndex &index, const QVariant &value, int role)
{
    bool result = true;
    if (role != Qt::EditRole)
        return false;
    MainDbCommonItem *item = getItem(index);
    result = item->setData(index.column(), value);
    if (result)
    {
        emit dataChanged(index, index);
        emit updateByDelegate(index);
    }
    return result;
}
bool MainDbTableSignsModel::setHeaderData(int section, Qt::Orientation orientation,
                                          const QVariant &value, int role)
{
    if (role != Qt::EditRole || orientation != Qt::Horizontal)
        return false;

    bool result = rootItem->setData(section, value);
    if (result)
        emit headerDataChanged(orientation, section, section);
    return result;
}

Qt::ItemFlags MainDbTableSignsModel::flags(const QModelIndex &index) const
{
    if (!index.isValid())
        return 0;
    return Qt::ItemIsEditable | QAbstractItemModel::flags(index);
}

QVariant MainDbTableSignsModel::headerData(int section, Qt::Orientation orientation,
                                           int role) const
{
    if (orientation == Qt::Horizontal && role == Qt::DisplayRole)
        return rootItem->data(section);
    return QVariant();
}

void MainDbTableSignsModel::setupModelData(MainDbCommonItem *parent)
{
    QVector <QVariant> data;
    //static const QStringList byOrderArray[2] = {"Intel","Motorola"};

    int cnt=0, idx = 0;
    foreach (CANSignal * sgn, m_dbManager->getSignalsList()) {
        if(sgn){
            //qDebug()<<"child count signal = "<<parent->childCount();
            //qDebug()<<"root count signal = "<<rootItem->columnCount();
            //"Name" << "Length [Bit]" << "Byte Order" << "Value Type" << "Initial Value" << "Factor"<< "Offset"<< "Minimum" << "Maximum" ;
            idx = 0;
            parent->insertChildren(parent->childCount(), 1, rootItem->columnCount(),E_DbItemType_Signal);
            data << sgn->m_Name;
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data << sgn->m_Length;
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data << (sgn->m_ByteOrder == E_CANByteOrder_Intel ? "Intel": "Motorola");
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            if(sgn->m_ValueType == E_CANSignalSign_Signed){
                data <<"Signed";
            }else if(sgn->m_ValueType == E_CANSignalSign_UnSigned){
                data <<"Unsigned";
            }else if(sgn->m_ValueType == E_CANSignalSign_Float){
                data <<"Float";
            }else{
                data <<"Double";
            }
            //data << (sgn->m_ValueType == E_CANSignalSign_Signed ? "Signed" : "Unsigned");
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data <<  sgn->m_InitValue.dValue;
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data <<  sgn->m_Factor.dValue;
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data <<  sgn->m_Offset.dValue;
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data <<  sgn->m_Min.dValue;
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data <<  sgn->m_Max.dValue;
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data <<  sgn->m_Comment;
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);

//            switch(sgn->m_ValueType){
//            case E_CANSignalSign_Signed:
//                data << sgn->m_Factor.lValue;
//                data << sgn->m_Offset.lValue;
//                data << sgn->m_Min.lValue;
//                data << sgn->m_Max.lValue;
//                break;
//            case E_CANSignalSign_UnSigned:
//                data << sgn->m_Factor.uValue;
//                data << sgn->m_Offset.uValue;
//                data << sgn->m_Min.uValue;
//                data << sgn->m_Max.uValue;
//                break;

//            case E_CANSignalSign_Double:
//                data << sgn->m_Factor.dValue;
//                data << sgn->m_Offset.dValue;
//                data << sgn->m_Min.dValue;
//                data << sgn->m_Max.dValue;
//                break;

//            case E_CANSignalSign_Float:
//                data << sgn->m_Factor.fValue;
//                data << sgn->m_Offset.fValue;
//                data << sgn->m_Min.fValue;
//                data << sgn->m_Max.fValue;
//                break;

//            default: break;
//            }

            data.clear();
        }
        cnt++;
    }
}

// MainDbCommonItem method define area

MainDbCommonItem::MainDbCommonItem(QVector<QVariant> &data,E_DbItemType itemType, MainDbCommonItem *parent)
{
    parentItem = parent;
    itemData = data;
    m_itemType = itemType;
}

MainDbCommonItem::~MainDbCommonItem()
{
    qDeleteAll(childItems);
}

MainDbCommonItem *MainDbCommonItem::child(int number)
{
    return childItems.value(number);
}

int MainDbCommonItem::childCount() const
{
    return childItems.count();
}

int MainDbCommonItem::childNumber() const
{
    if (parentItem)
        return parentItem->childItems.indexOf(const_cast<MainDbCommonItem*>(this));
    return 0;
}

int MainDbCommonItem::columnCount() const
{
    return itemData.size();
}

QVariant  MainDbCommonItem::data(int column) const
{
    return itemData.value(column);
}
bool MainDbCommonItem::insertChildren(int position, int count, int columns, E_DbItemType type)
{
    qDebug()<<"columns ="<<columns;
    if (position < 0 || position > childItems.size())
        return false;
    for (int row = 0; row < count; ++row) {
        QVector<QVariant> data(columns);
        MainDbCommonItem *item = new MainDbCommonItem(data,type,this);
        childItems.insert(position, item);
    }

    return true;
}
bool MainDbCommonItem::insertColumns(int position, int columns)
{
    if (position < 0 || position > itemData.size())
        return false;

    for (int column = 0; column < columns; ++column)
        itemData.insert(position, QVariant());

    foreach (MainDbCommonItem *child, childItems)
        child->insertColumns(position, columns);

    return true;
}

MainDbCommonItem *MainDbCommonItem::parent()
{
    return parentItem;
}

bool MainDbCommonItem::removeChildren(int position, int count)
{
    if (position < 0 || position + count > childItems.size())
        return false;

    for (int row = 0; row < count; ++row)
        delete childItems.takeAt(position);

    return true;
}

bool MainDbCommonItem::removeColumns(int position, int columns)
{
    if (position < 0 || position + columns > itemData.size())
        return false;

    for (int column = 0; column < columns; ++column)
        itemData.removeAt(position);

    foreach (MainDbCommonItem *child, childItems)
        child->removeColumns(position, columns);

    return true;
}

bool MainDbCommonItem::setData(int column, const QVariant &value)
{
    if (column < 0 || column >= itemData.size())
        return false;
    itemData[column] = value;

    return true;
}
// MainDbTableCombineModel define area

MainDbTableCombineModel::MainDbTableCombineModel(MainDbManager *dbMng, QObject *parent, int i):MainDbCommonViewModel(dbMng,parent)
{
// do nothing , just call to construct a address for this model
// we should find another approach to fix this problem
}

MainDbTableCombineModel::MainDbTableCombineModel(MainDbManager * dbMng, QObject *parent,QModelIndex clickedIndex):
    MainDbCommonViewModel(dbMng,parent),clickedItemIndex(clickedIndex){
    QVector<QVariant> rootData;
    rootData <<  "Name" << "Length [Bit]" <<"Message"<<"Multiplexing/Group"<<"Startbit"<< "Byte Order" << "Value Type" << "Initial Value" << "Factor"<< "Offset"<< "Minimum" << "Maximum" << "Comment";
    rootItem = new MainDbCommonItem(rootData, E_DbItemType_Header);
    setupModelData(rootItem);
}

QVariant MainDbTableCombineModel::data(const QModelIndex &index, int role) const
{
    //    qDebug()<< __FUNCTION__ << __LINE__;
    if (!index.isValid())
        return QVariant();

    if (role != Qt::DisplayRole && role != Qt::EditRole && role != Qt::DecorationRole &&  role != Qt::BackgroundColorRole && role !=Qt::TextAlignmentRole)
        return QVariant();
    if(role == Qt::DisplayRole || role == Qt::EditRole){
        MainDbCommonItem *item = getItem(index);
        return item->data(index.column());
    }else if(role == Qt::DecorationRole && index.column() == 0){
        MainDbCommonItem *item = getItem(index);
        switch (item->getType() ) {
        case E_DbItemType_Message:
        {
            QPixmap px(":/icons/message.png");
            return px.scaled(16,16);
        }
            break;
        case E_DbItemType_Signal:
        case E_DbItemType_SignalInMessage:
        {
            QPixmap px(":/icons/signal.png");
            return px.scaled(16,16);
        }
            break;
        default:
            break;
        }
    }else if(role == Qt::BackgroundColorRole){
        if(index.row()%2 == 0){
            return QVariant( QColor( 215, 227, 229 ) );
        }
    }
    return QVariant();
}

bool MainDbTableCombineModel::setData(const QModelIndex &index, const QVariant &value, int role)
{
    qDebug()<<"setdata called";
    bool result = true;
    if (role != Qt::EditRole)
        return false;
    MainDbCommonItem *item = getItem(index);
    result = item->setData(index.column(), value);
    if (result)
    {
        emit dataChanged(index, index);
        emit updateByDelegate(index);
    }
    return result;
}
bool MainDbTableCombineModel::setHeaderData(int section, Qt::Orientation orientation,
                                          const QVariant &value, int role)
{
    if (role != Qt::EditRole || orientation != Qt::Horizontal)
        return false;

    bool result = rootItem->setData(section, value);
    if (result)
        emit headerDataChanged(orientation, section, section);
    return result;
}

Qt::ItemFlags MainDbTableCombineModel::flags(const QModelIndex &index) const
{
    if (!index.isValid())
        return 0;
    return Qt::ItemIsEditable | QAbstractItemModel::flags(index);
}

QVariant MainDbTableCombineModel::headerData(int section, Qt::Orientation orientation,
                                           int role) const
{
    if (orientation == Qt::Horizontal && role == Qt::DisplayRole)
        return rootItem->data(section);
    return QVariant();
}

void MainDbTableCombineModel::setupModelData(MainDbCommonItem *parent)
{

    MainDbCommonItem *inputItem = static_cast<MainDbCommonItem *> (clickedItemIndex.internalPointer());
    if(inputItem->getType()==E_DbItemType_Message){
    //qDebug()<<"row = "<<Row;
    QVector <QVariant> data;
    //static const QStringList byOrderArray[2] = {"Intel","Motorola"};
    int cnt=0, idx = 0;
    foreach (CANSignalInMessage sgn, m_dbManager->getMessagesList().at(clickedItemIndex.row())->m_Signals) {
        if(sgn.m_Signal){
            //"Name" << "Length [Bit]" <<"Message"<<"Multiplexing/Group"<<"Startbit"<< "Byte Order" <<
           qDebug()<<"child count = "<<parent->childCount();
           qDebug()<<"root count = "<<rootItem->columnCount();
            //"Value Type"<< "Initial Value" << "Factor"<< "Offset"<< "Minimum" << "Maximum" << "Comment";
          // insertChildren(int position, int count, int columns, E_DbItemType type)

           parent->insertChildren(parent->childCount(), 1, rootItem->columnCount(),E_DbItemType_Signal);
           data << sgn.m_Signal->m_Name;
            qDebug()<<sgn.m_Signal->m_Name;
            qDebug()<<parent->childCount();
            qDebug()<<idx;
            qDebug()<<data[idx];
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data << sgn.m_Signal->m_Length;
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data <<m_dbManager->getMessagesList().at(clickedItemIndex.row())->m_Name;
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data <<"mul";
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data <<sgn.m_StartBit;
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data << (sgn.m_Signal->m_ByteOrder == E_CANByteOrder_Intel ? "Intel": "Motorola");
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            //data << (sgn.m_Signal->m_ValueType == E_CANSignalSign_Signed ? "Signed" : "Unsigned");
            if(sgn.m_Signal->m_ValueType == E_CANSignalSign_Signed){
                data <<"Signed";
            }else if(sgn.m_Signal->m_ValueType  == E_CANSignalSign_UnSigned){
                data <<"Unsigned";
            }else if(sgn.m_Signal->m_ValueType  == E_CANSignalSign_Float){
                data <<"Float";
            }else{
                data <<"Double";
            }
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data <<  sgn.m_Signal->m_InitValue.dValue;
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data <<  sgn.m_Signal->m_Factor.dValue;
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data <<  sgn.m_Signal->m_Offset.dValue;
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data <<  sgn.m_Signal->m_Min.dValue;
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data <<  sgn.m_Signal->m_Max.dValue;
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data <<  sgn.m_Signal->m_Comment;
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            idx=0;
            data.clear();
        }
        cnt++;
    }}else if(inputItem->getType()==E_DbItemType_SignalInMessage){
        //qDebug()<<"row = "<<Row;
        QVector <QVariant> data;
        //static const QStringList byOrderArray[2] = {"Intel","Motorola"};
        int idx = 0;
        CANSignalInMessage sgn= m_dbManager->getMessagesList().at(clickedItemIndex.parent().row())->m_Signals.at(clickedItemIndex.row());
            if(sgn.m_Signal){
                //"Name" << "Length [Bit]" <<"Message"<<"Multiplexing/Group"<<"Startbit"<< "Byte Order" <<
               qDebug()<<"child count = "<<parent->childCount();
               qDebug()<<"root count = "<<rootItem->columnCount();
                //"Value Type"<< "Initial Value" << "Factor"<< "Offset"<< "Minimum" << "Maximum" << "Comment";
              // insertChildren(int position, int count, int columns, E_DbItemType type)

               parent->insertChildren(parent->childCount(), 1, rootItem->columnCount(),E_DbItemType_Signal);
               data << sgn.m_Signal->m_Name;
               qDebug()<<sgn.m_Signal->m_Name;
               qDebug()<<parent->childCount();
               qDebug()<<idx;
               qDebug()<<data[idx];
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                data << sgn.m_Signal->m_Length;
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                data <<m_dbManager->getMessagesList().at(clickedItemIndex.parent().row())->m_Name;
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                data <<"mul";
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                data <<sgn.m_StartBit;
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                data << (sgn.m_Signal->m_ByteOrder == E_CANByteOrder_Intel ? "Intel": "Motorola");
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                //data << (sgn.m_Signal->m_ValueType == E_CANSignalSign_Signed ? "Signed" : "Unsigned");
                if(sgn.m_Signal->m_ValueType == E_CANSignalSign_Signed){
                    data <<"Signed";
                }else if(sgn.m_Signal->m_ValueType  == E_CANSignalSign_UnSigned){
                    data <<"Unsigned";
                }else if(sgn.m_Signal->m_ValueType == E_CANSignalSign_Float){
                    data <<"Float";
                }else{
                    data <<"Double";
                }
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                data <<  sgn.m_Signal->m_InitValue.dValue;
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                data <<  sgn.m_Signal->m_Factor.dValue;
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                data <<  sgn.m_Signal->m_Offset.dValue;
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                data <<  sgn.m_Signal->m_Min.dValue;
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                data <<  sgn.m_Signal->m_Max.dValue;
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                data <<  sgn.m_Signal->m_Comment;
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                idx=0;
                data.clear();
            }
    }else if(inputItem->getType()==E_DbItemType_Signal){
        qDebug()<<"signal click  row =  "<<clickedItemIndex.row();
        CANSignal *sgn = m_dbManager->getSignalsList().at(clickedItemIndex.row());
        if(sgn){
        qDebug()<<"ok hehe"<<m_dbManager->getMessagesOfSignal(clickedItemIndex.row()).size();
        }
        QVector <QVariant> data;
        int idx = 0;
        foreach (CANMessagesOfSignal msg_sgn, m_dbManager->getMessagesOfSignal(clickedItemIndex.row())) {
            if(sgn){
               parent->insertChildren(parent->childCount(), 1, rootItem->columnCount(),E_DbItemType_Signal);
               data << sgn->m_Name;
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                data << sgn->m_Length;
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                data <<msg_sgn.m_msgName;
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                data <<"mul";
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                data <<msg_sgn.m_StartBit;
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                data << (sgn->m_ByteOrder == E_CANByteOrder_Intel ? "Intel": "Motorola");
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                if(sgn->m_ValueType == E_CANSignalSign_Signed){
                    data <<"Signed";
                }else if(sgn->m_ValueType  == E_CANSignalSign_UnSigned){
                    data <<"Unsigned";
                }else if(sgn->m_ValueType  == E_CANSignalSign_Float){
                    data <<"Float";
                }else{
                    data <<"Double";
                }
                //data << (sgn->m_ValueType == E_CANSignalSign_Signed ? "Signed" : "Unsigned");
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                data <<  sgn->m_InitValue.dValue;
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                data <<  sgn->m_Factor.dValue;
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                data <<  sgn->m_Offset.dValue;
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                data <<  sgn->m_Min.dValue;
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                data <<  sgn->m_Max.dValue;
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                data <<  sgn->m_Comment;
                parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
                idx=0;
                data.clear();
            }
    }
    }
}
void copySignal(CANSignal *editSignal, CANSignal *signal)
{
    editSignal->m_ByteOrder =signal->m_ByteOrder;
    editSignal->m_Comment=signal->m_Comment;
    editSignal->m_Factor =signal->m_Factor;
    editSignal->m_InitValue=signal->m_InitValue;
    editSignal->m_Length =signal->m_Length;
    editSignal->m_Max=signal->m_Max;
    editSignal->m_Min =signal->m_Min;
    editSignal->m_Name=signal->m_Name;
    editSignal->m_Offset =signal->m_Offset;
    editSignal->m_Unit=signal->m_Unit;
    editSignal->m_ValueType=signal->m_ValueType;
}
void copyMessage(CANMessage *editMessage, CANMessage *message)
{
    editMessage->m_ID =message->m_ID;
    editMessage->m_IdType=message->m_IdType;
    editMessage->m_Length =message->m_Length;
    editMessage->m_Name=message->m_Name;
}
